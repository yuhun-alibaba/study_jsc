// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/runtime.h"
#include "runtime/loader.h"
#include "net/url_request.h"
#include "runtime/js_context.h"
#include "runtime/js_function.h"
#include "net/url_request_context.h"

namespace jscore {
    Loader::Loader(JSContext* context) : context_(context) {
        
    }
    
    Loader::~Loader() {
        
    }
    
    void Loader::Script(const std::string& url, JSFunction* succ_func, JSFunction* error_func) {
        LoaderRequestDelegate* delegate = new LoaderRequestDelegate(context_, succ_func, error_func);
        delegate->AddRef();
        base::ScopedPtr<net::URLRequest> request(net::URLRequestContext::CreateRequest(
                reinterpret_cast<long>(context_->runtime())));
        request->Fetch(url, delegate);
    }
    
    void LoaderRequestDelegate::OnFailed(base::PlatformString& url, base::PlatformString& error) {
        context_->runtime()->thread_manager()->RunOnJSThread(base::Bind(&LoaderRequestDelegate::OnFailedOnJSThread, weak_ptr_));
    }
    
    void LoaderRequestDelegate::OnSuccess(base::PlatformString& url, base::PlatformString& response) {
        context_->runtime()->thread_manager()->RunOnJSThread(base::Bind(&LoaderRequestDelegate::OnSuccessOnJSThread, weak_ptr_, response));
    }
    
    void LoaderRequestDelegate::OnSuccessOnJSThread(const base::PlatformString& response) {
        if (js_succ_function_.Get() != NULL) {
            context_->RunScript(const_cast<base::PlatformString*>(&response)->GetUTFChars());
            js_succ_function_->Run(reinterpret_cast<void *>(TargetState::Global), NULL);
        }
        Release();
    }
    
    void LoaderRequestDelegate::OnFailedOnJSThread() {
        if (js_error_function_.Get() != NULL) {
            js_error_function_->Run(reinterpret_cast<void *>(TargetState::Global), NULL);
        }
        Release();
    }
}
