// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/js_event.h"
#include "runtime/js_value.h"
#include "runtime/js_array.h"

namespace jscore {
    JSEvent::JSEvent(std::string event) : type_(event){
        set_class_name("JSEvent");
        RegisterMethodCallback("initEvent", &InitEventCallback);
        RegisterMethodCallback("preventDefault", &PreventDefaultCallback);
        RegisterMethodCallback("stopPropagation", &StopPropagationCallback);
        RegisterAccessorCallback("type", &GetTypeCallback, 0);
        RegisterAccessorCallback("bubbles", &GetBubblesCallback, 0);
        RegisterAccessorCallback("cancelable", &GetCancelableCallback, 0);
        RegisterAccessorCallback("target", &GetTargetCallback, 0);
        RegisterAccessorCallback("currentTarget", &GetCurrentTargetCallback, 0);
    }

    JSEvent::~JSEvent() {

    }

    void JSEvent::InitEvent(std::string type, bool bubbles, bool cancelable) {

    }

    void JSEvent::PreventDefault() {

    }

    void JSEvent::StopPropagation() {

    }

    base::ScopedPtr<JSValue> JSEvent::GetTypeCallback(JSTargetObject* object) {
        std::string type = static_cast<JSEvent*>(object)->type();
        JSValue* value = JSValue::MakeString(type);
        return JSValue::MakeValueScoped(value);
    }

    base::ScopedPtr<JSValue> JSEvent::GetBubblesCallback(JSTargetObject* object) {
        JSValue* value = JSValue::MakeBool(static_cast<JSEvent*>(object)->bubbles());
        return JSValue::MakeValueScoped(value);
    }

    base::ScopedPtr<JSValue> JSEvent::GetCancelableCallback(JSTargetObject* object) {
        JSValue* value = JSValue::MakeBool(static_cast<JSEvent*>(object)->cancelable());
        return JSValue::MakeValueScoped(value);
    }

    base::ScopedPtr<JSValue> JSEvent::GetTargetCallback(JSTargetObject* object) {
        JSEvent* js_event = static_cast<JSEvent*>(object);
        JSValue* value = JSValue::MakeObjectWrap(
                static_cast<ObjectWrap*>(js_event->target()->GetJSRef()));
        return JSValue::MakeValueScoped(value);
    }

    base::ScopedPtr<JSValue> JSEvent::GetCurrentTargetCallback(JSTargetObject* object) {
        JSEvent* js_event = static_cast<JSEvent*>(object);
        JSValue* value = JSValue::MakeObjectWrap(
                static_cast<ObjectWrap*>(js_event->current_target()->GetJSRef()));
        return JSValue::MakeValueScoped(value);
    }

    base::ScopedPtr<JSValue> JSEvent::StopPropagationCallback(JSTargetObject* object, base::ScopedPtr<JSValue> value) {
        static_cast<JSEvent*>(object)->StopPropagation();
        return base::ScopedPtr<JSValue>();
    }

    base::ScopedPtr<JSValue> JSEvent::PreventDefaultCallback(JSTargetObject* object, base::ScopedPtr<JSValue> value) {
        static_cast<JSEvent*>(object)->PreventDefault();
        return base::ScopedPtr<JSValue>();
    }

    base::ScopedPtr<JSValue> JSEvent::InitEventCallback(JSTargetObject* object, base::ScopedPtr<JSValue> value) {
        JSArray* array = static_cast<JSArray*>(value.Get());
        static_cast<JSEvent*>(object)->InitEvent(array->Get(0)->data_.str,
                                                 array->Get(1)->data_.b,
                                                 array->Get(2)->data_.b);
        return base::ScopedPtr<JSValue>();
    }

    void JSEvent::Reset() {

    }

}