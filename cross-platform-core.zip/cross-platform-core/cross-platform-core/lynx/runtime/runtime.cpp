// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/js_context.h"
#include "runtime/runtime.h"
#include "runtime/js_vm.h"

#include "loader/xc/xc_loader.h"
#include "loader/html/html_loader.h"
#include "parser/render_parser.h"
#include "render/render_tree_host.h"
#include "render/render_tree_host_impl.h"

namespace jscore {

    Runtime::Runtime(JSContext* context)
            : data_server_rendered_(false),
              thread_manager_(new ThreadManager()),
              context_(context), weak_ptr_(this) {
                
    }
    
    void Runtime::InitRuntime(const char* arg) {
        thread_manager_->RunOnJSThread(
                base::Bind(&Runtime::InitRuntimeOnJSThread, weak_ptr_, arg));
    }

    void Runtime::LoadUrl(const std::string& url) {

        if(!data_server_rendered_) {
            render_tree_host()->host_impl()->SetNoParser();
        }
        LoadUrl(url, loader::LynxLoader::MAIN_FILE);
    }

    void Runtime::LoadUrl(const std::string& url, int type) {
        loader_->Load(url, type);
        thread_manager_->RunOnJSThread(
                base::Bind(&Runtime::LoadUrlOnJSThread, weak_ptr_, url));
    }

    void Runtime::Reload(bool force) {
        thread_manager_->RunOnJSThread(
                base::Bind(&Runtime::ReloadOnJSThread, weak_ptr_, force));
    }

    void Runtime::RunScript(const base::PlatformString& source) {
        thread_manager_->RunOnJSThread(
                base::Bind(&Runtime::RunScriptOnJSThread, weak_ptr_, source));
    }

    void Runtime::LoadHTML(const std::string& html) {
        parser::RenderParser parser(render_tree_host(), thread_manager());
        parser.Insert(html);
        render_tree_host()->ForceFlushCommands();
        render_tree_host()->host_impl()->SetParseFinished();
    }

    void Runtime::LoadScript(const std::string& source) {
        LoadScriptOnJSThread(source);
    }

    void Runtime::FlushScript() {
        loader_->Flush();
    }

    void Runtime::Destroy() {
        thread_manager_->DetachUIThread();
        thread_manager_->QuitJSThread(base::Bind(&Runtime::DestroyOnJSThread, weak_ptr_));
    }

    void Runtime::SetDataServerRendered(bool data_server_rendered) {
        data_server_rendered_ = data_server_rendered;
        if(data_server_rendered) {
            loader_ = new loader::HTMLLoader(this);
        }else {
            loader_ = new loader::XCLoader(this);
        }
    }

    void Runtime::InitRuntimeOnJSThread(const char *arg) {
        vm_ = new JSVM();
        vm_->Initialize();
        context_->Initialize(vm_.Get(), this);
    }

    void Runtime::RunScriptOnJSThread(const base::PlatformString& source) {
        context_->RunScript(const_cast<base::PlatformString*>(&source)->GetUTFChars());
    }

    void Runtime::LoadScriptOnJSThread(const std::string& source) {
        context_->RunScript(source.c_str());
    }

    void Runtime::LoadUrlOnJSThread(const std::string& url) {
        context_->LoadUrl(url);
    }

    void Runtime::ReloadOnJSThread(bool force) {

    }

    void Runtime::DestroyOnJSThread() {
        delete this;
    }
}  // namespace jscore
