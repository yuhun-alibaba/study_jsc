// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/js_target_object.h"
#include "runtime/js_object.h"
#include "runtime/js_value.h"

namespace jscore {

    JSTargetObject::JSTargetObject() {
    }

    JSTargetObject::~JSTargetObject() {

    }

    void JSTargetObject::RegisterMethodCallback(std::string method_name,
                                                JSMethodCallback callback) {
        methods_[method_name] = callback;
    }

    void JSTargetObject::RegisterAccessorCallback(std::string field_name,
                                                        JSGetPropertyCallback get_callback,
                                                        JSSetPropertyCallback set_callback) {
        Field field;
        if (get_callback != 0) {
            field.get_callback = get_callback;
        }
        if (set_callback != 0) {
            field.set_callback = set_callback;
        }
        fields_[field_name] = field;
    }

    base::ScopedPtr<JSValue> JSTargetObject::MethodCallback(std::string name, base::ScopedPtr<JSValue> value) {
        auto it = methods_.find(name);
        if (it != methods_.end()) {
            JSMethodCallback callback = it->second;
            return (*callback)(this, value);
        }
        return base::ScopedPtr<JSValue>();
    }

    void JSTargetObject::SetPropertyCallback(std::string name, base::ScopedPtr<JSValue> value) {
        auto it = fields_.find(name);
        if (it != fields_.end()) {
            Field field = it->second;
            JSSetPropertyCallback callback = field.set_callback;
            if (callback != 0) {
                (*callback)(this, value);
            }
        }
    }

    base::ScopedPtr<JSValue> JSTargetObject::GetPropertyCallback(std::string name) {
        auto it = fields_.find(name);
        if (it != fields_.end()) {
            Field field = it->second;
            JSGetPropertyCallback callback = field.get_callback;
            if (callback != 0) {
                return (*callback)(this);
            }
        }
        return base::ScopedPtr<JSValue>();
    }
}