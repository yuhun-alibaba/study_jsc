// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JS_TARGET_OBJECT_H_
#define LYNX_RUNTIME_JS_TARGET_OBJECT_H_

#include <string>
#include <unordered_map>
#include <vector>
#include "base/scoped_ptr.h"
#include "runtime/js_value.h"

namespace jscore {
    class JSValue;

    class JSTargetObject {

    public:

        typedef base::ScopedPtr<jscore::JSValue> (*JSMethodCallback)
                (jscore::JSTargetObject*, base::ScopedPtr<jscore::JSValue>);
        typedef base::ScopedPtr<jscore::JSValue> (*JSGetPropertyCallback)
                (jscore::JSTargetObject*);
        typedef void (*JSSetPropertyCallback)
                (jscore::JSTargetObject*, base::ScopedPtr<jscore::JSValue>);

        struct Field{
            JSSetPropertyCallback set_callback = 0;
            JSGetPropertyCallback get_callback = 0;
        };

        JSTargetObject();
        virtual ~JSTargetObject();
        void RegisterMethodCallback(std::string method_name,
                                    JSMethodCallback callback);
        void RegisterAccessorCallback(std::string field_name,
                                     JSGetPropertyCallback get_callback,
                                     JSSetPropertyCallback set_callback);

        base::ScopedPtr<JSValue> MethodCallback(std::string name, base::ScopedPtr<JSValue> value);
        void SetPropertyCallback(std::string name, base::ScopedPtr<JSValue> value);
        base::ScopedPtr<JSValue> GetPropertyCallback(std::string name);

        inline void set_class_name(std::string class_name) {
            class_name_ = class_name;
        }

        inline std::string &class_name() {
            return class_name_;
        }

        inline std::unordered_map<std::string, JSMethodCallback> methods() {
            return methods_;
        }

        inline std::unordered_map<std::string, Field> fields() {
            return fields_;
        }

    private:

        std::unordered_map<std::string, JSMethodCallback> methods_;
        std::unordered_map<std::string, Field> fields_;
        std::string class_name_;
    };
}

#endif //LYNX_RUNTIME_JS_TARGET_OBJECT_H_
