// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef ANDROID_JS_EVENT_H
#define ANDROID_JS_EVENT_H

#include <string>
#include "runtime/js_target_object.h"
#include "runtime/js_value.h"
#include "render/render_object.h"

namespace jscore {
    class JSEvent : public JSTargetObject {

    public:
        JSEvent(std::string event);
        virtual ~JSEvent();

        void InitEvent(std::string type, bool bubbles, bool cancelable);
        void PreventDefault();
        void StopPropagation();

        void set_type(std::string type) {
            type_ = type;
        }

        std::string type() {
            return type_;
        }

        inline void set_target(lynx::RenderObject* target) {
            target_ = target;
        }

        inline lynx::RenderObject* target() {
            return target_;
        }

        inline void set_current_target(lynx::RenderObject* current_target) {
            current_target_ = current_target;
        }

        inline lynx::RenderObject* current_target() {
            return current_target_;
        }

        inline bool bubbles() {
            return bubbles_;
        }

        inline bool cancel_bubble() {
            return bubbles_;
        }

        inline bool cancelable() {
            return cancelable_;
        }

    private:
        static base::ScopedPtr<JSValue> GetTypeCallback(JSTargetObject* object);
        static base::ScopedPtr<JSValue> GetBubblesCallback(JSTargetObject* object);
        static base::ScopedPtr<JSValue> GetCancelableCallback(JSTargetObject* object);
        static base::ScopedPtr<JSValue> GetTargetCallback(JSTargetObject* object);
        static base::ScopedPtr<JSValue> GetCurrentTargetCallback(JSTargetObject* object);
        static base::ScopedPtr<JSValue> StopPropagationCallback(JSTargetObject* object, base::ScopedPtr<JSValue> value);
        static base::ScopedPtr<JSValue> PreventDefaultCallback(JSTargetObject* object, base::ScopedPtr<JSValue> value);
        static base::ScopedPtr<JSValue> InitEventCallback(JSTargetObject* object, base::ScopedPtr<JSValue> value);
        void Reset();

        lynx::RenderObject* current_target_;
        lynx::RenderObject* target_;

        bool default_prevented_;
        bool cancel_bubble_;
        bool cancelable_;
        bool bubbles_;

        long time_stamp;

        std::string type_;

    };
}


#endif //ANDROID_JS_EVENT_H
