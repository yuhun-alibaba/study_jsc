// Copyright 2017 The Lynx Authors. All rights reserved.


#ifndef LYNX_RUNTIME_TIMED_TASK_INVOKER_H_
#define LYNX_RUNTIME_TIMED_TASK_INVOKER_H_

#include "base/task/callback.h"
#include "base/scoped_ptr.h"
#include "runtime/runtime.h"
#include "runtime/js_function.h"

namespace jscore {
    
    class JSContext;
    
    class TimedTask : public base::Clouse{
    public:
        
        TimedTask(JSFunction* js_function) : js_function_(js_function) {}
        virtual ~TimedTask() {}
        
    protected:
        virtual void Run();
        
    private:
        base::ScopedPtr<JSFunction> js_function_;
    };
    
    class TimedTaskInvoker {
    public:
        void SetTimeout(JSContext* context, JSFunction* function, int time);
        void SetInterval(JSContext* context, JSFunction* function, int time);
        void clearTimeout();
    };
    
}


#endif // LYNX_RUNTIME_TIMED_TASK_INVOKER_H_
