// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/js_value.h"

#include "runtime/js_object.h"
#include "runtime/js_target_object.h"
#include "runtime/js_array.h"
#include "runtime/jsc/object_wrap.h"
#include "js_value.h"

namespace jscore {
    JSValue::JSValue() {

    }

    JSValue::JSValue(Type type) : type_(type) {

    }

    JSValue::~JSValue() {
        if (type_ == VALUE_JS_ARRAY && data_.js_array != 0) {
            delete data_.js_array;
        } else if (type_ == VALUE_JS_ARRAY && data_.js_object != 0) {
            delete data_.js_object;
        }
    }
}