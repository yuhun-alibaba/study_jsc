//
//  window_object.h
//  lynx-ios
//
//  Created by yxp on 16/12/9.
//  Copyright © 2016年 dli. All rights reserved.
//

#ifndef window_object_h
#define window_object_h

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>
#import <UIKit/UIKit.h>

@interface WindowObject : NSObject

@property (nonatomic, assign, readonly) CGFloat devicePixelRatio;


-(id) initWithContext: (JSContext *)context;
@end

#endif /* window_object_h */
