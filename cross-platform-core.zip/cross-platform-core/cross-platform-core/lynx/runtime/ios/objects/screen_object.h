//
//  screen_object.h
//  lynx-ios
//
//  Created by yxp on 16/12/9.
//  Copyright © 2016年 dli. All rights reserved.
//

#ifndef screen_object_h
#define screen_object_h

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>
#import <UIKit/UIKit.h>

@protocol ScreenObjectProtocol <JSExport>

@property(nonatomic, assign, readonly) CGFloat width;
@property(nonatomic, assign, readonly) CGFloat height;

@end

@interface ScreenObject : NSObject <ScreenObjectProtocol>

@end

#endif /* screen_object_h */
