//
//  console_object.h
//  lynx-ios
//
//  Created by dli on 11/3/16.
//  Copyright © 2016 dli. All rights reserved.
//

#ifndef CONSOLE_OBJECT_H_
#define CONSOLE_OBJECT_H_

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>

@protocol ConsoleObjectProtocol <JSExport>
-(id) time;
-(id) log:(id) value;
-(id) warn:(id) value;
-(id) alert:(id) value;
-(id) error:(id) value;
@end

@interface ConsoleObject : NSObject <ConsoleObjectProtocol>
@end

#endif /* CONSOLE_OBJECT_H_ */
