//
//  screen_object.cpp
//  lynx-ios
//
//  Created by yxp on 16/12/9.
//  Copyright © 2016年 dli. All rights reserved.
//

#import "screen_object.h"

@implementation ScreenObject

-(CGFloat) width
{
    return [[UIScreen mainScreen] bounds].size.width;
}

-(CGFloat) height
{
    return [[UIScreen mainScreen] bounds].size.height;
}

@end
