//
//  console_object.cpp
//  lynx-ios
//
//  Created by dli on 11/3/16.
//  Copyright © 2016 dli. All rights reserved.
//

#include "console_object.h"

@implementation ConsoleObject

-(id) time
{
    return @([[NSDate date] timeIntervalSince1970] * 1000);
}

-(id) log:(id) value
{
    NSLog(@"js log: %@", value);
    return nil;
}

-(id) warn:(id) value
{
    NSLog(@"js warn: %@", value);
    return nil;
}

-(id) alert:(id) value
{
    NSLog(@"js alert: %@", value);
    return nil;
}

-(id) error:(id) value
{
    NSLog(@"js error: %@", value);
    return nil;
}
@end
