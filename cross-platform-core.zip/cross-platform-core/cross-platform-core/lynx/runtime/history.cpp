// Copyright 2017 The Lynx Authors. All rights reserved.

#include <stdio.h>
#include "history.h"

namespace jscore {
    
    History::History(JSContext* context) : context_(context), pos_(kBlankPos) {
        
    }
    
    History::~History() {
        
    }
    
    void History::Load() {
        if (pos_ == kBlankPos) {
            context_->LoadUrl("");
        } else {
            const std::string url = history_list_.at(pos_);
            context_->LoadUrl(url);
        }
    }
    
    void History::Forward() {
        Go(1);
    }
    
    void History::Back() {
        Go(-1);
    }
    
    void History::ReloadUrl(const std::string& url) {
        if (pos_ == kBlankPos) {
            return;
        }
        history_list_[pos_] = url;
    }
    
    void History::Go(const std::string& url) {
        int index = kBlankPos;
        for (int i = 0; i < history_list_.size(); ++i) {
            if (url.compare(history_list_.at(i)) == 0) {
                index = i;
            }
        }
        if (index > kBlankPos) {
            pos_ = index;
        } else {
            history_list_.push_back(url);
            pos_++;
        }
    }
    
    void History::Go(int offset) {
        int target = pos_ + offset;
        if (target < kBlankPos || target >= history_list_.size()) {
            return;
        }
        pos_ = target;
    }
    
    int History::GetLength() {
        return (int) history_list_.size();
    }
    
}
