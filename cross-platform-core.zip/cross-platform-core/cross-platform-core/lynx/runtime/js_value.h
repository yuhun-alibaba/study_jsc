// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JS_VALUE_H_
#define LYNX_RUNTIME_JS_VALUE_H_

#include "base/scoped_ptr.h"
#include <string>

namespace jscore {

    class JSArray;
    class JSObject;
    class JSTargetObject;
    class ObjectWrap;

    class JSValue {
    public:
        enum Type {
            VALUE_INT,
            VALUE_LONG,
            VALUE_BOOL,
            VALUE_FLOAT,
            VALUE_DOUBLE,
            VALUE_STRING,
            VALUE_JS_OBJECT,
            VALUE_JS_ARRAY,
            VALUE_JS_TARGET_OBJECT,
            VALUE_OBJECT_WRAP,
            VALUE_NULL,
        };

        Type type_;
        union {
            int i;
            bool b;
            long l;
            float f;
            double d;
            const char* str;
            JSArray* js_array;
            JSObject* js_object;
            JSTargetObject* js_target_object;
            ObjectWrap* object_wrap;
        } data_;

        inline static JSValue* MakeBool(bool value) {
            JSValue *js_value = new JSValue(JSValue::Type::VALUE_BOOL);
            js_value->data_.b = value;
            return js_value;
        }

        inline static JSValue* MakeLong(long value) {
            JSValue *js_value = new JSValue(JSValue::Type::VALUE_LONG);
            js_value->data_.l = value;
            return js_value;
        }

        inline static JSValue* MakeInt(int value) {
            JSValue *js_value = new JSValue(JSValue::Type::VALUE_INT);
            js_value->data_.i = value;
            return js_value;
        }

        inline static JSValue* MakeFloat(float value) {
            JSValue *js_value = new JSValue(JSValue::Type::VALUE_FLOAT);
            js_value->data_.f = value;
            return js_value;
        }

        inline static JSValue* MakeDouble(double value) {
            JSValue *js_value = new JSValue(JSValue::Type::VALUE_DOUBLE);
            js_value->data_.d = value;
            return js_value;
        }

        inline static JSValue* MakeString(std::string& value) {
            JSValue *js_value = new JSValue(JSValue::Type::VALUE_STRING);
            js_value->data_.str = value.c_str();
            return js_value;
        }

        inline static JSValue* MakeString(std::string&& value) {
            JSValue *js_value = new JSValue(JSValue::Type::VALUE_STRING);
            js_value->data_.str = value.c_str();
            return js_value;
        }

        inline static JSValue* MakeTargetObject(JSTargetObject* object) {
            JSValue *js_object = new JSValue(JSValue::Type::VALUE_JS_TARGET_OBJECT);
            js_object->data_.js_target_object = object;
            return js_object;
        }

        inline static JSValue* MakeObjectWrap(ObjectWrap* object_wrap) {
            JSValue *js_object = new JSValue(JSValue::Type::VALUE_OBJECT_WRAP);
            js_object->data_.object_wrap = object_wrap;
            return js_object;
        }

        inline static base::ScopedPtr<JSValue> MakeValueScoped(JSValue* js_value) {
            return base::ScopedPtr<JSValue>(js_value);
        }

        inline static base::ScopedPtr<JSArray> MakeArrayScoped(JSArray* js_array) {
            return base::ScopedPtr<JSArray>(js_array);
        }

        inline static base::ScopedPtr<JSObject> MakeObjectScoped(JSObject* js_object) {
            return base::ScopedPtr<JSObject>(js_object);
        }

        virtual ~JSValue();

    protected:

        JSValue();

        JSValue(Type type);

    };
}


#endif //LYNX_RUNTIME_JS_VALUE_H_
