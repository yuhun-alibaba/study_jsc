// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JS_ARRAY_H_
#define LYNX_RUNTIME_JS_ARRAY_H_

#include <vector>
#include "runtime/js_value.h"
#include "base/scoped_set.h"

namespace jscore {

    class JSArray : public JSValue {
    public:
        JSArray();
        virtual ~JSArray();

        void Push(JSValue* value);
        JSValue* Pop();
        JSValue* Get(int index);
        int Size();

    private:
        void RemovePtr(JSValue* value);
        void AddPtr(JSValue* value);
        std::vector<JSValue*> values_;
        base::ScopedSet<JSValue> ptrs_;
    };
}


#endif //LYNX_RUNTIME_JS_ARRAY_H_
