// Copyright 2017 The Lynx Authors. All rights reserved.



#include "runtime/android/jni_runtime_bridge.h"

#include "base/android/jni_helper.h"
#include "config/global_config_data.h"
#include "render/android/render_tree_host_impl_android.h"
#include "render/android/render_object_impl_android.h"

#include "base/print.h"

#include "JSRuntime_jni.h"

#if USING_V8
#include "runtime/v8/v8_context.h"
#else
#include "runtime/jsc/jsc_context.h"
#endif


jint CreateNativeJSRuntime(JNIEnv* env, jobject jcaller) {
    jscore::Runtime* runtime_ptr = 
#if USING_V8
        new jscore::Runtime(new jscore::V8Context());
#else
        new jscore::Runtime(new jscore::JSCContext());
#endif
    return reinterpret_cast<long>(runtime_ptr);
}

void DestroyNativeJSRuntime(JNIEnv* env, jobject jcaller, jlong runtime) {
    LOGD("lynx-debug", "DestroyNativeJSRuntime");
    jscore::Runtime* runtime_ptr = reinterpret_cast<jscore::Runtime*>(runtime);
    if(runtime_ptr == NULL) return ;

    runtime_ptr->Destroy();
}

void RunScript(JNIEnv *env, jobject jcaller, jlong runtime, jstring source) {
    jscore::Runtime* runtime_ptr = reinterpret_cast<jscore::Runtime*>(runtime);
    LOGD("lynx-debug", "RunScript %p", runtime_ptr);
    base::PlatformString platform_string(env, source);
    runtime_ptr->RunScript(platform_string);
}

void LoadHTML(JNIEnv *env, jobject jcaller, jlong runtime, jstring source) {
    jscore::Runtime* runtime_ptr = reinterpret_cast<jscore::Runtime*>(runtime);
    LOGD("lynx-debug", "RunScript %p", runtime_ptr);
    base::PlatformString platform_string(env, source);
    runtime_ptr->LoadHTML(platform_string.ToString());
}

void LoadUrl(JNIEnv *env, jobject jcaller, jlong runtime, jstring url) {
    jscore::Runtime* runtime_ptr = reinterpret_cast<jscore::Runtime*>(runtime);
    runtime_ptr->LoadUrl(base::android::JNIHelper::ConvertToString(env, url));
}

void InitRuntime(JNIEnv *env, jobject caller, jlong runtime) {

    jscore::Runtime* runtime_ptr = reinterpret_cast<jscore::Runtime*>(runtime);
    LOGD("lynx-debug", "InitRuntime %p", runtime_ptr);
    if (runtime_ptr == NULL) return;
    runtime_ptr->SetupRenderHost();
    runtime_ptr->InitRuntime("");
}

jobject ActiveRuntime(JNIEnv *env, jobject caller, jlong runtime, jint width, jint height, jdouble density, jboolean dataServerRendered) {

    jscore::Runtime* runtime_ptr = reinterpret_cast<jscore::Runtime*>(runtime);
    LOGD("lynx-debug", "ActiveRuntime %p", runtime_ptr);
    if (runtime_ptr == NULL) return 0;

    if (!config::GlobalConfigData::GetInstance()->is_initialized()) {
        config::GlobalConfigData::GetInstance()->SetScreenConfig(
            width, height, density);
    }

    runtime_ptr->SetDataServerRendered(dataServerRendered);

    return reinterpret_cast<lynx::RenderTreeHostImplAndroid*>(
               runtime_ptr->render_tree_host()->host_impl())->GetJavaImpl();
}

namespace jscore {

bool JNIRuntimeBridge::RegisterJNIUtils(JNIEnv* env) {
    return RegisterNativesImpl(env);
}

}
