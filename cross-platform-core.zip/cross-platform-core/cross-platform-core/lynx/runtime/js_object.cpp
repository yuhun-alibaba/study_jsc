// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/js_object.h"
#include <assert.h>

namespace jscore {

    JSObject::JSObject() : JSValue(JSValue::Type::VALUE_JS_OBJECT) {
        data_.js_object = this;
    }

    JSObject::~JSObject() {
        data_.js_object = NULL;
    }

    void JSObject::Set(std::string name, JSValue* value) {
        properties_[name] = value;
        AddPtr(value);
    }

    void JSObject::Delete(std::string name) {
        auto it = properties_.find(name);
        if (it != properties_.end()) {
            RemovePtr(it->second);
            properties_.erase(it);
        }
    }

    JSValue* JSObject::GetProperty(std::string name) {
        auto it = properties_.find(name);
        if (it != properties_.end()) {
            return it->second;
        }
        JSValue* value = 0;
        return value;
    }

    int JSObject::Size() {
        return properties_.size();
    }

    std::string JSObject::GetName(int index) {
        std::unordered_map<std::string, JSValue*>::iterator it;
        for (it = properties_.begin(); it != properties_.end() && index > 0; ++it, --index);
        assert(it != properties_.end());
        return it->first;
    }

    void JSObject::AddPtr(JSValue* value) {
        ptrs_.add(value);
    }

    void JSObject::RemovePtr(JSValue* value) {
        bool exist = false;
        for (auto it = properties_.begin(); it != properties_.end(); ++it) {
            if (it->second == value) {
                exist = true;
                break;
            }
        }
        if (!exist) {
            ptrs_.erase(value);
        }
    }
}