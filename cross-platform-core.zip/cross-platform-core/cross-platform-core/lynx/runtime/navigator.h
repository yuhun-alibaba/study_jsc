// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_NAVIGATOR_H_
#define LYNX_RUNTIME_NAVIGATOR_H_

#include "runtime/config.h"

namespace jscore {
    class Navigator {
    public:
        inline std::string user_agent() {
            return USERAGENT;
        }
        
        inline std::string app_code_name() {
            return APP_NAME;
        }
        
        inline std::string app_version() {
            return VERSION;
        }
        
        inline std::string platform() {
            return PLATFORM;
        }
        
        inline std::string app_name() {
            return APP_NAME;
        }
    };
}
#endif // LYNX_RUNTIME_NAVIGATOR_H_
