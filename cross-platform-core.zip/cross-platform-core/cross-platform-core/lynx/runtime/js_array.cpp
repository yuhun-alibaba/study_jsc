// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/js_array.h"

namespace jscore {
    JSArray::JSArray() : JSValue(JSValue::Type::VALUE_JS_ARRAY) {
        data_.js_array = this;
    }

    JSArray::~JSArray() {
        data_.js_array = 0;
    }

    void JSArray::Push(JSValue* value) {
        values_.push_back(value);
        AddPtr(value);
    }

    JSValue* JSArray::Pop() {
        if (values_.size() > 0) {
            JSValue* value = values_[values_.size() - 1];
            values_.pop_back();
            RemovePtr(value);
            return value;
        }
        return 0;
    }

    JSValue* JSArray::Get(int index) {
        return values_[index];
    }

    int JSArray::Size() {
        return values_.size();
    }

    void JSArray::RemovePtr(JSValue* value) {
        bool exist = false;
        for (auto it = values_.begin(); it != values_.end(); ++it) {
            if (*it == value) {
                exist = true;
                break;
            }
        }
        if (!exist) {
            ptrs_.erase(value);
        }
    }

    void JSArray::AddPtr(JSValue* value) {
        ptrs_.add(value);
    }

}