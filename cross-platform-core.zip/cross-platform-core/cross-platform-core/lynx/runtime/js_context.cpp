//
//  js_context.cpp
//  lynx
//
//  Created by dli on 30/06/2017.
//  Copyright © 2017 lynx. All rights reserved.
//

#include "runtime/js_context.h"
