//
//  js_context.hpp
//  lynx
//
//  Created by dli on 30/06/2017.
//  Copyright © 2017 lynx. All rights reserved.
//

#ifndef LYNX_RUNTIME_JS_CONTEXT_H_
#define LYNX_RUNTIME_JS_CONTEXT_H_

#include "base/observer/observer_list.h"
#include "base/ref_counted_ptr.h"
#include "runtime/js_vm.h"

namespace jscore {
    class Runtime;
class JSContext {
 public:
    JSContext()
            :runtime_(NULL),
             vm_(NULL) {

    }

    virtual ~JSContext() {
        Finalize();
    }

    virtual void Initialize(JSVM* vm, Runtime* runtime) {
        vm_ = vm;
        runtime_ = runtime;
    }
    virtual void RunScript(const char* source) {}
    virtual void LoadUrl(const std::string& url) {}

    void* GetVM() {
        return vm_->vm();
    }

    Runtime* runtime() {
        return runtime_;
    }

    void AddObserver(base::Observer* obs) {
        observers_.AddObserver(obs);
    }

    void RemoveObserver(base::Observer* obs) {
        observers_.RemoveObserver(obs);
    }

    void Finalize() {
        observers_.ForEachObserver();
    }

 protected:
    Runtime* runtime_;
    JSVM* vm_;
    base::ObserverList observers_;
};
}

#endif  // LYNX_RUNTIME_JS_CONTEXT_H_
