//
//  window.c
//  lynx
//
//  Created by 燕行 on 17/7/7.
//  Copyright © 2017年 lynx. All rights reserved.
//

#include "window.h"
