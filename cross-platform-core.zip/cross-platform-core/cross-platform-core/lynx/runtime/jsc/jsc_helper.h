// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JSC_JSC_HELPER_H_
#define LYNX_RUNTIME_JSC_JSC_HELPER_H_

#include <JavaScriptCore/JavaScript.h>
#include <string>
#include "runtime/js_array.h"
#include "runtime/js_value.h"
#include "runtime/js_object.h"
#include "runtime/js_target_object.h"

namespace jscore {
    class JSCHelper {
        public:
        static bool ConvertToBool(JSContextRef ctx, JSValueRef value) {
            return JSValueToBoolean(ctx, value);
        }
        static std::string ConvertToString(JSContextRef ctx, JSValueRef value);
        static std::string ConvertToString(JSContextRef ctx, JSStringRef value);
        static JSValue* ConvertToValue(JSContextRef ctx, JSValueRef value);
        static JSArray* ConvertToArray(JSContextRef ctx, JSObjectRef value);
        static JSArray* ConvertToArray(JSContextRef ctx, JSValueRef* value, int length);
        static JSObject* ConvertToObject(JSContextRef ctx, JSObjectRef value);

        static JSValueRef ConvertToJSString(JSContextRef ctx, const std::string &s);
        static JSValueRef ConvertToJSString(JSContextRef ctx, const char* s);

        static JSValueRef* ConvertToJSValueRefArray(JSContextRef ctx, jscore::JSArray* args);
        static JSObjectRef ConvertToJSArray(JSContextRef ctx, jscore::JSArray* args);
        static JSValueRef ConvertToJSValue(JSContextRef ctx, jscore::JSValue* value);
        static JSObjectRef ConvertToJSObject(JSContextRef ctx, jscore::JSObject* object);
        static JSObjectRef ConvertToJSTargetObject(JSContextRef ctx, jscore::JSTargetObject* object);
        static JSObjectRef ConvertToObjectWrap(JSContextRef ctx, ObjectWrap* object);

        static void SetPropertyAsFunction(JSContextRef context, JSObjectRef object, std::string propertyName, JSObjectCallAsFunctionCallback callAsFunction, JSPropertyAttributes attributes, JSValueRef* exception) {
            
            JSStringRef name = JSStringCreateWithUTF8CString(propertyName.c_str());
            JSObjectRef function = JSObjectMakeFunctionWithCallback(context, name, callAsFunction);
            JSObjectSetProperty(context, object, name, function, attributes, exception);
            JSStringRelease(name);
        }
        
        static void SetPropertyAsValue(JSContextRef context, JSObjectRef object, std::string propertyName, JSValueRef value, JSPropertyAttributes attributes, JSValueRef* exception) {
            
            JSStringRef name = JSStringCreateWithUTF8CString(propertyName.c_str());
            JSObjectSetProperty(context, object, name, value, attributes, exception);
            JSStringRelease(name);
        }


        inline static JSValueRef ConvertToJSInt(JSContextRef ctx, JSValue* value) {
            return JSValueMakeNumber(ctx, value->data_.i);
        }

        inline static JSValueRef ConvertToJSLong(JSContextRef ctx, JSValue* value) {
            return JSValueMakeNumber(ctx, value->data_.l);
        }

        inline static JSValueRef ConvertToJSFloat(JSContextRef ctx, JSValue* value) {
            return JSValueMakeNumber(ctx, value->data_.f);
        }

        inline static JSValueRef ConvertToJSDouble(JSContextRef ctx, JSValue* value) {
            return JSValueMakeNumber(ctx, value->data_.d);
        }

        inline static JSValueRef ConvertToJSBoolean(JSContextRef ctx, JSValue* value) {
            return JSValueMakeBoolean(ctx, value->data_.b);
        }

        inline static JSValueRef ConvertToJSString(JSContextRef ctx, JSValue* value) {
            JSStringRef str = JSStringCreateWithUTF8CString(value->data_.str);
            JSValueRef result = JSValueMakeString(ctx, str);
            JSStringRelease(str);
            return result;
        }
    };
}

#endif // LYNX_RUNTIME_JSC_JSC_HELPER_H_
