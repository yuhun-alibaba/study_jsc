// Copyright 2017 The Lynx Authors. All rights reserved.

#include <runtime/js_value.h>
#include "runtime/jsc/objects/target_object.h"
#include "jsc_helper.h"

#include "runtime/jsc/jsc_context.h"

namespace jscore {

    JSValueRef JSCHelper::ConvertToJSString(JSContextRef ctx, const std::string &s) {
        JSStringRef ref = JSStringCreateWithUTF8CString(s.c_str());
        JSValueRef result = JSValueMakeString(ctx, ref);
        JSStringRelease(ref);
        return result;
    }

    JSValueRef JSCHelper::ConvertToJSString(JSContextRef ctx, const char* s) {
        JSStringRef ref = JSStringCreateWithUTF8CString(s);
        JSValueRef result = JSValueMakeString(ctx, ref);
        JSStringRelease(ref);
        return result;
    }


    std::string JSCHelper::ConvertToString(JSContextRef ctx, JSStringRef value) {
        std::string str;
        size_t len = JSStringGetMaximumUTF8CStringSize(value);
        char* ch = new char[len];
        JSStringGetUTF8CString(value, ch, len);
        str = ch;
        delete[] ch;
        return str;
    }
    
    std::string JSCHelper::ConvertToString(JSContextRef ctx, JSValueRef value) {
        std::string str;
        if(JSValueIsString(ctx, value) || JSValueIsObject(ctx, value)) {
            JSStringRef js_str = JSValueToStringCopy(ctx, value, NULL);
            size_t len = JSStringGetMaximumUTF8CStringSize(js_str);
            char* ch = new char[len];
            JSStringGetUTF8CString(js_str, ch, len);
            str = ch;
            delete[] ch;
            JSStringRelease(js_str);
        }
        return str;
    }

    JSValue* JSCHelper::ConvertToValue(JSContextRef ctx, JSValueRef value) {
        JSValue* js_value = 0;
        if (JSValueIsBoolean(ctx, value)) {
            js_value = JSValue::MakeBool(JSValueToBoolean(ctx, value));
        } else if (JSValueIsNumber(ctx, value)) {
            js_value = JSValue::MakeDouble(JSValueToNumber(ctx, value, NULL));
        } else if (JSValueIsObject(ctx, value)) {
            js_value = ConvertToObject(ctx, (JSObjectRef) value);
        } else if (JSValueIsArray(ctx, value)) {
            js_value = ConvertToArray(ctx, (JSObjectRef) value);
        } else if (JSValueIsString(ctx, value)) {
            js_value = JSValue::MakeString(ConvertToString(ctx, value));
        }
        return js_value;
    }

    JSArray* JSCHelper::ConvertToArray(JSContextRef ctx, JSObjectRef value) {
        JSArray* array = new JSArray;
        int length = JSObjectGetArrayBufferByteLength(ctx, value, NULL);
        for (int i = 0; i < length; ++i) {
            JSValueRef temp = JSObjectGetPropertyAtIndex(ctx, value, i, NULL);
            array->Push(ConvertToValue(ctx, temp));
        }
        return array;
    }

    JSArray* JSCHelper::ConvertToArray(JSContextRef ctx, JSValueRef* value, int length) {
        JSArray* array = new JSArray();
        for (int i = 0; i < length; ++i) {
            array->Push(ConvertToValue(ctx, value[i]));
        }
        return array;
    }

    JSObject* JSCHelper::ConvertToObject(JSContextRef ctx, JSObjectRef value) {
        return 0;
    }

    JSValueRef JSCHelper::ConvertToJSValue(JSContextRef ctx, jscore::JSValue* value) {
        JSValueRef js_obj = NULL;
        if (value == 0) {
            return JSValueMakeNull(ctx);
        }
        switch (value->type_) {
            case JSValue::Type::VALUE_INT:
                js_obj = ConvertToJSInt(ctx, value);
                break;
            case JSValue::Type::VALUE_LONG:
                js_obj = ConvertToJSLong(ctx, value);
                break;
            case JSValue::Type::VALUE_FLOAT:
                js_obj = ConvertToJSFloat(ctx, value);
                break;
            case JSValue::Type::VALUE_DOUBLE:
                js_obj = ConvertToJSDouble(ctx, value);
                break;
            case JSValue::Type::VALUE_BOOL:
                js_obj = ConvertToJSBoolean(ctx, value);
                break;
            case JSValue::Type::VALUE_STRING:
                js_obj = ConvertToJSString(ctx, value);
                break;
            case JSValue::Type::VALUE_JS_ARRAY:
                js_obj = ConvertToJSArray(ctx, value->data_.js_array);
                break;
            case JSValue::Type::VALUE_JS_OBJECT:
                js_obj = ConvertToJSObject(ctx, value->data_.js_object);
                break;
            case JSValue::Type::VALUE_JS_TARGET_OBJECT:
                js_obj = ConvertToJSTargetObject(ctx, value->data_.js_target_object);
                break;
            case JSValue::Type::VALUE_OBJECT_WRAP:
                js_obj = ConvertToObjectWrap(ctx, value->data_.object_wrap);
                break;
            case JSValue::Type::VALUE_NULL:
                js_obj = JSValueMakeNull(ctx);
                break;
            default:
                js_obj = JSValueMakeUndefined(ctx);
                break;
        }
        return js_obj;
    }

    JSValueRef* JSCHelper::ConvertToJSValueRefArray(JSContextRef ctx, jscore::JSArray* args) {
        int length = args->Size();
        int i = 0;
        JSValueRef* values = new JSValueRef[length];
        for (; i < length; ++i) {
            jscore::JSValue* arg = args->Get(i);
            JSValueRef object = ConvertToJSValue(ctx, arg);
            values[i] = object;
        }
        return values;
    }

    JSObjectRef JSCHelper::ConvertToJSArray(JSContextRef ctx, jscore::JSArray* args) {
        JSValueRef* array = ConvertToJSValueRefArray(ctx, args);
        JSObjectRef js_obj = JSObjectMakeArray(ctx, args->Size(), array, NULL);
        delete[] array;
        return js_obj;
    }

    JSObjectRef JSCHelper::ConvertToJSObject(JSContextRef ctx, JSObject* object) {
        JSObjectRef v8_obj = JSObjectMake(ctx, NULL, NULL);
        if (object != NULL) {
            for (int i = 0; i < object->Size(); ++i) {
                std::string name = object->GetName(i);
                JSStringRef str_ref = JSStringCreateWithUTF8CString(name.c_str());
                JSValueRef property = ConvertToJSValue(ctx, object->GetProperty(name));
                JSObjectSetProperty(ctx, v8_obj, str_ref, property, kJSClassAttributeNone, NULL);
                JSStringRelease(str_ref);
            }
        }
        return v8_obj;
    }

    JSObjectRef JSCHelper::ConvertToJSTargetObject(JSContextRef ctx, JSTargetObject* object) {
        JSCContext* context = static_cast<JSCContext*>(JSObjectGetPrivate(JSContextGetGlobalObject(ctx)));
        ClassWrap* class_wrap = context->context_storage()->GetClassWrap(object->class_name());
        if (class_wrap == 0) {
            class_wrap = context->context_storage()->CreateClassWrap(object->class_name());
            TargetObject::BindingClass(class_wrap, object);
        }
        JSObjectRef v8_obj = TargetObject::Create(context, class_wrap, object);
        return v8_obj;
    }

    JSObjectRef JSCHelper::ConvertToObjectWrap(JSContextRef ctx, ObjectWrap* object) {
        return object->object_ref();
    }
}
