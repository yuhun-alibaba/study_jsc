// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JSC_JSC_CONTEXT_H_
#define LYNX_RUNTIME_JSC_JSC_CONTEXT_H_

#include "runtime/js_context.h"
#include "runtime/jsc/jsc_runtime.h"
#include "runtime/jsc/jsc_class_wrap_storage.h"
#include <JavaScriptCore/JavaScript.h>

namespace jscore {
    
    class History;
    class Location;
    class ClassWrap;
    
    class JSCContext : public JSContext {
    public:
        JSCContext()
        : JSContext(), class_wrap_storage_(new JSCClassWrapStorage()) {}
        
        virtual ~JSCContext();
        
        virtual void Initialize(JSVM* vm, Runtime* runtime);
        virtual void RunScript(const char* source);
        virtual void LoadUrl(const std::string& url);

        JSObjectRef MakeJSObject(const std::string& name);

        JSCClassWrapStorage* context_storage() {
            return class_wrap_storage_.Get();
        }
        
        JSGlobalContextRef GetContext() {
            return context_;
        }
    private:
        JSGlobalContextRef context_;
        base::ScopedPtr<JSCClassWrapStorage> class_wrap_storage_;
        
        History* history_;
        Location* location_;
    };
}

#endif  // LYNX_RUNTIME_JSC_JSC_CONTEXT_H_
