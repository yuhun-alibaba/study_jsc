// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/jsc/objects/target_object.h"
#include "runtime/jsc/jsc_helper.h"
#include "runtime/jsc/class_wrap.h"
#include "runtime/jsc/jsc_context.h"

namespace jscore {
    TargetObject::TargetObject(JSCContext* context, JSTargetObject* obj) : ObjectWrap(context), target_(obj) {

    }

    TargetObject::~TargetObject() {

    }

    void TargetObject::BindingClass(ClassWrap* class_wrap, JSTargetObject* object) {
        if (object != 0) {

            std::unordered_map<std::string, JSTargetObject::Field> field_map
                    = object->fields();
            for (auto it = field_map.begin(); it != field_map.end(); ++it) {
                std::string name = it->first;
                JSTargetObject::Field field = it->second;
                JSObjectGetPropertyCallback get = TargetObject::GetPropertyCallback;
                JSObjectSetPropertyCallback set = TargetObject::SetPropertyCallback;
                if (field.get_callback == 0) get = 0;
                if (field.set_callback == 0) set = 0;
                class_wrap->SetJSStaticValue(name.c_str(),
                                             get,
                                             set,
                                             NULL);
            }

            std::unordered_map<std::string, JSTargetObject::JSMethodCallback> method_map
                    = object->methods();
            for (auto it = method_map.begin(); it != method_map.end(); ++it) {
                std::string name = it->first;
                class_wrap->SetJSStaticFunction(name.c_str(), TargetObject::MethodCallback, NULL);
            }
        }
    }

    JSObjectRef TargetObject::Create(JSCContext* context, ClassWrap* class_wrap, JSTargetObject* obj) {
        TargetObject* object = new TargetObject(context, obj);
        JSObjectRef js_object = class_wrap->MakeObject(context->GetContext());
        ObjectWrap::Wrap(object, js_object);
        return js_object;
    }

    JSValueRef TargetObject::GetPropertyCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        TargetObject* obj = ObjectWrap::Unwrap<TargetObject>(object);
        std::string property_name = JSCHelper::ConvertToString(ctx, propertyName);
        base::ScopedPtr<JSValue> value = obj->target()->GetPropertyCallback(property_name);
        return JSCHelper::ConvertToJSValue(ctx, value.Get());
    }

    bool TargetObject::SetPropertyCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        TargetObject* obj = ObjectWrap::Unwrap<TargetObject>(object);
        std::string property_name = JSCHelper::ConvertToString(ctx, propertyName);
        base::ScopedPtr<JSValue> js_value(JSCHelper::ConvertToValue(ctx, value));
        obj->target()->SetPropertyCallback(property_name, js_value);
        return true;
    }

    JSValueRef TargetObject::MethodCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thisObject, size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
        TargetObject* obj = ObjectWrap::Unwrap<TargetObject>(thisObject);

        JSStringRef name_key = JSStringCreateWithUTF8CString("name");
        std::string function_name = JSCHelper::ConvertToString(ctx,
                                                               JSObjectGetProperty(ctx,
                                                                                   function,
                                                                                   name_key,
                                                                                   NULL));
        JSStringRelease(name_key);
        base::ScopedPtr<JSValue> js_value(JSCHelper::ConvertToArray(ctx, const_cast<JSValueRef*>(arguments), argumentCount));
        return JSCHelper::ConvertToJSValue(ctx, obj->target()->MethodCallback(function_name, js_value).Get());
    }

}