// Copyright 2017 The Lynx Authors. All rights reserved.

#include "navigator_object.h"
#include "runtime/jsc/jsc_context.h"

namespace jscore {
static JSValueRef GetUserAgentCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
    NavigatorObject* navigator = ObjectWrap::Unwrap<NavigatorObject>(object);
    JSStringRef str = JSStringCreateWithUTF8CString(navigator->user_agent().c_str());
    JSValueRef result = JSValueMakeString(ctx, str);
    JSStringRelease(str);
    return result;
}

static JSValueRef GetAppCodeNameCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
    NavigatorObject* navigator = ObjectWrap::Unwrap<NavigatorObject>(object);
    JSStringRef str = JSStringCreateWithUTF8CString(navigator->app_code_name().c_str());
    JSValueRef result = JSValueMakeString(ctx, str);
    JSStringRelease(str);
    return result;
}

static JSValueRef GetAppNameCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
    NavigatorObject* navigator = ObjectWrap::Unwrap<NavigatorObject>(object);
    JSStringRef str = JSStringCreateWithUTF8CString(navigator->app_name().c_str());
    JSValueRef result = JSValueMakeString(ctx, str);
    JSStringRelease(str);
    return result;
}

static JSValueRef GetPlatformCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
    NavigatorObject* navigator = ObjectWrap::Unwrap<NavigatorObject>(object);
    JSStringRef str = JSStringCreateWithUTF8CString(navigator->platform().c_str());
    JSValueRef result = JSValueMakeString(ctx, str);
    JSStringRelease(str);
    return result;
}

static JSValueRef GetAppVersionCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
    NavigatorObject* navigator = ObjectWrap::Unwrap<NavigatorObject>(object);
    JSStringRef str = JSStringCreateWithUTF8CString(navigator->app_version().c_str());
    JSValueRef result = JSValueMakeString(ctx, str);
    JSStringRelease(str);
    return result;
}

void NavigatorObject::BindingClass(ClassWrap* class_wrap) {
    
    class_wrap->SetJSClassAttributes(kJSClassAttributeNone);
    class_wrap->SetJSStaticValue("userAgent", GetUserAgentCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);
    class_wrap->SetJSStaticValue("appCodeName", GetAppCodeNameCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);
    class_wrap->SetJSStaticValue("appName", GetAppNameCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);
    class_wrap->SetJSStaticValue("platform", GetPlatformCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);
    class_wrap->SetJSStaticValue("appVersion", GetAppVersionCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);
}
    
JSObjectRef NavigatorObject::Create(JSCContext* context, ClassWrap* class_wrap) {
    NavigatorObject* navigator = new NavigatorObject(context);
    JSObjectRef object = class_wrap->MakeObject(context->GetContext());
    ObjectWrap::Wrap(navigator, object);
    return object;
}
}
