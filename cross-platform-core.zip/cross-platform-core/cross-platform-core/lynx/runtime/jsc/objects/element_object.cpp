// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/jsc/objects/element_object.h"

#include <sstream>

#include "runtime/jsc/jsc_helper.h"
#include "runtime/jsc/jsc_context.h"
#include "config/global_config_data.h"
#include "runtime/jsc/jsc_function.h"
#include "base/print.h"

namespace jscore {
    static int ElementObjectCount = 0;
    ElementObject::ElementObject(JSContext* context, lynx::RenderObject* render_object)
        : ObjectWrap(context), render_object_(render_object) {
        render_object->SetJSRef(static_cast<void *>(this));
        LOGD("lynx-debug", "construct ElementObjectCount: %d", ++ElementObjectCount);

    }
    
    ElementObject::~ElementObject() {
        LOGD("lynx-debug", "destruct ElementObjectCount: %d", --ElementObjectCount);
    }
    
    static JSValueRef AppendChildCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                          size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        //LOGD("lynx-debug", "%s:%s", __FILE__, __FUNCTION__);
        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0]) ) {

            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            lynx::RenderObject* child = ObjectWrap::Unwrap<ElementObject>((JSObjectRef)argv[0])->render_object_.Get();
            render_object->AppendChild(child);

            ElementObject::ProtectChild(ctx, (JSObjectRef)argv[0]);
        }
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef AppendChildrenCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                             size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0]) ) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            //lynx::RenderObject* child = static_cast<lynx::RenderObject*>(JSObjectGetPrivate((JSObjectRef)argv[0]));
            //render_object->AppendChild(child);
            int index = 0;
            while(true) {
                JSValueRef child = JSObjectGetPropertyAtIndex(ctx, JSValueToObject(ctx, argv[0], NULL), index++, NULL);
                if(JSValueIsNull(ctx, child) || JSValueIsUndefined(ctx, child)) break;
                lynx::RenderObject* render_child = ObjectWrap::Unwrap<ElementObject>((JSObjectRef)child)->render_object_.Get();
                render_object->AppendChild(render_child);

                ElementObject::ProtectChild(ctx, (JSObjectRef)child);
            }
        }
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef InsertChildAtIndexCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                                 size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0])
            && !JSValueIsNull(ctx, argv[1]) && !JSValueIsUndefined(ctx, argv[1])) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            lynx::RenderObject* child = ObjectWrap::Unwrap<ElementObject>((JSObjectRef)argv[0])->render_object_.Get();
            int index = (int) JSValueToNumber(ctx, argv[1], NULL);
            render_object->InsertChild(child, index);

            ElementObject::ProtectChild(ctx, (JSObjectRef)child);
        }
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef RemoveChildByIndexCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                                 size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0])) {
            lynx::RenderObject* render_parent = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            int index = (int) JSValueToNumber(ctx, argv[0], NULL);
            lynx::RenderObject* render_child = const_cast<lynx::RenderObject*>(
                    render_parent->Get(index));
            JSObjectRef child = static_cast<ElementObject*>(render_child->GetJSRef())->object_ref();

            render_parent->RemoveChild(render_child);
            ElementObject::UnprotectChild(ctx, child);
        }
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef InsertBeforeCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                           size_t argc, const JSValueRef argv[], JSValueRef *exception) {

        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0])) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            lynx::RenderObject* child = ObjectWrap::Unwrap<ElementObject>((JSObjectRef)argv[0])->render_object_.Get();
            if (!JSValueIsNull(ctx, argv[1]) && !JSValueIsUndefined(ctx, argv[1])) {
                lynx::RenderObject* reference = ObjectWrap::Unwrap<ElementObject>((JSObjectRef)argv[1])->render_object_.Get();
                render_object->InsertBefore(child, reference);
            } else {
                render_object->AppendChild(child);
            }

            ElementObject::ProtectChild(ctx, (JSObjectRef)argv[0]);
        }
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef RemoveChildCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                          size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0]) ) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            lynx::RenderObject* child = ObjectWrap::Unwrap<ElementObject>((JSObjectRef)argv[0])->render_object_.Get();
            render_object->RemoveChild(child);
            ElementObject::UnprotectChild(ctx, (JSObjectRef)argv[0]);
        }
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef GetChildByIndexCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                              size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0]) ) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            int index = (int) JSValueToNumber(ctx, argv[0], NULL);
            lynx::RenderObject* child = const_cast<lynx::RenderObject*>(render_object->Get(index));
            if(child) {
                return static_cast<JSValueRef>(child->GetJSRef());
            }
        }
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef AddEventListenerCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                               size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        //return JSValueMakeNull(ctx);
        if (!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0]) &&
                !JSValueIsNull(ctx, argv[1]) && !JSValueIsUndefined(ctx, argv[1]) ) {
            JSCContext* context = static_cast<JSCContext*>(JSObjectGetPrivate(JSContextGetGlobalObject(ctx)));
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            std::string event = JSCHelper::ConvertToString(ctx, argv[0]);
            bool capture = false;
            if (JSValueIsBoolean(ctx, argv[2])) {
                capture = JSValueToBoolean(ctx, argv[2]);
            }
            JSCFunction* jsc_function = new JSCFunction(context, thiz, (JSObjectRef) argv[1]);
            render_object->AddEventListener(event, jsc_function, capture);
        }
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef RemoveEventListenerCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                                  size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if (!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0]) &&
            !JSValueIsNull(ctx, argv[1]) && !JSValueIsUndefined(ctx, argv[1]) ) {
            JSCContext* context = static_cast<JSCContext*>(JSObjectGetPrivate(JSContextGetGlobalObject(ctx)));
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            std::string event = JSCHelper::ConvertToString(ctx, argv[0]);
            JSCFunction* jsc_function = new JSCFunction(context, thiz, (JSObjectRef) argv[1]);
            render_object->RemoveEventListener(event, jsc_function);
        }
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef SetAttributionCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                             size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
        JSObjectRef obj = JSValueToObject(ctx, argv[0], NULL);
        JSPropertyNameArrayRef names = JSObjectCopyPropertyNames(ctx, obj);
        size_t len = JSPropertyNameArrayGetCount(names);
        for(int i = 0; i < len; ++i) {
            JSStringRef key = JSPropertyNameArrayGetNameAtIndex(names, i);
            std::string key_str = JSCHelper::ConvertToString(ctx, key);
            JSValueRef value = JSObjectGetProperty(ctx, obj, key, NULL);
            std::string value_str = JSCHelper::ConvertToString(ctx, value);
            render_object->SetAttribute(key_str, value_str);
        }
        JSPropertyNameArrayRelease(names);
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef SetAttributeCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                           size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(argc == 2 && !JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0])
           && !JSValueIsNull(ctx, argv[1]) && !JSValueIsUndefined(ctx, argv[1])) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            render_object->SetAttribute(JSCHelper::ConvertToString(ctx, argv[0]), JSCHelper::ConvertToString(ctx, argv[1]));
        }
        return JSValueMakeUndefined(ctx);
    }

    static JSValueRef HasAttributeCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                           size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(argc == 1 && !JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0])) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            return JSValueMakeBoolean(ctx, render_object->HasAttribute(JSCHelper::ConvertToString(ctx, argv[0])));
        }
        return JSValueMakeBoolean(ctx, false);
    }

    static JSValueRef RemoveAttributeCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                           size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(argc == 1 && !JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0])) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            render_object->RemoveAttribute(JSCHelper::ConvertToString(ctx, argv[0]));
        }
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef SetStyleCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                       size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
        JSObjectRef obj = JSValueToObject(ctx, argv[0], NULL);
        JSPropertyNameArrayRef names = JSObjectCopyPropertyNames(ctx, obj);
        size_t len = JSPropertyNameArrayGetCount(names);
        for(int i = 0; i < len; ++i) {
            std::string value_str;
            JSStringRef key = JSPropertyNameArrayGetNameAtIndex(names, i);
            std::string key_str = JSCHelper::ConvertToString(ctx, key);
            JSValueRef value = JSObjectGetProperty(ctx, obj, key, NULL);
            if(JSValueIsString(ctx, value)) {
                value_str = JSCHelper::ConvertToString(ctx, value);
                render_object->SetStyle(key_str, value_str);
            }else if(JSValueIsNumber(ctx, value)) {
                int number = JSValueToNumber(ctx, value, NULL);
                std::stringstream stream;
                stream<<number;
                render_object->SetStyle(key_str, stream.str());
            }
        }
        JSPropertyNameArrayRelease(names);
        render_object->SetStyle("", "");
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef SetTextCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                      size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0]) ) {
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            std::string text = JSCHelper::ConvertToString(ctx, argv[0]);
            render_object->SetText(text);
        }
        return JSValueMakeUndefined(ctx);
    }
    
    static JSValueRef GetTextCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                      size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
        JSStringRef str = JSStringCreateWithUTF8CString(render_object->GetText().c_str());
        JSValueRef result = JSValueMakeString(ctx, str);
        JSStringRelease(str);
        return result;
    }
    
    static JSValueRef GetNodeTypeCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        return JSValueMakeNumber(ctx, 1);
    }
    
    static JSValueRef GetParentNodeCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        lynx::RenderObject* parent = const_cast<lynx::RenderObject*>(render_object->Parent());
        if(parent) {
            return static_cast<ElementObject*>(parent->GetJSRef())->object_ref();
        }
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef GetNextSiblingCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        lynx::RenderObject* next = render_object->NextSibling();
        if(next) {
            return static_cast<ElementObject*>(next->GetJSRef())->object_ref();
        }
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef GetTagNameCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        JSStringRef str = JSStringCreateWithUTF8CString(render_object->tag_name().c_str());
        JSValueRef result = JSValueMakeString(ctx, str);
        JSStringRelease(str);
        return result;
    }
    
    static JSValueRef GetOffsetTopCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        return JSValueMakeNumber(ctx, render_object->offset_top());
    }
    
    static JSValueRef GetOffsetLeftCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        return JSValueMakeNumber(ctx, render_object->offset_left());
    }
    
    static JSValueRef GetOffsetWidthCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        return JSValueMakeNumber(ctx, render_object->offset_width());
    }
    
    static JSValueRef GetOffsetHeightCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        return JSValueMakeNumber(ctx, render_object->offset_height());
    }
    
    static JSValueRef GetScrollWidthCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        return JSValueMakeNumber(ctx, render_object->scroll_width());
    }
    
    static JSValueRef GetScrollHeightCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        return JSValueMakeNumber(ctx, render_object->scroll_height());
    }
    
    static bool SetScrollTopCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        int scroll_top = (int) JSValueToNumber(ctx, value, NULL);
        render_object->set_offset_top(scroll_top);
        return true;
    }
    
    static JSValueRef GetScrollTopCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        return JSValueMakeNumber(ctx, render_object->scroll_top());
    }
    
    static bool SetScrollLeftCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        int scroll_left = (int) JSValueToNumber(ctx, value, NULL);
        render_object->set_offset_top(scroll_left);
        return true;
    }
    
    static JSValueRef GetScrollLeftCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        return JSValueMakeNumber(ctx, render_object->scroll_left());
    }

    static JSValueRef GetChildNodesCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(object)->render_object_.Get();
        lynx::RenderObject* render_child = static_cast<lynx::RenderObject*>(render_object->FirstChild());

        if(render_object->GetChildCount() == 0) {
            return JSObjectMakeArray(ctx, render_object->GetChildCount(), NULL, NULL);
        }
        JSValueRef* values = new JSValueRef[render_object->GetChildCount()];
        int index = 0;
        while (render_child) {
            JSObjectRef obj = render_child->IsPrivate() ?
                              ElementObject::ToJSObjectRef(ctx, static_cast<lynx::RenderObject*>(render_child->FirstChild())) :
                              ElementObject::ToJSObjectRef(ctx, render_child);
            values[index] = (JSValueRef)obj;
            ++index;
            render_child = static_cast<lynx::RenderObject*>(render_child->Next());
        }
        JSObjectRef children = JSObjectMakeArray(ctx, render_object->GetChildCount(), values, NULL);
        delete[] values;
        return children;
    }
    
    static bool SetForceScrollAnimateCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        return false;
    }
    
    static JSValueRef GetIndexCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef StartCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                    size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef StopCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                   size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef SetPullViewCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                          size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef ClosePullViewCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                            size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef StopAnimateCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                          size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef StartAnimateWithCallbackCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                                       size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static std::vector<JSStaticFunction> s_element_functions_ = {
        {"appendChild", AppendChildCallback, kJSClassAttributeNone},
        {"appendChildren", AppendChildrenCallback, kJSClassAttributeNone},
        {"insertChildAtIndex", InsertChildAtIndexCallback, kJSClassAttributeNone},
        {"removeChildByIndex", RemoveChildByIndexCallback, kJSClassAttributeNone},
        {"insertBefore", InsertBeforeCallback, kJSClassAttributeNone},
        {"removeChild", RemoveChildCallback, kJSClassAttributeNone},
        {"getChildByIndex", GetChildByIndexCallback, kJSClassAttributeNone},
        {"addEventListener", AddEventListenerCallback, kJSClassAttributeNone},
        {"removeEventListener", RemoveEventListenerCallback, kJSClassAttributeNone},
        {"setAttribution", SetAttributionCallback, kJSClassAttributeNone},
        {"setAttribute", SetAttributeCallback, kJSClassAttributeNone},
        {"hasAttribute", HasAttributeCallback, kJSClassAttributeNone},
        {"removeAttribute", RemoveAttributeCallback, kJSClassAttributeNone},
        {"setStyle", SetStyleCallback, kJSClassAttributeNone},
        {"setText", SetTextCallback, kJSClassAttributeNone},
        {"getText", GetTextCallback, kJSClassAttributeNone},
        {"start", StartCallback, kJSClassAttributeNone},
        {"stop", StopCallback, kJSClassAttributeNone},
        {"stopAnimate", StopAnimateCallback, kJSClassAttributeNone},
        {"startAnimateWithCallback", StartAnimateWithCallbackCallback, kJSClassAttributeNone},
        {"setPullView", SetPullViewCallback, kJSClassAttributeNone},
        {"closePullView", ClosePullViewCallback, kJSClassAttributeNone},
    };
    
    static std::vector<JSStaticValue> s_element_values_ = {
        {"tagName", GetTagNameCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"nodeType", GetNodeTypeCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"parentNode", GetParentNodeCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"offsetTop", GetOffsetTopCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"offsetLeft", GetOffsetLeftCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"offsetWidth", GetOffsetWidthCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"offsetHeight", GetOffsetHeightCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"scrollWidth", GetScrollWidthCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"scrollHeight", GetScrollHeightCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"scrollTop", GetScrollTopCallback, SetScrollTopCallback,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"scrollLeft", GetScrollLeftCallback, SetScrollLeftCallback,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"nextSibling", GetNextSiblingCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"forceScrollAnimate", NULL, SetForceScrollAnimateCallback,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"childNodes", GetChildNodesCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"index", GetIndexCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
    };
    
    void ElementObject::BindingClass(ClassWrap* class_wrap) {
        class_wrap->SetJSClassAttributes(kJSClassAttributeNone);
        int i = 0;
        for (; i < s_element_values_.size(); ++i) {
            class_wrap->SetJSStaticValue(s_element_values_[i]);
        }
        for (i = 0; i < s_element_functions_.size(); ++i) {
            class_wrap->SetJSStaticFunction(s_element_functions_[i]);
        }
    }
    
    JSObjectRef ElementObject::Create(JSCContext *context, lynx::RenderObject *render_object) {
        if(render_object == NULL)
            return (JSObjectRef)JSValueMakeNull(context->GetContext());
        ElementObject* element = new ElementObject(context, render_object);
        JSObjectRef object = context->context_storage()->GetClassWrap("Element")->MakeObject(context->GetContext());
        ObjectWrap::Wrap(element, object);
        return object;
    }

    void ElementObject::ProtectChild(JSContextRef ctx, JSObjectRef obj) {
        JSValueProtect(ctx, obj);
    }

    void ElementObject::UnprotectChild(JSContextRef ctx, JSObjectRef obj) {
        JSValueUnprotect(ctx, obj);
        lynx::RenderObject* renderer = ObjectWrap::Unwrap<ElementObject>(obj)->render_object_.Get();
        lynx::RenderObject* child = static_cast<lynx::RenderObject*>(renderer->FirstChild());
        while(child) {
            UnprotectChild(ctx, ToJSObjectRef(ctx, child));
            child = static_cast<lynx::RenderObject*>(renderer->Next());
        }
    }


    JSObjectRef ElementObject::ToJSObjectRef(JSContextRef ctx, lynx::RenderObject* renderer) {
        if(renderer && renderer->GetJSRef()) {
            return static_cast<jscore::ElementObject*>(renderer->GetJSRef())->object_ref();
        }
        return (JSObjectRef)JSValueMakeNull(ctx);
    }
}
