// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef console_object_hpp
#define console_object_hpp

#include <JavaScriptCore/JavaScript.h>

namespace jscore {
    
    class ClassWrap;
    class JSCContext;
    
    class ConsoleObject {
        public:
        static void BindingClass(ClassWrap* class_wrap);
        static JSObjectRef Create(JSCContext* context, ClassWrap* class_wrap);
        
    };
}

#endif /* console_object_hpp */
