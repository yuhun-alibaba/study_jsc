// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JSC_OBJECTS_NAVIGATOR_OBJECT_H_
#define LYNX_RUNTIME_JSC_OBJECTS_NAVIGATOR_OBJECT_H_

#include <JavaScriptCore/JavaScript.h>
#include "runtime/navigator.h"
#include "runtime/jsc/object_wrap.h"

namespace jscore {
    
    class ClassWrap;
    class JSCContext;
    
    class NavigatorObject : public Navigator , public ObjectWrap {
        public:
        NavigatorObject(JSContext* context) : Navigator(), ObjectWrap(context) {}
        virtual ~NavigatorObject() {}
        static void BindingClass(ClassWrap* class_wrap);
        static JSObjectRef Create(JSCContext* context, ClassWrap* class_wrap);
    };
}

#endif  // LYNX_RUNTIME_JSC_OBJECTS_NAVIGATOR_OBJECT_H_

