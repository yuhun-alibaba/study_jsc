// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JSC_OBJECTS_BODY_OBJECT_H_
#define LYNX_RUNTIME_JSC_OBJECTS_BODY_OBJECT_H_


#include <JavaScriptCore/JavaScript.h>
#include "runtime/jsc/objects/element_object.h"

namespace jscore {
    
    class JSCContext;
    class ClassWrap;
    
    class BodyObject : public ElementObject {
    public:
        static void BindingClass(ClassWrap* class_wrap);
        static JSObjectRef Create(JSCContext* context, ClassWrap* class_wrap);
    protected:
        explicit BodyObject(JSContext* context, lynx::RenderObject* render_object);
        virtual ~BodyObject();
    };
}

#endif  // LYNX_RUNTIME_JSC_OBJECTS_BODY_OBJECT_H_

