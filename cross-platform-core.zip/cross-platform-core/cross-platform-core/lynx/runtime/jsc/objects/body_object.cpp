// Copyright 2017 The Lynx Authors. All rights reserved.

#include "body_object.h"

#include "config/global_config_data.h"
#include "runtime/jsc/jsc_context.h"

namespace jscore {
    
    BodyObject::BodyObject(JSContext* context, lynx::RenderObject* render_object) : ElementObject(context, render_object) {
        
    }
    
    BodyObject::~BodyObject() {
        
    }
    
    static JSValueRef GetClientWidthCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        int width = config::GlobalConfigData::GetInstance()->screen_width();
        return JSValueMakeNumber(ctx, width);
    }
    
    static JSValueRef GetClientHeightCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        int height = config::GlobalConfigData::GetInstance()->screen_height();
        return JSValueMakeNumber(ctx, height);
    }
    
    void BodyObject::BindingClass(ClassWrap* class_wrap) {
        ElementObject::BindingClass(class_wrap);
        class_wrap->SetJSStaticValue("clientWidth", GetClientWidthCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);
        class_wrap->SetJSStaticValue("clientHeight", GetClientHeightCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);
    }
    
    JSObjectRef BodyObject::Create(JSCContext* context, ClassWrap* class_wrap) {
        lynx::RenderObject* render_root = context->runtime()->render_tree_host()->render_root();
        BodyObject* body = new BodyObject(context, render_root);
        JSObjectRef object = class_wrap->MakeObject(context->GetContext());
        ObjectWrap::Wrap(body, object);
        return object;
    }
    
}
