// Copyright 2017 The Lynx Authors. All rights reserved.

#include "screen_object.h"

#include "config/global_config_data.h"
#include "runtime/jsc/jsc_context.h"

namespace jscore {
    
    static JSValueRef GetWidthCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        int width = config::GlobalConfigData::GetInstance()->screen_width();
        return JSValueMakeNumber(ctx, width);
    }
    
    static JSValueRef GetHeightCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        int height = config::GlobalConfigData::GetInstance()->screen_height();
        return JSValueMakeNumber(ctx, height);
    }
    
    static JSStaticValue s_screen_values_[] = {
        {"width", GetWidthCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"height", GetHeightCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        { 0, 0, 0, 0}
    };
    
    void ScreenObject::BindingClass(ClassWrap* class_wrap) {
        class_wrap->SetJSClassAttributes(kJSClassAttributeNone);
        class_wrap->SetJSStaticValues(s_screen_values_);
    }
    
    JSObjectRef ScreenObject::Create(JSCContext* context, ClassWrap* class_wrap) {
        return class_wrap->MakeObject(context->GetContext());
    }
}
