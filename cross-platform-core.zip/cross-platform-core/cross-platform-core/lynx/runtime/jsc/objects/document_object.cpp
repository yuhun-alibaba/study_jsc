// Copyright 2017 The Lynx Authors. All rights reserved.

#include "document_object.h"

#include "base/string/string16.h"
#include "render/render_factory.h"
#include "runtime/jsc/jsc_helper.h"
#include "runtime/jsc/jsc_context.h"
#include "runtime/jsc/objects/element_object.h"

namespace jscore {
    
    static JSValueRef GetDomainCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef GetCookieCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        JSStringRef str = JSStringCreateWithUTF8CString("");
        JSValueRef cookie = JSValueMakeString(ctx, str);
        JSStringRelease(str);
        return cookie;
    }
    
    static JSValueRef GetReadyStateCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        return JSValueMakeNull(ctx);
    }
    
    static bool SetDomainCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        return true;
    }
    
    static bool SetCookieCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        return true;
    }
    
    static bool SetOnTouchStartCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        return true;
    }
    
    static bool SetOnTouchEndCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        return true;
    }
    
    static bool SetOnTouchMoveCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef value, JSValueRef* exception) {
        return true;
    }
    
    static JSValueRef CreateElementCallback(JSContextRef ctx,JSObjectRef function,JSObjectRef thisObject,size_t argumentCount, const JSValueRef arguments[],JSValueRef *exception) {
        JSCContext* context = static_cast<JSCContext*>(JSObjectGetPrivate(thisObject));
        std::string tag_name = JSCHelper::ConvertToString(ctx, arguments[0]);
        lynx::RenderObject* render_object = lynx::RenderFactory::CreateRenderObject(context->runtime()->thread_manager(), tag_name, context->runtime()->render_tree_host());
        JSObjectRef element = ElementObject::Create(context, render_object);
        return element;
    }

    static JSValueRef GetElementByIdCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                             size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        if(!JSValueIsNull(ctx, argv[0]) && !JSValueIsUndefined(ctx, argv[0]) ) {
            JSCContext* context = static_cast<JSCContext*>(JSObjectGetPrivate(thiz));
            lynx::RenderObject* render_object = ObjectWrap::Unwrap<ElementObject>(thiz)->render_object_.Get();
            std::string id = JSCHelper::ConvertToString(ctx, argv[0]);
            JSObjectRef obj = ElementObject::ToJSObjectRef(ctx, context->runtime()->render_tree_host()->GetElementById(id));
            return obj;
        }
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef CreateDomCallback(JSContextRef ctx,JSObjectRef function,JSObjectRef thisObject,size_t argumentCount, const JSValueRef arguments[],JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef AddEventListenerCallback(JSContextRef ctx,JSObjectRef function,JSObjectRef thisObject,size_t argumentCount, const JSValueRef arguments[],JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef RemoveEventListenerCallback(JSContextRef ctx,JSObjectRef function,JSObjectRef thisObject,size_t argumentCount, const JSValueRef arguments[],JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef DispatchEventCallback(JSContextRef ctx,JSObjectRef function,JSObjectRef thisObject,size_t argumentCount, const JSValueRef arguments[],JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef CreateEventCallback(JSContextRef ctx,JSObjectRef function,JSObjectRef thisObject,size_t argumentCount, const JSValueRef arguments[],JSValueRef *exception) {
        return JSValueMakeNull(ctx);
    }
    
    static JSStaticValue s_document_values_[] = {
        {"domain", GetDomainCallback, SetDomainCallback,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"cookie", GetCookieCallback, SetCookieCallback,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"readyState", GetReadyStateCallback, NULL,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"ontouchstart", NULL, SetOnTouchStartCallback,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"ontouchend", NULL, SetOnTouchEndCallback,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"ontouchmove", NULL, SetOnTouchMoveCallback,  kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {0, 0, 0, 0}
    };
    
    static JSStaticFunction s_document_functions_[] = {
        {"createElement", CreateElementCallback, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"createDom", CreateDomCallback, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"addEventListener", AddEventListenerCallback, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"removeEventListener", RemoveEventListenerCallback, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"dispatchEvent", DispatchEventCallback, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"createEvent", CreateEventCallback, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        {"getElementById", GetElementByIdCallback, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete},
        { 0, 0, 0}
    };
    
    void DocumentObject::BindingClass(ClassWrap* class_wrap) {
        class_wrap->SetJSClassAttributes(kJSClassAttributeNone);
        class_wrap->SetJSStaticFunctions(s_document_functions_);
        class_wrap->SetJSStaticValues(s_document_values_);
    }
    
    JSObjectRef DocumentObject::Create(JSCContext* context, ClassWrap* class_wrap) {
        return class_wrap->MakeObject(context->GetContext(), context);
    }
}
