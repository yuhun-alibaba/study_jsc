// Copyright 2017 The Lynx Authors. All rights reserved.

#include <iostream>

#include "runtime/jsc/objects/console_object.h"
#include "runtime/jsc/jsc_context.h"
#include "runtime/jsc/jsc_helper.h"
#include "base/string/string16.h"
#include "base/print.h"

namespace jscore {
    
    static JSValueRef LogCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                          size_t argc, const JSValueRef argv[], JSValueRef *exception) {        
        std::string str = JSCHelper::ConvertToString(ctx, argv[0]);
        LOGD("lynx-js-console", "%s", str.c_str());
        return JSValueMakeNull(ctx);
    }
    
    void ConsoleObject::BindingClass(ClassWrap* class_wrap) {
        class_wrap->SetJSClassAttributes(kJSClassAttributeNone);
        class_wrap->SetJSStaticFunction("log", LogCallback, kJSClassAttributeNone);
        class_wrap->SetJSStaticFunction("warn", LogCallback, kJSClassAttributeNone);
        class_wrap->SetJSStaticFunction("error", LogCallback, kJSClassAttributeNone);
    }
    
    JSObjectRef ConsoleObject::Create(JSCContext* context, ClassWrap* class_wrap) {
        return class_wrap->MakeObject(context->GetContext());
    }
}
