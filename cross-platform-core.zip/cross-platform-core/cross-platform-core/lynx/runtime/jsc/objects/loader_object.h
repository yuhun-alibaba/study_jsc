// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JSC_OBJECTS_LOADER_OBJECT_H_
#define LYNX_RUNTIME_JSC_OBJECTS_LOADER_OBJECT_H_

#include "runtime/loader.h"
#include "runtime/jsc/object_wrap.h"
#include <JavaScriptCore/JavaScript.h>

namespace jscore {
    
    class JSCContext;
    class ClassWrap;
    
    class LoaderObject : public Loader , public ObjectWrap {
    public:
        LoaderObject(JSCContext* context);
        virtual ~LoaderObject() {}
        static void BindingClass(ClassWrap* class_wrap);
        static JSObjectRef Create(JSCContext* context, ClassWrap* class_wrap);
    };
}

#endif // LYNX_RUNTIME_JSC_OBJECTS_LOADER_OBJECT_H_
