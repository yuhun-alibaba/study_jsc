// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef element_hpp
#define element_hpp

#include <JavaScriptCore/JavaScript.h>
#include <runtime/js_object.h>
#include "runtime/jsc/object_wrap.h"
#include "base/scoped_ptr.h"
#include "render/render_object.h"

namespace jscore {
    
class JSCContext;
class ClassWrap;
    
class ElementObject : public ObjectWrap {
public:
    static void BindingClass(ClassWrap* class_wrap);
    static JSObjectRef Create(JSCContext* context, lynx::RenderObject* render_object);

    static void ProtectChild(JSContextRef ctx, JSObjectRef obj);
    static void UnprotectChild(JSContextRef ctx, JSObjectRef obj);
    static JSObjectRef ToJSObjectRef(JSContextRef ctx, lynx::RenderObject* renderer);

    base::ScopedPtr<lynx::RenderObject> render_object_;
    
//protected:
    explicit ElementObject(JSContext* context, lynx::RenderObject* render_object);
    virtual ~ElementObject();
    
};
}

#endif /* element_hpp */
