// Copyright 2017 The Lynx Authors. All rights reserved.

#include "history_object.h"

#include "runtime/jsc/jsc_helper.h"
#include "runtime/jsc/jsc_context.h"

namespace jscore {
    
    HistoryObject::HistoryObject(JSCContext* context) : History(context), ObjectWrap(context){
        
    }
    
    HistoryObject::~HistoryObject() {
        
    }
    
    static JSValueRef ForwardCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz, size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        
        HistoryObject* history = ObjectWrap::Unwrap<HistoryObject>(thiz);
        history->Forward();
        history->Load();
        
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef BackCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz, size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        
        HistoryObject* history = ObjectWrap::Unwrap<HistoryObject>(thiz);
        history->Back();
        history->Load();
        
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef GoCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz, size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        
        HistoryObject* history = ObjectWrap::Unwrap<HistoryObject>(thiz);
        if (JSValueIsNumber(ctx, argv[0])) {
            int offset = JSValueToNumber(ctx, argv[0], NULL);
            history->Go(offset);
        } else if (JSValueIsString(ctx, argv[0])) {
            std::string url = JSCHelper::ConvertToString(ctx, argv[0]);
            history->Go(url);
        }
        history->Load();
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef GetLengthCallback(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception) {
        
        HistoryObject* history = ObjectWrap::Unwrap<HistoryObject>(object);
        
        return JSValueMakeNumber(ctx, history->GetLength());
    }
    
    void HistoryObject::BindingClass(ClassWrap* class_wrap) {
        
        class_wrap->SetJSClassAttributes(kJSClassAttributeNone);
        class_wrap->SetJSStaticFunction("forward", ForwardCallback, kJSClassAttributeNone);
        class_wrap->SetJSStaticFunction("back", BackCallback, kJSClassAttributeNone);
        class_wrap->SetJSStaticFunction("go", GoCallback, kJSClassAttributeNone);
        class_wrap->SetJSStaticValue("length", GetLengthCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);
    }
    
    JSObjectRef HistoryObject::Create(JSCContext* context, ClassWrap* class_wrap) {
        HistoryObject* history = new HistoryObject(context);
        JSObjectRef object = class_wrap->MakeObject(context->GetContext());
        ObjectWrap::Wrap(history, object);
        return object;
    }
    
}
