// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/jsc/objects/loader_object.h"
#include "runtime/jsc/jsc_helper.h"
#include "runtime/jsc/jsc_function.h"
#include "runtime/jsc/jsc_context.h"
#include "runtime/jsc/class_wrap.h"
#include "base/scoped_ptr.h"

namespace jscore {
    
    LoaderObject::LoaderObject(JSCContext* context) : Loader(context), ObjectWrap(context) {
        
    }
    
    static JSValueRef TraceCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                    size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        
        return JSValueMakeNull(ctx);
    }
    
    static JSValueRef ScriptCallback(JSContextRef ctx, JSObjectRef function, JSObjectRef thiz,
                                     size_t argc, const JSValueRef argv[], JSValueRef *exception) {
        
        LoaderObject* loader = ObjectWrap::Unwrap<LoaderObject>(thiz);
        std::string url = argc > 0 ? JSCHelper::ConvertToString(ctx, argv[0]) : NULL;
        JSCFunction* succ = argc > 1 ? new JSCFunction(static_cast<JSCContext*>(loader->context()),
                                                       JSContextGetGlobalObject(ctx),
                                                       (JSObjectRef) argv[1]) : NULL;
        JSCFunction* error = argc > 2 ? new JSCFunction(static_cast<JSCContext*>(loader->context()),
                                                        JSContextGetGlobalObject(ctx),
                                                        (JSObjectRef) argv[2]) : NULL;
        loader->Script(url, succ, error);
        return JSValueMakeNull(ctx);
    }
    
    void LoaderObject::BindingClass(ClassWrap* class_wrap) {
        class_wrap->SetJSClassAttributes(kJSClassAttributeNone);
        class_wrap->SetJSStaticFunction("trace", TraceCallback, kJSClassAttributeNone);
        class_wrap->SetJSStaticFunction("script", ScriptCallback, kJSClassAttributeNone);
    }
    
    JSObjectRef LoaderObject::Create(JSCContext* context, ClassWrap* class_wrap) {
        LoaderObject* loader = new LoaderObject(context);
        JSObjectRef object = class_wrap->MakeObject(context->GetContext());
        ObjectWrap::Wrap(loader, object);
        return object;
    }
}
