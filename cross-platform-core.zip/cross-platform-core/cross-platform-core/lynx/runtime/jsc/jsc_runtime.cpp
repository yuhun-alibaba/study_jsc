// Copyright 2017 The Lynx Authors. All rights reserved.

#import "runtime/jsc/jsc_runtime.h"


#include "loader/xc/xc_file.h"
#include "loader/xc/xc_loader.h"

#include "runtime/jsc/jsc_context.h"
#include "runtime/jsc/jsc_helper.h"

namespace jscore {
    
    JSCRuntime::JSCRuntime()
        : Runtime(new JSCContext()) {
    }
    
    JSCRuntime::~JSCRuntime() {
    }
}
