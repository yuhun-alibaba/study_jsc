// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/jsc/jsc_function.h"
#include "runtime/jsc/jsc_context.h"
#include "runtime/jsc/jsc_helper.h"
#include <sstream>

namespace jscore {
    JSCFunction::JSCFunction(JSCContext* context, JSObjectRef target, JSObjectRef function) : JSFunction(context) {
        function_key_ = reinterpret_cast<intptr_t>(function);
        JSContextRef ctx = static_cast<JSCContext*>(context_)->GetContext();
        std::stringstream stream;
        stream<<function_key_;
        JSStringRef function_key = JSStringCreateWithUTF8CString(stream.str().c_str());
        JSObjectSetProperty(ctx, target, function_key, function, kJSPropertyAttributeNone, NULL);
        JSStringRelease(function_key);
    }
    
    JSCFunction::~JSCFunction() {
    
    }
    

    void JSCFunction::Run(void* target, JSArray* args) {
        if (target == 0) {
            return;
        }
        JSContextRef ctx = static_cast<JSCContext*>(context_)->GetContext();
        JSObjectRef target_object;
        if ((intptr_t) target == (intptr_t) TargetState::Global) {
            target_object = JSContextGetGlobalObject(ctx);
        } else {
            target_object = static_cast<ObjectWrap*>(target)->object_ref();
        }

        JSValueRef* array;
        int argc = 0;
        if (args != 0) {
            array = JSCHelper::ConvertToJSValueRefArray(ctx, args);
            argc = args->Size();
        } else {
            array = NULL;
        }

        for (int i = 0; i < argc; i++) {
            // register target
            if (JSValueIsObject(ctx, array[i])) {
                JSCHelper::SetPropertyAsValue(ctx,
                                              (JSObjectRef) array[i],
                                              "target",
                                              target_object,
                                              kJSPropertyAttributeReadOnly, NULL);
            }
        }

        std::stringstream stream;
        stream<<function_key_;
        JSStringRef function_key = JSStringCreateWithUTF8CString(stream.str().c_str());
        JSObjectRef function = (JSObjectRef)JSObjectGetProperty(ctx, target_object, function_key, NULL);
        JSObjectCallAsFunction(ctx, function, target_object, argc, array, NULL);
        JSStringRelease(function_key);

        delete[] array;
    }
}
