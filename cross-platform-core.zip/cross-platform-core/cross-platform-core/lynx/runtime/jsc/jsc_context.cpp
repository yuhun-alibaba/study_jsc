// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/jsc/jsc_context.h"
#include "runtime/jsc/objects/console_object.h"
#include "runtime/jsc/objects/screen_object.h"
#include "runtime/jsc/objects/element_object.h"
#include "runtime/jsc/objects/body_object.h"
#include "runtime/jsc/objects/document_object.h"
#include "runtime/jsc/objects/history_object.h"
#include "runtime/jsc/objects/location_object.h"
#include "runtime/jsc/objects/loader_object.h"
#include "runtime/jsc/objects/window_object.h"
#include "runtime/jsc/objects/navigator_object.h"

#include "runtime/jsc/timeout_callback.h"
#include "runtime/jsc/jsc_helper.h"
#include "runtime/jsc/class_wrap.h"
#include "base/print.h"

namespace jscore {
    
    JSCContext::~JSCContext() {
        JSGlobalContextRelease(context_);
    }
    
    void JSCContext::Initialize(JSVM* vm, Runtime* runtime) {
        JSContext::Initialize(vm, runtime);
        JSContextGroupRef context_group = static_cast<JSContextGroupRef>(vm->vm());
        
        ClassWrap* global_class_wrap = class_wrap_storage_->CreateClassWrap("Global", NULL);
        ClassWrap* body_class_wrap = class_wrap_storage_->CreateClassWrap("Body");
        ClassWrap* element_class_wrap = class_wrap_storage_->CreateClassWrap("Element");
        ClassWrap* document_class_wrap = class_wrap_storage_->CreateClassWrap("Document", NULL);
        ClassWrap* console_class_wrap = class_wrap_storage_->CreateClassWrap("Console");
        ClassWrap* screen_class_wrap = class_wrap_storage_->CreateClassWrap("Screen");
        ClassWrap* history_class_wrap = class_wrap_storage_->CreateClassWrap("History");
        ClassWrap* location_class_wrap = class_wrap_storage_->CreateClassWrap("Location");
        ClassWrap* navigator_class_wrap = class_wrap_storage_->CreateClassWrap("Navigator");
        ClassWrap* loader_class_wrap = class_wrap_storage_->CreateClassWrap("Loader");
        
        TimeoutCallback::BindingClass(global_class_wrap);
        WindowObject::BindingClass(global_class_wrap);
        ConsoleObject::BindingClass(console_class_wrap);
        ScreenObject::BindingClass(screen_class_wrap);
        ElementObject::BindingClass(element_class_wrap);
        BodyObject::BindingClass(body_class_wrap);
        DocumentObject::BindingClass(document_class_wrap);
        LoaderObject::BindingClass(loader_class_wrap);
        NavigatorObject::BindingClass(navigator_class_wrap);
        HistoryObject::BindingClass(history_class_wrap);
        LocationObject::BindingClass(location_class_wrap);
        
        global_class_wrap->SetJSClassAttributes(kJSClassAttributeNoAutomaticPrototype);
        JSClassRef global_class = global_class_wrap->MakeClass();
        context_ = JSGlobalContextCreateInGroup(context_group, global_class);
        JSClassRelease(global_class);
        
        JSObjectRef global_object = JSContextGetGlobalObject(context_);
        JSObjectSetPrivate(global_object, this);
        
        JSObjectRef loader_object = LoaderObject::Create(this, loader_class_wrap);
        JSObjectRef console_object = ConsoleObject::Create(this, console_class_wrap);
        JSObjectRef screen_object = ScreenObject::Create(this, screen_class_wrap);
        JSObjectRef navigator_object= NavigatorObject::Create(this, navigator_class_wrap);
        JSObjectRef document_object = DocumentObject::Create(this, document_class_wrap);
        JSObjectRef location_object = LocationObject::Create(this, location_class_wrap);
        JSObjectRef history_object = HistoryObject::Create(this, history_class_wrap);
        JSObjectRef body_object = BodyObject::Create(this, body_class_wrap);
        
        JSCHelper::SetPropertyAsValue(context_, global_object, "console", console_object, kJSPropertyAttributeNone, 0);
        JSCHelper::SetPropertyAsValue(context_, global_object, "navigator", navigator_object, kJSPropertyAttributeNone, 0);
        JSCHelper::SetPropertyAsValue(context_, global_object, "screen", screen_object, kJSPropertyAttributeNone, 0);
        JSCHelper::SetPropertyAsValue(context_, global_object, "window", global_object, kJSPropertyAttributeNone, 0);
        JSCHelper::SetPropertyAsValue(context_, global_object, "loader", loader_object, kJSPropertyAttributeNone, 0);
        JSCHelper::SetPropertyAsValue(context_, global_object, "document", document_object, kJSPropertyAttributeNone, 0);
        JSCHelper::SetPropertyAsValue(context_, document_object, "body", body_object, kJSPropertyAttributeNone, 0);
        JSCHelper::SetPropertyAsValue(context_, global_object, "history", history_object, kJSPropertyAttributeNone, 0);
        JSCHelper::SetPropertyAsValue(context_, global_object, "location", location_object, kJSPropertyAttributeNone, 0);
        
        history_ = ObjectWrap::Unwrap<HistoryObject>(history_object);
        location_ = ObjectWrap::Unwrap<LocationObject>(location_object);
    }
    
    void JSCContext::RunScript(const char* source) {
        JSStringRef js_source = JSStringCreateWithUTF8CString(source);
        JSValueRef exception = nullptr;
        
        if (JSCheckScriptSyntax(context_, js_source, NULL, 0, &exception)) {
            JSEvaluateScript(context_, js_source, NULL, NULL, 0, &exception);
        }
        
        JSStringRelease(js_source);
        
        if (exception) {
            int type = JSValueGetType(context_, exception);
            
            std::string str = JSCHelper::ConvertToString(context_, exception);
            if (!str.empty()) {
                LOGE("lynx-error", "js error: %s", str.c_str());
            }
        }
    }

    JSObjectRef JSCContext::MakeJSObject(const std::string& name) {
        if(context_storage() && context_storage()->GetClassWrap(name)) {
            return context_storage()->GetClassWrap(name)->MakeObject(GetContext());
        }
        return (JSObjectRef)JSValueMakeNull(GetContext());
    }
    
    void JSCContext::LoadUrl(const std::string& url) {
        location_->SetUrl(url);
        history_->Go(url);
    }
    
}
