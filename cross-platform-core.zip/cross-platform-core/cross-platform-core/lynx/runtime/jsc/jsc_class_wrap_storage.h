// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JSC_JSC_CLASS_WRAP_STORAGE_H_
#define LYNX_RUNTIME_JSC_JSC_CLASS_WRAP_STORAGE_H_

#include <JavaScriptCore/JavaScript.h>
#include "runtime/jsc/class_wrap.h"
#include <unordered_map>
#include <string>

namespace jscore {
    
    class JSCClassWrapStorage {
        public:
        
        JSCClassWrapStorage() {
            
        }
        
        ~JSCClassWrapStorage() {
            for (auto it = class_map.begin(); it != class_map.end(); ++it) {
                delete it->second;
            }
            class_map.clear();
        }
        
        ClassWrap* CreateClassWrap(const std::string& name, JSObjectFinalizeCallback callback = ObjectWrap::FinalizeCallback) {
            if (class_map.find(name) == class_map.end()) {
                class_map[name] = new ClassWrap(name, callback);
            }
            return class_map[name];
        }

        ClassWrap* GetClassWrap(const std::string& name) {
            ClassWrap* class_wrap = 0;
            if (class_map.find(name) != class_map.end()) {
                class_wrap = class_map[name];
            }
            return class_wrap;
        }
        
    private:
        // Scoped Ptr to manage heap
        std::unordered_map<std::string, ClassWrap*> class_map;
        
        
    };
}

#endif  // LYNX_RUNTIME_JSC_JSC_CLASS_WRAP_STORAGE_H_
