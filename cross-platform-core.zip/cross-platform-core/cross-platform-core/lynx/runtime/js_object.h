// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JS_OBJECT_H_
#define LYNX_RUNTIME_JS_OBJECT_H_

#include <unordered_map>
#include "base/scoped_set.h"
#include <string>
#include "runtime/js_value.h"

namespace jscore {

    class JSObject : public JSValue {
    public:
        JSObject();
        virtual ~JSObject();
        void Set(std::string name, JSValue* value);
        void Delete(std::string name);
        int Size();
        std::string GetName(int index);
        JSValue* GetProperty(std::string name);

    private:
        void RemovePtr(JSValue* value);
        void AddPtr(JSValue* value);
        std::unordered_map<std::string, JSValue*> properties_;
        base::ScopedSet<JSValue> ptrs_;
    };

}

#endif //LYNX_RUNTIME_JS_OBJECT_H_
