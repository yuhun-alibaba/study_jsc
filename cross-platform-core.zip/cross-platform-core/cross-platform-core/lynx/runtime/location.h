// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_LOCATION_H_
#define LYNX_RUNTIME_LOCATION_H_

#include <string>
#include "net/uri.h"
#include "runtime/js_context.h"

namespace jscore {
    class Location {
        
    public:
        void Reload(bool force);
        void Assign(const std::string &url);
        void Replace(const std::string &url);
        void SetUrl(const std::string& url);
        void ParseHref(const std::string& href);
        
        Location(JSContext* context);
        virtual ~Location();
        
        inline std::string hash() {
            return hash_;
        }
        
        inline void set_hash(const std::string& hash) {
            hash_ = hash;
        }
        
        inline std::string host() {
            return host_;
        }
        
        inline void set_host(const std::string& host) {
            host_ = host;
        }
        
        inline std::string hostname() {
            return hostname_;
        }
        
        inline void set_hostname(const std::string& hostname) {
            hostname_ = hostname;
        }
        
        inline std::string href() {
            return href_;
        }
        
        inline void set_href(const std::string& href) {
            href_ = href;
        }
        
        inline std::string pathname() {
            return pathname_;
        }
        
        inline void set_pathname(const std::string& pathname) {
            pathname_ = pathname;
        }
        
        inline std::string port() {
            return port_;
        }
        
        inline void set_port(const std::string& port) {
            port_ = port;
        }
        
        inline std::string protocol() {
            return protocol_;
        }
        
        inline void set_protocol(const std::string& protocol) {
            protocol_ = protocol;
        }
        
        inline std::string search() {
            return search_;
        }
        
        inline void set_search(const std::string& search) {
            search_ = search;
        }
        
        inline std::string origin() {
            return origin_;
        }
        
        inline void set_origin(const std::string& origin) {
            origin_ = origin;
        }
        
    private:
        JSContext* context_;
        net::Uri uri_;
        
        std::string hash_;
        std::string host_;
        std::string hostname_;
        std::string href_;
        std::string pathname_;
        std::string port_;
        std::string protocol_;
        std::string search_;
        std::string origin_;
    };
}

#endif // LYNX_RUNTIME_LOCATION_H_
