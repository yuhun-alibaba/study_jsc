// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_JS_FUNCTION_H_
#define LYNX_RUNTIME_JS_FUNCTION_H_

#include <stdint.h>

namespace jscore {

class JSContext;
class JSArray;

enum class TargetState : int {
    Empty = 0,
    Global = -1
};

class JSFunction {
 public:
    JSFunction(JSContext* context) : context_(context){}
    virtual ~JSFunction() {}
    virtual void Run(void* target, JSArray* args) {}

    intptr_t GetKey() { return function_key_;}

 protected:
    intptr_t function_key_;
    JSContext* context_;
};
}  // namespace jscore

#endif  // LYNX_RUNTIME_JS_FUNCTION_H_
