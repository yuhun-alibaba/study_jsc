// Copyright 2017 The Lynx Authors. All rights reserved.

#include "runtime/timed_task.h"
#include "runtime/js_context.h"

namespace jscore {
    
    void TimedTaskInvoker::SetTimeout(JSContext* context, JSFunction* function, int time) {
        context->runtime()->thread_manager()->RunOnJSThreadDelay(new TimedTask(function), time);
    }
    
    void TimedTaskInvoker::SetInterval(JSContext* context, JSFunction* function, int time) {
        context->runtime()->thread_manager()->RunOnJSThreadInterval(new TimedTask(function), time);
    }
    
    void TimedTaskInvoker::clearTimeout() {
    }
    
    void TimedTask::Run() {
        if (js_function_.Get() != NULL) {
            js_function_->Run(reinterpret_cast<void*>(TargetState::Global), NULL);
        }
    }
}