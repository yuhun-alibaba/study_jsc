// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RUNTIME_LOADER_H_
#define LYNX_RUNTIME_LOADER_H_

#include <string>
#include "base/weak_ptr.h"
#include "net/url_request_delegate.h"

namespace jscore {

    class JSContext;
    class JSFunction;
    
    class LoaderRequestDelegate : public net::URLRequestDelegate {
        
    public:
        LoaderRequestDelegate(JSContext* context) : LoaderRequestDelegate(context, NULL) {}
        
        LoaderRequestDelegate(JSContext* context, JSFunction* succ)
        : LoaderRequestDelegate(context, succ, NULL) {}
        
        LoaderRequestDelegate(JSContext* context, JSFunction* succ, JSFunction* error)
        : context_(context), js_succ_function_(succ), js_error_function_(error), weak_ptr_(this) {}
        
        virtual ~LoaderRequestDelegate() {}
        
        virtual void OnSuccess(base::PlatformString& url, base::PlatformString& response);
        virtual void OnFailed(base::PlatformString& url, base::PlatformString& error);
        void OnSuccessOnJSThread(const base::PlatformString& response);
        void OnFailedOnJSThread();
        
    private:
        JSContext* context_;
        base::ScopedPtr<JSFunction> js_succ_function_;
        base::ScopedPtr<JSFunction> js_error_function_;
        base::WeakPtr<LoaderRequestDelegate> weak_ptr_;
    };
    
    class Loader {
    public:
        Loader(JSContext* context);
        ~Loader();
        void Script(const std::string& url, JSFunction* succ_func, JSFunction* error_func);
        
        inline JSContext* context() {
            return context_;
        }
    private:
        JSContext* context_;
    };
}

#endif // LYNX_RUNTIME_LOADER_H_
