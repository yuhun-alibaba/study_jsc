// Copyright 2017 The Lynx Authors. All rights reserved.

#include "location.h"

namespace jscore {
    
    Location::Location(JSContext* context) : context_(context) {
        
    }
    
    Location::~Location() {
        
    }
    
    void Location::SetUrl(const std::string& url) {
        ParseHref(url);
    }
    
    void Location::ParseHref(const std::string& href) {
        uri_ = net::Uri::Parse(href);
        href_ = uri_.href_;
        host_ = uri_.host_;
        protocol_ = uri_.protocol_;
        port_ = uri_.port_;
        pathname_ = uri_.path_;
        search_ = uri_.query_;
        origin_ = uri_.origin_;
        hostname_ = uri_.hostname_;
    }
    
    void Location::Reload(bool force) {
//        context_->Reload(force);
    }
    
    void Location::Replace(const std::string &url) {
        SetUrl(url);
//        context_->Reload(true);
    }
    
    void Location::Assign(const std::string &url) {
        context_->LoadUrl(url);
    }
}
