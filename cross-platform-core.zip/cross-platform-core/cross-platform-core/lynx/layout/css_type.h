// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_LAYOUT_CSS_TYPE_H_
#define LYNX_LAYOUT_CSS_TYPE_H_

#include <limits.h>
#include <string>

namespace lynx {

#define CSS_UNDEFINED 0x7FFFFFFF
#define CSS_MAX (0x7FFFFFFF - 1)
#define CSS_IS_UNDEFINED(VAL) (VAL == INT_MAX)

enum CSSStyleType {
    CSS_DISPLAY_NONE,
    CSS_DISPLAY_FLEX,

    CSSFLEX_ALIGN_AUTO,
    CSSFLEX_ALIGN_FLEX_START,
    CSSFLEX_ALIGN_CENTER,
    CSSFLEX_ALIGN_FLEX_END,
    CSSFLEX_ALIGN_STRETCH,

    CSSFLEX_DIRECTION_COLUMN,
    CSSFLEX_DIRECTION_COLUMN_REVERS,
    CSSFLEX_DIRECTION_ROW,
    CSSFLEX_DIRECTION_ROW_REVERSE,

    CSSFLEX_JUSTIFY_FLEX_START,
    CSSFLEX_JUSTIFY_FLEX_CENTER,
    CSSFLEX_JUSTIFY_FLEX_END,
    CSSFLEX_JUSTIFY_SPACE_BETWEEN,
    CSSFLEX_JUSTIFY_SPACE_AROUND,

    CSSFLEX_WRAP,
    CSSFLEX_NOWRAP,

    CSS_POSITION_RELATIVE,
    CSS_POSITION_ABSOLUTE,
    CSS_POSITION_FIXED,

    CSS_VISIBLE,
    CSS_HIDDEN
};

enum TextStyleType {
    CSSTEXT_ALIGN_LEFT = 0,
    CSSTEXT_ALIGN_RIGHT,
    CSSTEXT_ALIGN_CENTER,

    CSSTEXT_TEXTDECORATION_LINETHROUGH,
    CSSTEXT_TEXTDECORATION_NONE,

    CSSTEXT_FONT_WEIGHT_NORMAL,
    CSSTEXT_FONT_WEIGHT_BOLD,

    CSSTEXT_OVERFLOW_ELLIPSIS,
    CSSTEXT_OVERFLOW_NONE,

    CSSTEXT_WHITESPACE_NOWRAP,
    CSSTEXT_WHITESPACE_NORMAL
};

enum ImageStyleType {
    CSSIMAGE_OBJECT_FIT_FILL,
    CSSIMAGE_OBJECT_FIT_CONTAIN,
    CSSIMAGE_OBJECT_FIT_COVER
};

CSSStyleType ToVisibleType(const std::string& value);

CSSStyleType ToDisplayType(const std::string& value);

CSSStyleType ToFlexAlignType(const std::string& value);

CSSStyleType ToFlexDirectionType(const std::string& value);

CSSStyleType ToFlexJustifyType(const std::string& value);

CSSStyleType ToFlexWrapType(const std::string& value);

CSSStyleType ToPositionType(const std::string& value);

TextStyleType ToTextAlignType(const std::string& value);

TextStyleType ToTextDecorationType(const std::string& value);

TextStyleType ToTextFontWeightType(const std::string& value);

TextStyleType ToTextOverflowType(const std::string& value);

TextStyleType ToTextWhiteSpaceType(const std::string& value);

ImageStyleType ToObjectFitType(const std::string& value);

}  // namespace lynx

#endif  // LYNX_LAYOUT_CSS_TYPE_H_
