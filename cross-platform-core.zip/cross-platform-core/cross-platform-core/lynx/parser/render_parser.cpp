//
//  RenderParser.cpp
//  lynx
//
//  Created by dli on 2017/7/17.
//  Copyright © 2017年 lynx. All rights reserved.
//

#include "parser/render_parser.h"

namespace parser {
    void RenderParser::Insert(const std::string& source) {
        input_.Write(source);
        PumpTokenizer();
    }
    
    void RenderParser::PumpTokenizer() {
        while(input_.HasNext()) {
            if(tokenizer_.NextToken(input_, token_)) {
                tree_builder_.BuildTree(token_);
                token_.Clear();
            }
        }
    }

}
