//
//  render_token.cpp
//  lynx
//
//  Created by dli on 2017/7/17.
//  Copyright © 2017年 lynx. All rights reserved.
//

#include "parser/render_token.h"

namespace parser {
    void RenderToken::BeginStartTag(char ch) {
        type_ = START_TAG;
        tag_name_.append(1, ch);
    }
}
