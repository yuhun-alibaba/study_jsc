// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_NET_URL_REQUEST_CONTEXT_H_
#define LYNX_NET_URL_REQUEST_CONTEXT_H_

#include <string>
#include "net/url_request.h"
#if OS_ANDROID
#include "net/android/url_request_android.h"
#elif OS_IOS
#include "net/ios/url_request_ios.h"
#endif

namespace net {
class URLRequestContext {
 public:
    static URLRequest* CreateRequest(int id) {
#if OS_ANDROID
        return new URLRequestAndroid(id);
#elif OS_IOS
        return new URLRequestIOS(id);
#endif
    }
};
}  // namespace net
#endif  // LYNX_NET_URL_REQUEST_CONTEXT_H_
