// Copyright 2017 The Lynx Authors. All rights reserved.

#import "url_request_ios.h"

namespace net {
    
    AFHTTPRequestOperationManager* URLRequestIOS::g_network_;
    
    URLRequestIOS::URLRequestIOS(int id) : URLRequest(id){
        
    }
    
    URLRequestIOS::~URLRequestIOS() {
        
    }
    
    void URLRequestIOS::Fetch(const string& url, URLRequestDelegate *delegate) {
        NSString *ns_url_string =  [NSString stringWithUTF8String:url.c_str()];
        NSURL *ns_url = [NSURL URLWithString:ns_url_string];
        
        delegate->AddRef();
        
        if (ns_url.fileURL) {
            [[[NSURLSession sharedSession] downloadTaskWithURL:ns_url completionHandler:^(NSURL* _Nullable location,
                                                                                        NSURLResponse * _Nullable response, NSError * _Nullable error) {
                NSData *downloadData = [NSData dataWithContentsOfURL:location];
                NSString *response_ns_str = [[NSString alloc] initWithData:downloadData encoding:NSUTF8StringEncoding];
                base::PlatformString scoped_url(ns_url_string);
                base::PlatformString scoped_source(response_ns_str);
                delegate->OnSuccess(scoped_url, scoped_source);
                delegate->Release();
            }] resume];
        } else {
            if (nil == g_network_)
            {
                g_network_ = [AFHTTPRequestOperationManager manager];
                g_network_.requestSerializer.timeoutInterval = 30.0f;
                g_network_.responseSerializer = [AFHTTPResponseSerializer serializer];
                [g_network_.requestSerializer setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
                //[g_network_.requestSerializer setValue:@"User-Agent" forHTTPHeaderField:@"mogujie"];
                [g_network_.requestSerializer setValue:@"*/*" forHTTPHeaderField:@"Accept"];
            }
            
            [g_network_ GET:ns_url.absoluteString parameters:nil
                    success:^(AFHTTPRequestOperation* operation, id responseObject)
                    {
                        if (delegate != 0) {
                            NSString *response_ns_str = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
                            base::PlatformString scoped_url(ns_url_string);
                            base::PlatformString scoped_source(response_ns_str);
                            delegate->OnSuccess(scoped_url, scoped_source);
                            delegate->Release();
                        }
                    }
                   failure:^(AFHTTPRequestOperation* operation, NSError* error)
                    {
                        if (delegate != 0) {
                            NSString *error_ns_str = error.localizedFailureReason;
                            base::PlatformString scoped_url(ns_url_string);
                            base::PlatformString scoped_error(error_ns_str);
                            delegate->OnSuccess(scoped_url, scoped_error);
                            delegate->Release();
                        }
                    }
            ];
        }

    }
}
