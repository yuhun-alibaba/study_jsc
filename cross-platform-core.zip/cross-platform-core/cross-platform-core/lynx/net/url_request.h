// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_NET_URL_REQUEST_H_
#define LYNX_NET_URL_REQUEST_H_

#include <string>
#include "net/url_request_delegate.h"

namespace net {
class URLRequest {
 public:
    URLRequest(long id) : id_(id) {}
    virtual ~URLRequest() {}
    virtual void Fetch(const std::string& url, URLRequestDelegate* delegate) {}

protected:
    long id_;
};
}
#endif  // LYNX_NET_URL_REQUEST_H_
