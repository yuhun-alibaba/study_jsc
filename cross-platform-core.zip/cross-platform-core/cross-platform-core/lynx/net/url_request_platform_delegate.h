// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_NET_URL_REQUEST_PLATFORM_DELEGATE_H_
#define LYNX_NET_URL_REQUEST_PLATFORM_DELEGATE_H_

#include "net/url_request_delegate.h"

#include <string>

#include "base/ref_counted_ptr.h"

namespace net {
class URLRequestPlatformDelegate : public URLRequestDelegate {
 public:
    explicit URLRequestPlatformDelegate(URLRequestDelegate* delegate) :
        URLRequestDelegate(),
        delegate_(delegate) {
    }

    virtual ~URLRequestPlatformDelegate() {
    }

    virtual void OnSuccess(base::PlatformString& url,
                           base::PlatformString& response) {
        delegate_->OnSuccess(url, response);
    }

    virtual void OnFailed(base::PlatformString& url,
                          base::PlatformString& error) {
        delegate_->OnFailed(url, error);
    }

 private:
    base::ScopedRefPtr<URLRequestDelegate> delegate_;
};
}  // namespace net
#endif  // LYNX_NET_URL_REQUEST_PLATFORM_DELEGATE_H_
