//
//  Created by yxp on 02/10/17.
//


#include "base/android/java_type.h"
#include "net/android/url_request_android.h"
#include "net/url_request_platform_delegate.h"
#include "URLRequest_jni.h"

void OnSuccess(JNIEnv* env, jobject jcaller, jlong ptr, jstring url, jstring response) {
    net::URLRequestPlatformDelegate* delegate = reinterpret_cast<net::URLRequestPlatformDelegate*>(ptr);
    if(delegate != NULL) {
        base::PlatformString scoped_url(env, url);
        base::PlatformString scoped_response(env, response);
        delegate->OnSuccess(scoped_url, scoped_response);
        delegate->Release();
    }
}

void OnFailed(JNIEnv* env, jobject jcaller, jlong ptr, jstring url, jstring error) {
    net::URLRequestPlatformDelegate* delegate = reinterpret_cast<net::URLRequestPlatformDelegate*>(ptr);
    if(delegate != NULL) {
        base::PlatformString scoped_url(env, url);
        base::PlatformString scoped_error(env, error);
        delegate->OnFailed(scoped_url, scoped_error);
        delegate->Release();
    }
}

void OnCancel(JNIEnv* env, jobject jcaller, jlong ptr) {
    net::URLRequestPlatformDelegate* delegate = reinterpret_cast<net::URLRequestPlatformDelegate*>(ptr);
    if(delegate != NULL) {
        delegate->Release();
    }
}

namespace net {


    URLRequestAndroid::URLRequestAndroid(int id) : URLRequest(id) {
        CreateRequestObject();
    }

    URLRequestAndroid::~URLRequestAndroid() {

    }

    bool URLRequestAndroid::RegisterJNIUtils(JNIEnv* env) {
        return RegisterNativesImpl(env);
    }

    void URLRequestAndroid::Fetch(const std::string& url, URLRequestDelegate* delegate) {
        JNIEnv* env = base::android::AttachCurrentThread();
        URLRequestPlatformDelegate* platform_delegate = new URLRequestPlatformDelegate(delegate);
        platform_delegate->AddRef();
        Java_URLRequest_fetch(env, net_request_obj_.Get(), id_,
                              (jstring)base::android::JType::NewString(env, url.c_str()).Get(),
                              reinterpret_cast<long>(platform_delegate));
    }

    void URLRequestAndroid::CreateRequestObject() {
        JNIEnv* env = base::android::AttachCurrentThread();
        net_request_obj_.Reset(env, Java_URLRequest_create(env, id_));
    }

}

