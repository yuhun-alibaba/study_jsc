//
// Created by yxp on 17/2/10.
//

#ifndef LYNX_NET_URL_REQUEST_ANDROID_H_
#define LYNX_NET_URL_REQUEST_ANDROID_H_

#include <jni.h>

#include "base/android/scoped_java_ref.h"
#include "base/android/android_jni.h"
#include "net/url_request.h"
#include "net/url_request_delegate.h"

namespace net {
    class URLRequestAndroid : public URLRequest{
    public:
        URLRequestAndroid(int id);
        virtual ~URLRequestAndroid();
        virtual void Fetch(const std::string& url, URLRequestDelegate* delegate);
        static bool RegisterJNIUtils(JNIEnv* env);
    private:
        void CreateRequestObject();
        base::android::ScopedGlobalJavaRef<jobject> net_request_obj_;
    };
}
#endif  // LYNX_NET_URL_REQUEST_ANDROID_H_
