//
// Created by dli on 2017/7/13.
//

#include <runtime/js_value.h>
#include "base/android/jni_helper.h"
#include "base/android/params_transform.h"
#include "runtime/js_array.h"
#include "runtime/js_object.h"
#include "runtime/js_target_object.h"

namespace base {
    namespace android {
        jmethodID get_bytes_method_ = 0;
        std::string JNIHelper::ConvertToString(JNIEnv* env, jstring jstr)
        {
            char* rtn = NULL;

            if (get_bytes_method_ == 0) {
                jclass clsstring = env->FindClass("java/lang/String");
                //jstring strencode = env->NewStringUTF("GB2312");
                get_bytes_method_ = env->GetMethodID(clsstring, "getBytes", "()[B");
            }

            jbyteArray barr = (jbyteArray)env->CallObjectMethod(jstr, get_bytes_method_);
            jsize alen = env->GetArrayLength(barr);
            jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);

            std::string stemp((char*)ba, alen);
            env->ReleaseByteArrayElements(barr, ba, 0);
            env->DeleteLocalRef(barr);

            return stemp;
        }

        base::Value JNIHelper::ConvertToValue(JNIEnv* env, jobject obj) {
            char type = ParamsTransform::Transform(env, obj);
            return ConvertToValue(env, obj, type);
        }

        base::Value JNIHelper::ConvertToValue(JNIEnv* env, jobject obj, char type) {
            base::Value result;
            switch (type) {
                case 'I':
                    result.data_.i = ConvertToInt(env, obj);
                    break;
                case 'J':
                    result.data_.l = ConvertToLong(env, obj);
                    break;
                case 'F':
                    result.data_.f = ConvertToFloat(env, obj);
                    break;
                case 'D':
                    result.data_.d = ConvertToDouble(env, obj);
                    break;
                case 'Z':
                    result.data_.b = ConvertToBoolean(env, obj);
                    break;
                case 's': // String
                    result.data_.str = ConvertToString(env, (jstring) obj).c_str();
                    break;
                case 'B':
                case 'C':
                case 'S':
                case 'V':
                default:
                    break;
            }
            return result;
        }

        base::android::ScopedLocalJavaRef<jobject> JNIHelper::ConvertToJObject(JNIEnv* env, base::Value value) {
            base::android::ScopedLocalJavaRef<jobject> result;
            jobject obj;
            switch (value.type_) {
                case base::Value::VALUE_INT:
                    obj = JType::NewInt(env, value.data_.i);
                    break;
                case base::Value::VALUE_LONG:
                    obj = JType::NewLong(env, value.data_.l);
                    break;
                case base::Value::VALUE_BOOL:
                    obj = JType::NewBoolean(env, value.data_.b);
                    break;
                case base::Value::VALUE_FLOAT:
                    obj = JType::NewFloat(env, value.data_.f);
                    break;
                case base::Value::VALUE_DOUBLE:
                    obj = JType::NewDouble(env, value.data_.d);
                    break;
                case base::Value::VALUE_STRING:
                    obj = JType::NewString(env, value.data_.str).Release();
                    break;
                default:
                    break;
            }
            result.ResetNewLocalRef(env, obj);
            return result;
        }

        jscore::JSObject* JNIHelper::ConvertToJSObject(JNIEnv* env, jobject obj) {
            jobject properties_array_java = base::android::JType::GetJSObjectProperties(env, obj);
            jscore::JSObject* js_obj = new jscore::JSObject();
            if (properties_array_java != NULL) {
                jscore::JSArray* js_properties_array = ConvertToJSArray(env, properties_array_java);
                env->DeleteLocalRef(properties_array_java);
                for (int i = 0; i < js_properties_array->Size(); i += 2) {
                    jscore::JSValue* str_ref = js_properties_array->Get(i);
                    js_obj->Set(str_ref->data_.str, js_properties_array->Get(i + 1));
                }
            }
            return js_obj;
        }

        jscore::JSValue* JNIHelper::ConvertToJSTargetObject(JNIEnv* env, jobject value) {
        }

        jscore::JSArray* JNIHelper::ConvertToJSArray(JNIEnv* env, jobject java_array) {
            int length = (int)base::android::JType::GetJSArrayLength(env, java_array);
            jstring types_j = base::android::JType::GetJSArrayElementTypes(env, java_array);
            const char* types_c = env->GetStringUTFChars(types_j, JNI_FALSE);
            std::string types(types_c);

            jscore::JSArray* js_array = new jscore::JSArray();
            for (int i = 0; i < length; ++i) {
                jobject java_obj = base::android::JType::GetJSArrayElement(env, java_array, i);
                jscore::JSValue* object = ConvertToJSValue(env, java_obj, types[i]);
                env->DeleteLocalRef(java_obj);
                js_array->Push(object);
            }
            env->ReleaseStringUTFChars(types_j, types_c);
            env->DeleteLocalRef(types_j);
            return js_array;
        }

        jscore::JSArray* JNIHelper::ConvertToJSArray(JNIEnv* env, const jobjectArray args) {
            std::string types = base::android::ParamsTransform::Transform(env, args);
            int length = types.size();
            int i = 0;
            jscore::JSArray* values = new jscore::JSArray();
            for (; i < length; ++i) {
                jobject arg = env->GetObjectArrayElement(args, i);
                jscore::JSValue* object = ConvertToJSValue(env, arg, types[i]);
                env->DeleteLocalRef(arg);
                values->Push(object);
            }
            return values;
        }

        jscore::JSValue* JNIHelper::ConvertToJSValue(JNIEnv* env, jobject java_obj, char type) {
            jscore::JSValue* value = 0;
            switch (type) {
                case 'I':
                    value = jscore::JSValue::MakeInt(ConvertToInt(env, java_obj));
                    break;
                case 'J':
                    value = jscore::JSValue::MakeLong(ConvertToLong(env, java_obj));
                    break;
                case 'F':
                    value = jscore::JSValue::MakeFloat(ConvertToFloat(env, java_obj));
                    break;
                case 'D':
                    value = jscore::JSValue::MakeDouble(ConvertToDouble(env, java_obj));
                    break;
                case 'Z':
                    value = jscore::JSValue::MakeBool(ConvertToBoolean(env, java_obj));
                    break;
                case 's': // String
                    value = jscore::JSValue::MakeString(ConvertToString(env, (jstring) java_obj));
                    break;
                case 'b': // JSArray
                    value = ConvertToJSArray(env, java_obj);
                    break;
                case 'c': // JSObject
                    value = ConvertToJSObject(env, java_obj);
                case 'V':
                default:
                    break;
            }
            return value;
        }

    }
}