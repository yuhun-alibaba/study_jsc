// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_BASE_ANDROID_JAVA_TYPE_H_
#define LYNX_BASE_ANDROID_JAVA_TYPE_H_

#include <jni.h>

#include "base/android/scoped_java_ref.h"

namespace base {
namespace android {

enum class Type : int {
    Boolean,
    Char,
    Byte,
    Short,
    Int,
    Long,
    Float,
    Double,
    String,
    JSArray,
    JSObject,
    Object,
    Null
};

class JType {
 public:
    static jobject NewByte(JNIEnv* env, jbyte value);
    static jobject NewChar(JNIEnv* env, jchar value);
    static jobject NewBoolean(JNIEnv* env, jboolean value);
    static jobject NewShort(JNIEnv* env, jshort value);
    static jobject NewInt(JNIEnv* env, jint value);
    static jobject NewLong(JNIEnv* env, jlong value);
    static jobject NewFloat(JNIEnv* env, jfloat value);
    static jobject NewDouble(JNIEnv* env, jdouble value);

    static ScopedLocalJavaRef<jstring> NewString(JNIEnv* env, const char* str);

    static jbyte ByteValue(JNIEnv* env, jobject value);
    static jchar CharValue(JNIEnv* env, jobject value);
    static jboolean BooleanValue(JNIEnv* env, jobject value);
    static jshort ShortValue(JNIEnv* env, jobject value);
    static jint IntValue(JNIEnv* env, jobject value);
    static jlong LongValue(JNIEnv* env, jobject value);
    static jfloat FloatValue(JNIEnv* env, jobject value);
    static jdouble DoubleValue(JNIEnv* env, jobject value);

    static jobjectArray NewObjectArray(JNIEnv* env, int length);
    static jobjectArray NewStringArray(JNIEnv* env, int length);

    static Type getClassType(int retType);

    static bool IsInstanceOf(JNIEnv* env, jobject arg, Type retType);
    static void ReleaseAll(JNIEnv* env);

    // JSArray
    static jobject NewJSArray(JNIEnv* env, int length);
    static void SetJSArrayElement(JNIEnv* env,
        jobject array, int index, jobject obj);
    static jobject GetJSArrayElement(JNIEnv* env, jobject array, int index);
    static jstring GetJSArrayElementTypes(JNIEnv* env, jobject array);
    static jint GetJSArrayLength(JNIEnv* env, jobject array);

    // JSObject
    static jobject NewJSObject(JNIEnv* env);
    static void SetJSObjectProperties(JNIEnv* env,
        jobject jjsobj, jobject array);
    static jobject GetJSObjectProperties(JNIEnv* env, jobject jjsobj);

    static void Init(JNIEnv* env, Type type);

 private:
    JType() {
    }

    static void EnsureInstance(JNIEnv* env, Type type);

    static jclass byte_clazz;
    static jmethodID byte_ctor;
    static jfieldID byte_valueField;

    static jclass char_clazz;
    static jmethodID char_ctor;
    static jfieldID char_valueField;

    static jclass boolean_clazz;
    static jmethodID boolean_ctor;
    static jfieldID boolean_valueField;

    static jclass short_clazz;
    static jmethodID short_ctor;
    static jfieldID short_valueField;

    static jclass int_clazz;
    static jmethodID int_ctor;
    static jfieldID int_valueField;

    static jclass long_clazz;
    static jmethodID long_ctor;
    static jfieldID long_valueField;

    static jclass float_clazz;
    static jmethodID float_ctor;
    static jfieldID float_valueField;

    static jclass double_clazz;
    static jmethodID double_ctor;
    static jfieldID double_valueField;

    static jclass string_clazz;
    static jclass object_clazz;

    // JSArray
    static jclass js_array_clazz;
    static jmethodID js_array_ctor;
    static jmethodID js_array_set_method;
    static jmethodID js_array_get_method;
    static jmethodID js_array_get_element_type_method;
    static jmethodID js_array_length_method;

    // JSObject
    static jclass js_object_clazz;
    static jmethodID js_object_ctor;
    static jmethodID js_object_set_properties_method;
    static jmethodID js_object_get_properties_method;
};

}  // namespace android
}  // namespace base
#endif //LYNX_BASE_ANDROID_JAVA_TYPE_H_
