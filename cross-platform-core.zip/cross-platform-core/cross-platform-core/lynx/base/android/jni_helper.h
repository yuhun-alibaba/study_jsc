//
// Created by dli on 2017/7/13.
//

#ifndef LYNX_BASE_ANDROID_JNI_HELPER_H_
#define LYNX_BASE_ANDROID_JNI_HELPER_H_

#include <string>
#include <jni.h>
#include <base/scoped_ptr.h>

#include "base/value.h"
#include "base/android/scoped_java_ref.h"
#include "base/android/java_type.h"
#include "runtime/js_value.h"
#include "runtime/js_array.h"

namespace base {
    namespace android {
        class JNIHelper {
        public:
            static std::string ConvertToString(JNIEnv* env, jstring value);
            static base::Value ConvertToValue(JNIEnv* env, jobject jobj);
            static base::Value ConvertToValue(JNIEnv* env, jobject jobj, char type);

            static base::android::ScopedLocalJavaRef<jobject> ConvertToJObject(JNIEnv* env, base::Value);


            inline static int ConvertToInt(JNIEnv* env, jobject jobj) {
                int value = JType::IntValue(env, jobj);
                return value;
            }

            inline static long ConvertToLong(JNIEnv* env, jobject jobj) {
                long value = (long)JType::LongValue(env, jobj);
                return value;
            }

            inline static float ConvertToFloat(JNIEnv* env, jobject jobj) {
                float value = (float) JType::FloatValue(env, jobj);
                return value;
            }

            inline static double ConvertToDouble(JNIEnv* env, jobject jobj) {
                double value = (double) JType::DoubleValue(env, jobj);
                return value;
            }

            inline static bool ConvertToBoolean(JNIEnv* env, jobject jobj) {
                jboolean value = JType::BooleanValue(env, jobj);
                return (bool)(value == JNI_TRUE);
            }

            static jscore::JSObject* ConvertToJSObject(JNIEnv* env, jobject value);
            static jscore::JSValue* ConvertToJSTargetObject(JNIEnv* env, jobject value);
            static jscore::JSArray* ConvertToJSArray(JNIEnv* env, jobject value);
            static jscore::JSArray* ConvertToJSArray(JNIEnv *env, const jobjectArray args);
            static jscore::JSValue* ConvertToJSValue(JNIEnv* env, jobject value, char type);

        };
    }
}

#endif  // LYNX_BASE_ANDROID_JNI_HELPER_H_
