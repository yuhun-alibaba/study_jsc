// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef BASE_ANDROID_JNI_REGISTER_H_
#define BASE_ANDROID_JNI_REGISTER_H_

namespace base {
    namespace android {

    }
}

#endif //BASEANDROID_JNI_REGISTER_H_
