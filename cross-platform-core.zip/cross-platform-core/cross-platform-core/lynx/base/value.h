// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_BASE_VALUE_H_
#define LYNX_BASE_VALUE_H_

namespace base {

typedef struct Value {
    enum ValueType {
        VALUE_INT,
        VALUE_LONG,
        VALUE_BOOL,
        VALUE_FLOAT,
        VALUE_DOUBLE,
        VALUE_STRING,
    };
    ValueType type_;
    union {
        int i;
        long l;  // TODO(int64)
        short s;
        bool b;
        float f;
        double d;
        const char* str;
    } data_;
} Value;

}  // namespace base
#endif  // LYNX_BASE_VALUE_H_
