// Copyright 2017 The Lynx Authors. All rights reserved.

#include "loader/xc/xc_request_delegate.h"
#include "loader/xc/xc_file.h"

namespace loader {
XCRequestDelegate::XCRequestDelegate(XCLoader* loader, int type):
                                    loader_(loader),
                                    type_(type) {
    loader_->AddRef();
}

XCRequestDelegate::~XCRequestDelegate() {
    loader_->Release();
}

void XCRequestDelegate::OnSuccess(base::PlatformString& url,
                            base::PlatformString& response) {
    loader_->LoadXC(url.ToString(), response.ToString());
}

void XCRequestDelegate::OnFailed(base::PlatformString& url,
                                base::PlatformString& error) {
}

}  // namespace loader
