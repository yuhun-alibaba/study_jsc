// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_LOADER_XC_XC_FILE_H_
#define LYNX_LOADER_XC_XC_FILE_H_

#include <string>

namespace loader {
class XCFile {
 public:

    XCFile(): api_level_(0), stable_version_(0) {}
    ~XCFile() {}
    void Parse(const std::string& str);

    friend class XCLoader;
 protected:
    std::string pre_bundle_;
    std::string bundle_;
    std::string post_bundle_;
    std::string title_;
    int api_level_;
    int stable_version_;
};
}  // namespace loader

#endif  // LYNX_LOADER_XC_XC_FILE_H_
