// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_LOADER_XC_XC_LOADER_H_
#define LYNX_LOADER_XC_XC_LOADER_H_

#include <string>

#include "base/scoped_ptr.h"
#include "net/url_request.h"
#include "loader/loader.h"
#include "runtime/runtime_url_request_delegate.h"
#include "loader/xc/xc_file.h"

namespace loader {
class XCLoader : public LynxLoader {
 public:
    explicit XCLoader(jscore::Runtime* runtime);
    virtual ~XCLoader();

    virtual void Load(const std::string& url, int type);
    void LoadXC(const std::string& url, const std::string& data);

 private:
    void LoadXCOnJSThread(const std::string& url, const std::string& data);
    bool LoadFromCache(const std::string& url);

    base::ScopedPtr<net::URLRequest> request_;
    jscore::Runtime* runtime_;
    std::string url_;
    base::ScopedRefPtr<ScriptLoader> script_loader_;
};
}  // namespace loader

#endif  // LYNX_LOADER_XC_XC_LOADER_H_
