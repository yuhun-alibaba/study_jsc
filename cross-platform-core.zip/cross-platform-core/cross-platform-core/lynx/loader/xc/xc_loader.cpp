// Copyright 2017 The Lynx Authors. All rights reserved.

#include <config/global_config_data.h>
#include <base/print.h>
#include "net/url_request_context.h"
#include "net/url_parser.h"
#include "loader/xc/xc_loader.h"
#include "loader/xc/xc_file.h"
#include "loader/xc/xc_request_delegate.h"

namespace loader {

XCLoader::XCLoader(jscore::Runtime* runtime)
    : request_(net::URLRequestContext::CreateRequest(reinterpret_cast<long>(runtime))),
      runtime_(runtime),
      script_loader_(new ScriptLoader(runtime, true)){
}

XCLoader::~XCLoader() {

}

std::string XCConvert(const std::string& url) {
    net::URLParser parser(url);
    std::string converted_url = parser.URLWithoutParams();
    int len = converted_url.length();
    if (converted_url.compare(len - 5, 5, ".html") == 0) {
        converted_url = converted_url.replace(len - 5, 5, ".xc");
    } else {
        converted_url = converted_url + "/index.xc";
    }
    converted_url += parser.Query();
    return converted_url;
}

void XCLoader::Load(const std::string& url, int type) {
    switch (type) {
        case MAIN_FILE:
            url_ = XCConvert(url);
            if (!LoadFromCache(url_)) {
                request_->Fetch(url_, new XCRequestDelegate(this, type));
            }
            break;
        case SCRIPT_FILE:
            script_loader_->Load(url, type);
            break;
    }
}
    void XCLoader::LoadXC(const std::string& url, const std::string& data) {
        base::ScopedRefPtr<XCLoader> ref(this);
        runtime_->thread_manager()->RunOnJSThread(
                base::Bind(&XCLoader::LoadXCOnJSThread, ref, url, data));
    }

    void XCLoader::LoadXCOnJSThread(const std::string& url, const std::string& data) {
        XCFile xc_file;
        xc_file.Parse(data);
        if(!xc_file.pre_bundle_.empty()) {
            Load(xc_file.pre_bundle_, SCRIPT_FILE);
        }
        if(!xc_file.bundle_.empty()) {
            Load(xc_file.bundle_, SCRIPT_FILE);
        }
        if(!xc_file.post_bundle_.empty()) {
            Load(xc_file.post_bundle_, SCRIPT_FILE);
        }
    }

bool XCLoader::LoadFromCache(const std::string& url) {
    //if(config::GlobalConfigData::GetInstance()->cache_manager().ReadCache(data, xc_file))
    return false;
}
}  // namespace loader
