// Copyright 2017 The Lynx Authors. All rights reserved.

#include "loader/xc/xc_file.h"

#include "third_party/jsoncpp/include/json/reader.h"

namespace loader {
void XCFile::Parse(const std::string& str) {
    Json::Reader reader;
    Json::Value root;
    if (reader.parse(str, root)) {
        pre_bundle_ = root["prejsbundle"].asString();
        bundle_ = root["jsbundle"].asString();
        post_bundle_ = root["postjsbundle"].asString();
        title_ = root["title"].asString();
        api_level_ = root["apilevel"].asInt();
#if OS_ANDROID
        stable_version_ = root["stableversion4android"].asInt();
#else
        stable_version_ = root["stableversion4ios"].asInt();
#endif
    }
}

}  // namespace loader
