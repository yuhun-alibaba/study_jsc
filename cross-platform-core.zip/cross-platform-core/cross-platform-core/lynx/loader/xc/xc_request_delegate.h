// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_LOADER_XC_XC_FILE_REQUEST_DELEGATE_H_
#define LYNX_LOADER_XC_XC_FILE_REQUEST_DELEGATE_H_

#include "net/url_request.h"
#include "loader/loader.h"
#include "loader/xc/xc_loader.h"
#include "loader/xc/xc_file.h"

namespace loader {
class XCRequestDelegate: public net::URLRequestDelegate {
 public:
    XCRequestDelegate(XCLoader* loader, int type);
    ~XCRequestDelegate();
    virtual void OnSuccess(base::PlatformString& url,
                        base::PlatformString& response);
    virtual void OnFailed(base::PlatformString& url,
                        base::PlatformString& error);

 private:
    XCLoader* loader_;
    int type_;
};
}  // namespace loader

#endif  // LYNX_LOADER_XC_XC_FILE_REQUEST_DELEGATE_H_
