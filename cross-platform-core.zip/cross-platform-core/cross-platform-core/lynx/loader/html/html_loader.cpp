// Copyright 2017 The Lynx Authors. All rights reserved.

#include "config/global_config_data.h"
#include "net/url_request_context.h"
#include "net/url_parser.h"
#include "loader/html/html_loader.h"
#include "runtime/runtime.h"
#include "loader/html/html_request_delegate.h"

namespace loader {

    std::string ToCompleteUrl(const std::string& url, const std::string& ref_url) {
        net::URLParser parser(ref_url);
        std::string converted_url = parser.URLWithoutParams();

        if (strncmp(url.c_str(), "http", 4) == 0) {
            converted_url = url;
        } else if (strncmp(url.c_str(), "./", 2) == 0) {
            converted_url = url.substr(1, url.size());
            converted_url = parser.BaseUrl() + converted_url;
        } else if (strncmp(url.c_str(), "/", 1) == 0) {
            converted_url = parser.BaseUrl() + url;
        } else {
            converted_url = parser.URLWithoutParams() + "/" + url;
        }

        return converted_url;
    }

    HTMLLoader::HTMLLoader(jscore::Runtime* runtime)
            : request_(net::URLRequestContext::CreateRequest(reinterpret_cast<long>(runtime))),
              runtime_(runtime), script_loader_(new ScriptLoader(runtime, false)) {
    }

    HTMLLoader::~HTMLLoader() {

    }

    void HTMLLoader::Load(const std::string& data, int type) {
        switch (type) {
            case MAIN_FILE:
                html_url_ = data;
                if (!LoadFromCache(data)) {
                    request_->Fetch(data, new HTMLRequestDelegate(this, data));
                }
                break;
            case SCRIPT_FILE:
                std::string url = ToCompleteUrl(data, html_url_);
                script_loader_->Load(url, type);
                break;
        }
    }

    void HTMLLoader::Flush() {
        script_loader_->Flush();
    }

    void HTMLLoader::LoadHTML(const std::string& url, const std::string& data) {
        config::GlobalConfigData::GetInstance()->cache_manager().WriteCache(url, data, MAIN_FILE);
        base::ScopedRefPtr<HTMLLoader> ref(this);
        runtime_->thread_manager()->RunOnUIThread(
                base::Bind(&HTMLLoader::LoadHTMLOnUIThread, ref, url, data));
    }

    void HTMLLoader::LoadHTMLOnUIThread(const std::string& url, const std::string& data) {
        runtime_->LoadHTML(data);
    }

    bool HTMLLoader::LoadFromCache(const std::string& url) {
        std::string data;
        if(config::GlobalConfigData::GetInstance()->cache_manager().ReadCache(url, data, MAIN_FILE)) {
            LoadHTMLOnUIThread(url, data);
            return true;
        }
        return false;
    }
}