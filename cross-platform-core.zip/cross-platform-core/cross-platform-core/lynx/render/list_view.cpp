// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/cell_view.h"
#include "render/list_view.h"
#include "render/impl/render_command.h"
#include "render/render_object_type.h"

namespace lynx {

ListView::ListView(jscore::ThreadManager* manager,
                   const char* tag_name,
                   uint64_t id,
                   RenderTreeHost* host)
    : RenderObject(tag_name,
                   LYNX_LISTVIEW,
                   id,
                   RenderObjectImpl::Create(manager, LYNX_LISTVIEW),
                   host) {
    style_.set_flex_direction(CSSFLEX_DIRECTION_COLUMN);
}

    ListView::~ListView() {

    }

base::Size ListView::Measure(int width, int height) {
    if (IsDirty()) {
        CSSStaticLayout::Measure(this, width, height);
    }
    measured_size_.width_ = base::Size::Descriptor::GetSize(width);
    measured_size_.height_ = 0;

    RenderObject* child = static_cast<RenderObject*>(FirstChild());
    while (child) {
        measured_size_.height_ += child->measured_size_.height_;
        child = static_cast<RenderObject*>(child->Next());
    }

    if (measured_size_.height_ < height) {
        measured_size_.height_ = base::Size::Descriptor::GetSize(height);;
    }

    return measured_size_;
}

void ListView::Layout(int left, int top, int right, int bottom) {
    RenderObject::Layout(left, top, right, bottom);

    int item_top = 0;
    int item_width = right - left;

    RenderObject* child = static_cast<RenderObject*>(FirstChild());
    while (child)  {
        int item_height = child->GetMeasuredSize().height_;
        child->Layout(0, item_top, item_width, item_top + item_height);
        item_top += item_height;
        child = static_cast<RenderObject*>(child->Next());
    }
    set_scroll_height(item_top);
}

void ListView::InsertChild(ContainerNode* child, int index) {
    RenderObject* render_object = NULL;
    if (static_cast<RenderObject*>(child)->render_object_type()
            == LYNX_LISTSHADOW) {
        render_object = static_cast<RenderObject*>(child);

    } else {
        CellView* cell =
            new CellView(impl()->thread_manager(), render_tree_host());
        cell->InsertChild(static_cast<RenderObject*>(child), 0);
        render_object = cell;
        container_.Add(render_object);
    }

    if (!render_object) return;

    RenderObject::InsertChild(render_object, index);
}

void ListView::InsertBefore(RenderObject* child, RenderObject* reference) {
    int index = -1;
    if (reference != NULL) {
        index = 0;
        RenderObject* child = static_cast<RenderObject *>(FirstChild());
        while (child) {
            if (child == reference || child->Find(0) == reference) {
                break;
            }
            index++;
            child = static_cast<RenderObject *>(child->Next());
        }
    }

    InsertChild(child, index);
}

void ListView::RemoveChild(ContainerNode* child) {
    RenderObject* cell = static_cast<RenderObject *>(FirstChild());
    int index = 0;
    while (cell) {
        if (cell == child || cell->Find(0) == child) {
            break;
        }
        index++;
        cell = static_cast<RenderObject *>(cell->Next());
    }

    RenderObject::RemoveChild(cell);
    container_.Remove(cell);
}
}  // namespace lynx
