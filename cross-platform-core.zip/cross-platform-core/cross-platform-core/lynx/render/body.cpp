// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/body.h"
#include "render/touch/touch_dispatcher.h"
#include "render/impl/render_command.h"
#include "render/render_object_type.h"

namespace lynx {

#define FRAME_RATE_INRERVAL_TIME 17

Body::Body(jscore::ThreadManager* manager, RenderTreeHost* host):
    View("body", LYNX_BODY, -1,
        RenderObjectImpl::Create(manager, LYNX_BODY),
        host),
    thread_manager_(manager),
    body_size_(),
    did_first_layout_(false),
    touch_dispatcher_(new TouchDispatcher(this)),
    weak_ptr_(this) {
}

void Body::Layout() {
    if (IsDirty()) {
        View::Measure(body_size_.width_, body_size_.height_);
        View::Layout(0, 0, body_size_.width_, body_size_.height_);
    }
}

void Body::Layout(int left, int top, int right, int bottom) {
    if (IsDirty()) {
        int width = right - left;
        int height = bottom - top;
        View::Measure(width, height);
        View::Layout(0, 0, width, height);
    }
}

void Body::LayoutWithTick(int tick) {
    Layout();
    thread_manager_->RunOnJSThreadDelay(
        base::Bind(&Body::LayoutWithTick, weak_ptr_, tick), tick);
}

void Body::DispatchEvent(const std::string& event, base::ScopedPtr<jscore::JSArray> args) {
    if (TouchEventInfo::IsTouchEvent(event) ||
            TouchEventInfo::IsMotionEvent(event)) {
        TouchEventInfo info = TouchEventInfo::MakeInfo(args.Get());
        //touch_dispatcher_->DispatchTouchEvent(info);
    } else {
        EventTarget::DispatchEvent(event, args);
    }
}
}  // namespace lynx
