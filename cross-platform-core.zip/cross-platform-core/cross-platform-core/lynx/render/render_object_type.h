//
//  element_type.h
//  lynx-ios
//
//  Created by dli on 11/7/16.
//  Copyright © 2016 dli. All rights reserved.
//

#ifndef LYNX_RENDER_RENDER_OBJECT_TYPE_H_
#define LYNX_RENDER_RENDER_OBJECT_TYPE_H_

namespace lynx {
enum RenderObjectType {
    LYNX_NONE = -1,
    LYNX_BODY,
    LYNX_VIEW,
    LYNX_LABEL,
    LYNX_LISTVIEW,
    LYNX_CELLVIEW,
    LYNX_LISTSHADOW,
    LYNX_IMAGEVIEW,
    LYNX_SCROLLVIEW,
    LYNX_INPUT,
    LYNX_SLIDER_IMAGE,
    LYNX_SLIDER_VIEW,
    LYNX_LAYOUT_VIEW,
};
}  // namespace lynx

#endif  // LYNX_RENDER_RENDER_OBJECT_TYPE_H_
