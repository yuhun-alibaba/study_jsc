// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render_object_proxy_ios.h"
#include "platform_render_impl.h"
#include "lynx_ui_list_view.h"
#include "render_object.h"
#include "common.h"

using namespace base;

namespace lynx {

    RenderObjectProxyIOS::RenderObjectProxyIOS(jscore::ThreadManager* manager,RenderObjectType type) :RenderObjectImpl(manager, type){

    }

    lynx::PlatformRenderImpl* RenderObjectProxyIOS::CreatePlatformRenderImpl() {
        platform_render_impl_.Reset(PlatformRenderImpl::New(this));
        RenderObjectProxyIOS* child = static_cast<RenderObjectProxyIOS*>(FirstChild());
        while(child) {
            child->CreatePlatformRenderImpl();
            platform_render_impl_->InsertChild(child, -1);
            child = static_cast<RenderObjectProxyIOS*>(child->Next());
        }
        return platform_render_impl_.Get();
    }

    void RenderObjectProxyIOS::SetPosition(const Position& position) {
        position_ = position;
        if(platform_render_impl_.Get() != NULL) {
            platform_render_impl_->SetPosition(position);
        }
    }

    void RenderObjectProxyIOS::SetSize(const base::Size& size) {
        size_ = size;
        if(platform_render_impl_.Get() != NULL) {
            platform_render_impl_->SetSize(size);
        }
    }

    void RenderObjectProxyIOS::UpdateStyle(const CSSStyle& style) {
        style_ = style;
        if(platform_render_impl_.Get() != NULL) {
            platform_render_impl_->UpdateStyle(style);
        }
    }


    void RenderObjectProxyIOS::SetText(const std::string& text) {
        text_ = text;
        if(platform_render_impl_.Get() != NULL) {
            platform_render_impl_->SetText(text);
        }
    }

    void RenderObjectProxyIOS::SetAttribute(const std::string& key, const std::string& value) {
        if (!key.empty()) {
            attributes_[key] = value;
            if(platform_render_impl_.Get() != NULL) {
                platform_render_impl_->SetAttribute(key, value);
            }
        }
    }

    void RenderObjectProxyIOS::RequestLayout() {
        if(platform_render_impl_.Get() != NULL) {
            platform_render_impl_->RequestLayout();
        }
    }

    void RenderObjectProxyIOS::InsertChild(RenderObjectImpl* child, int index) {
        ContainerNode::InsertChild(static_cast<RenderObjectProxyIOS*>(child), index);
        if(platform_render_impl_.Get() != NULL) {
            if(static_cast<RenderObjectProxyIOS*>(child)->platform_render_impl_.Get() == NULL) {
                static_cast<RenderObjectProxyIOS*>(child)->CreatePlatformRenderImpl();
            }
            platform_render_impl_->InsertChild(child, index);
        }
        if (render_object_type() == LYNX_LISTSHADOW
            && parent_ != 0
            && static_cast<RenderObjectProxyIOS*>(parent_)->render_object_type() == LYNX_LISTVIEW
            && static_cast<RenderObjectProxyIOS*>(parent_)->platform_render_impl_.Get()) {
            static_cast<PlatformListViewRenderImpl *>(static_cast<RenderObjectProxyIOS*>(parent_)->platform_render_impl_.Get())->NotifyDataChanged();
        }
    }
    
    void RenderObjectProxyIOS::RemoveChild(RenderObjectImpl* child) {
        
    }
    
    void RenderObjectProxyIOS::AddEventListener(const std::string& event) {
        if (event.empty()) {
            return;
        }
        events_.insert(event);
        if(platform_render_impl_.Get() == NULL) {
            return;
        }
        platform_render_impl_->AddEventListener(event);
    }
    
    void RenderObjectProxyIOS::RemoveEventListener(const std::string& event) {
        if (event.empty()) return;
        events_.erase(event);
        if(platform_render_impl_.Get() == NULL) {
            return;
        }
        platform_render_impl_->RemoveEventListener(event);
    }
    
    void RenderObjectProxyIOS::DispatchEvent(const std::string& event, NSMutableArray *array) {
        if (!array) {
            @throw [[NSException alloc]
                    initWithName:@"抛出错误" reason:@"array should not be null !" userInfo:nil];
        }
        void* pass_value = (void*)CFBridgingRetain(array);
        base::ScopedRefPtr<RenderObjectProxyIOS> ref(this);
        thread_manager_->RunOnJSThread(base::Bind(&RenderObjectProxyIOS::DispatchEventOnJSThread, ref, event, pass_value));
    }
    
    void RenderObjectProxyIOS::DispatchEventOnJSThread(const std::string& event, void* array) {
        if (render_object_weak_ptr_.IsValid()) {
            //to-do
            render_object_weak_ptr_->DispatchEvent(event, base::ScopedPtr<jscore::JSArray>());
        }
    }
    
    void RenderObjectProxyIOS::SyncBaseAttr(RenderObjectAttr attr, id value) {
        base::Value value_transformed = ConvertToValue(attr, value);
        base::ScopedRefPtr<RenderObjectProxyIOS> ref(this);
        thread_manager_->RunOnJSThread(base::Bind(&RenderObjectProxyIOS::SyncBaseAttrOnJSThread, ref, attr, value_transformed));
    }
    
    base::Value RenderObjectProxyIOS::ConvertToValue(RenderObjectAttr attr, id value) {
        base::Value value_transformed;
        switch (attr) {
            case SCROLL_TOP:
                {
                    NSNumber *num = SAFE_CONVERT(value, NSNumber);
                    value_transformed.data_.i = [num intValue];
                }
                break;
            case SCROLL_LEFT:
                {
                    NSNumber *num = SAFE_CONVERT(value, NSNumber);
                    value_transformed.data_.i = [num intValue];
                }
                break;
            default:
                break;
        }
        return value_transformed;
    }
    
    void RenderObjectProxyIOS::SyncBaseAttrOnJSThread(int attr, base::Value value) {
        if (render_object_weak_ptr_.IsValid()) {
            render_object_weak_ptr_->SyncAttr(attr, value);
        }
    }
    
    void RenderObjectProxyIOS::SetBaseAttribute(int attr, base::Value value) {
        platform_render_impl_->SetBaseAttribute((RenderObjectAttr) attr, ConvertToOCValue((RenderObjectAttr) attr, value));
    }
    
    id RenderObjectProxyIOS::ConvertToOCValue(RenderObjectAttr attr, base::Value& value) {
        switch (attr) {
            case SCROLL_TOP:
                return [NSNumber numberWithInt:value.data_.i];
                break;
            case SCROLL_LEFT:
                return [NSNumber numberWithInt:value.data_.i];
                break;
            default:
                break;
        }
        return nil;
    }
    
}
