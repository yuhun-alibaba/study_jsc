// Copyright 2017 The Lynx Authors. All rights reserved.

#import <CoreGraphics/CGGeometry.h>
#import "style_convector.h"
#include "lynx_ui_label.h"
#include "common.h"

namespace lynx {
    
    PlatformLabelRenderImpl::PlatformLabelRenderImpl(RenderObjectProxyIOS* proxy) : PlatformRenderImpl(proxy) {
        platform_view_ = [[LynxUILable alloc]initWithRenderObjectProxy:static_cast<RenderObjectProxyIOS*>(proxy)];
        platform_view_.clipsToBounds = YES;
        LinkRenderObjectProxy(proxy);
    }
    
    void PlatformLabelRenderImpl::UpdateStyle(const CSSStyle& style) {
        if (!platform_view_) {
            return;
        }
        LynxUILable* label = SAFE_CONVERT(platform_view_, LynxUILable);
        platform_view_.backgroundColor = [UIColor clearColor];
        platform_view_.alpha = style.opacity_;
        label.textColor = COLOR_CONVERT(style.font_color_);
        label.textAlignment = [CSSStyleConvector ConvectToTextAlignment:style.text_align_];
        if (style.font_weight_ == CSSTEXT_FONT_WEIGHT_BOLD) {
            label.font = [UIFont fontWithName:@ "Arial Rounded MT Bold"  size:(style.font_size_)];
        } else {
            label.font = [UIFont systemFontOfSize:style.font_size_];
        }
        
    }
    
    void PlatformLabelRenderImpl::SetText(const std::string& text) {
        if (!text.empty()) {
            ((UILabel *)platform_view_).text = [NSString stringWithUTF8String:text.c_str()];
        }
    }
    
    void PlatformLabelRenderImpl::LinkRenderObjectProxy(RenderObjectProxyIOS* proxy) {
        SetPosition(proxy->position_);
        SetText(proxy->text_);
        UpdateStyle(proxy->style_);
    }
}

@implementation LynxUILable

- (void)layoutSubviews {
    [super layoutSubviews];
}

- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy {
    self = [super init];
    if(self != nil) {
        proxy_ = proxy;
    }
    return self;
}

@end
