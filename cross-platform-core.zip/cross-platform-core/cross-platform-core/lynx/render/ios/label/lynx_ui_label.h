// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_UI_LABEL_H_
#define LYNX_UI_LABEL_H_

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include "platform_render_impl.h"
#include "render_object_proxy_ios.h"

@interface LynxUILable : UILabel {
    @private
    lynx::RenderObjectProxyIOS* proxy_;
}
- (void)layoutSubviews;
- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy;
@end

namespace lynx {
    
    class PlatformLabelRenderImpl : public PlatformRenderImpl {
    public:
        PlatformLabelRenderImpl(RenderObjectProxyIOS* proxy);
        virtual ~PlatformLabelRenderImpl() {}
        virtual void UpdateStyle(const CSSStyle& style);
        virtual void SetText(const std::string& text);
        virtual void LinkRenderObjectProxy(RenderObjectProxyIOS* proxy);
    };
}





#endif /* LYNX_UI_LABEL_H_ */
