// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_UI_VIEW_H_
#define LYNX_UI_VIEW_H_

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include "platform_render_impl.h"
#include "render_object_proxy_ios.h"

@interface LynxUIView : UIView {
    @protected
    lynx::RenderObjectProxyIOS* proxy_;
    UITapGestureRecognizer* single_tap_;
}
- (void)layoutSubviews;
- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy;
- (void)addEvent:(const std::string&)event;
- (void)removeEvent:(const std::string&)event;
@end

namespace lynx {
    
    class PlatformViewRenderImpl : public PlatformRenderImpl {
    public:
        PlatformViewRenderImpl(RenderObjectProxyIOS* proxy);
        virtual ~PlatformViewRenderImpl() {}
    
        virtual void InsertChild(RenderObjectImpl* child, int index);
        virtual void UpdateStyle(const CSSStyle& style);
        virtual void AddEventListener(const std::string& event);
        virtual void RemoveEventListener(const std::string& event);
        virtual void LinkRenderObjectProxy(lynx::RenderObjectProxyIOS* proxy);
    };
}

#endif /* LYNX_UI_VIEW_H_ */
