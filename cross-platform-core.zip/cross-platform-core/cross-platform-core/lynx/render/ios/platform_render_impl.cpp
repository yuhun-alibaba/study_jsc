// Copyright 2017 The Lynx Authors. All rights reserved.

#include "platform_render_impl.h"
#include "render_object_type.h"
#include "render_object_proxy_ios.h"
#include "lynx_view.h"
#include "lynx_ui_label.h"
#include "lynx_ui_view.h"
#include "lynx_ui_list_view.h"
#include "lynx_ui_image.h"
#include "lynx_ui_scrollview.h"

namespace lynx {
    
    PlatformRenderImpl* PlatformRenderImpl::New(lynx::RenderObjectImpl *proxy) {
        PlatformRenderImpl* render_impl = NULL;
        switch (proxy->render_object_type()) {
            case LYNX_BODY:
                render_impl = new PlatformBodyRenderImpl(static_cast<RenderObjectProxyIOS*>(proxy));
                break;
            case LYNX_VIEW:
            case LYNX_CELLVIEW:
            case LYNX_LISTSHADOW:
                render_impl = new PlatformViewRenderImpl(static_cast<RenderObjectProxyIOS*>(proxy));
                break;
            case LYNX_LABEL:
                render_impl = new PlatformLabelRenderImpl(static_cast<RenderObjectProxyIOS*>(proxy));
                break;
            case LYNX_LISTVIEW:
                render_impl = new PlatformListViewRenderImpl(static_cast<RenderObjectProxyIOS*>(proxy));
                break;
            case LYNX_IMAGEVIEW:
                render_impl = new PlatformImageRenderImpl(static_cast<RenderObjectProxyIOS*>(proxy));
                break;
            case LYNX_SCROLLVIEW:
                render_impl = new PlatformScrollViewRenderImpl(static_cast<RenderObjectProxyIOS*>(proxy));
                break;
            default:
                break;
        }
        return render_impl;
    }
    
    void PlatformRenderImpl::SetPosition(const base::Position& position) {
        RenderObjectProxyIOS* proxy = static_cast<RenderObjectProxyIOS*>(proxy_);
        proxy->position_ = position;
        if(proxy->position_.IsEmpty() || !platform_view_) return;
        platform_view_.frame = CGRectMake(proxy->position_.left_,
                                          proxy->position_.top_,
                                          proxy->position_.GetWidth(),
                                          proxy->position_.GetHeight());
        printf("view: %p, w: %d, h: %d\n", platform_view_, proxy->position_.GetWidth(), proxy->position_.GetHeight());
    }
}
