// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef render_object_attr_h
#define render_object_attr_h
namespace lynx {
    enum RenderObjectAttr {
        SCROLL_TOP = 0,
        SCROLL_LEFT = 1,
    };
}

#endif /* render_object_attr_h */
