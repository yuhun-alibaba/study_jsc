// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_UI_LIST_VIEW_H_
#define LYNX_UI_LIST_VIEW_H_

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include "platform_render_impl.h"
#include "listview_controller.h"

@interface LynxUIListView : UITableView
{
    @private
    lynx::RenderObjectProxyIOS* proxy_;
}
- (void)layoutSubviews;
- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy;

@end

namespace lynx {
    class PlatformListViewRenderImpl : public PlatformRenderImpl {
    public:
        PlatformListViewRenderImpl(RenderObjectProxyIOS* proxy);
        virtual ~PlatformListViewRenderImpl() {}
        virtual void InsertChild(RenderObjectImpl* child, int index);
        virtual void UpdateStyle(const CSSStyle& style);
        virtual void RequestLayout();
        virtual void AddEventListener(const std::string& event);
        virtual void RemoveEventListener(const std::string& event);
        virtual void LinkRenderObjectProxy(lynx::RenderObjectProxyIOS* proxy);
        virtual void NotifyDataChanged();
        virtual void SetBaseAttribute(RenderObjectAttr attr, id value);
        
    private:
        PlatformUIListViewController *controller_;
    };
}
#endif /* LYNX_UI_LIST_VIEW_H_ */
