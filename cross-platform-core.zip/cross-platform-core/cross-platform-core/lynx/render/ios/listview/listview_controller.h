// Copyright 2017 The Lynx Authors. All rights reserved.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include "platform_render_impl.h"
#include "render_object_proxy_ios.h"
#include <vector>

@interface PlatformUIListViewController : NSObject <UITableViewDataSource, UITableViewDelegate>
{
    std::vector<lynx::RenderObjectProxyIOS *> children_;
    UITableView *table_view_;
    lynx::RenderObjectProxyIOS* proxy_;
    bool scroll_event_enable;
}

- (instancetype) init:(UITableView *)table_view WithProxy:(lynx::RenderObjectProxyIOS*)proxy;
- (void) dataSetChange:(lynx::RenderObjectProxyIOS *)proxy;
- (void) setScrollEventEnable:(bool) enable;
@end

