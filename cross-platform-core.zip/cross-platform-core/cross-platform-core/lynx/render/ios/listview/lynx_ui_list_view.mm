// Copyright 2017 The Lynx Authors. All rights reserved.

#include "lynx_ui_list_view.h"
#include "common.h"


namespace lynx {
    PlatformListViewRenderImpl::PlatformListViewRenderImpl(RenderObjectProxyIOS* proxy) : PlatformRenderImpl(proxy) {
        if(proxy->render_object_type() == LYNX_LISTVIEW) {
            platform_view_ = [[LynxUIListView alloc] initWithRenderObjectProxy: static_cast<RenderObjectProxyIOS*>(proxy)];
            controller_ = [[PlatformUIListViewController alloc] init:(UITableView *)platform_view_ WithProxy:proxy];
            ((LynxUIListView *)platform_view_).dataSource = controller_;
            ((LynxUIListView *)platform_view_).delegate = controller_;
            LinkRenderObjectProxy(proxy);
        }
    }

    
    void PlatformListViewRenderImpl::UpdateStyle(const CSSStyle& style) {
        if (!platform_view_) {
            return;
        }
        platform_view_.backgroundColor = COLOR_CONVERT(style.background_color_);
        platform_view_.alpha = style.opacity_;
    }
    
    void PlatformListViewRenderImpl::InsertChild(RenderObjectImpl* child, int index) {
        [controller_ dataSetChange:static_cast<RenderObjectProxyIOS*>(proxy_)];
    }
    
    void PlatformListViewRenderImpl::RequestLayout() {
        [controller_ dataSetChange:static_cast<RenderObjectProxyIOS*>(proxy_)];
    }
    
    void PlatformListViewRenderImpl::LinkRenderObjectProxy(lynx::RenderObjectProxyIOS* proxy) {
        UpdateStyle(proxy->style_);
        SetPosition(proxy->position_);
    }
    
    void PlatformListViewRenderImpl::NotifyDataChanged() {
        [controller_ dataSetChange:static_cast<RenderObjectProxyIOS*>(proxy_)];
    }
    
    void PlatformListViewRenderImpl::AddEventListener(const std::string& event) {
        if (event.compare("scroll") == 0) {
            [controller_ setScrollEventEnable:true];
        }
    }
    
    void PlatformListViewRenderImpl::RemoveEventListener(const std::string& event) {
        if (event.compare("scroll") == 0) {
            [controller_ setScrollEventEnable:false];
        }
    }
    
    void PlatformListViewRenderImpl::SetBaseAttribute(RenderObjectAttr attr, id value) {
        LynxUIListView *listView = SAFE_CONVERT(platform_view_, LynxUIListView);
        switch (attr) {
            case SCROLL_LEFT:
                [listView setContentOffset:CGPointMake([SAFE_CONVERT(value, NSNumber) intValue], 0) animated:YES];
                break;
            case SCROLL_TOP:
                [listView setContentOffset:CGPointMake(0, [SAFE_CONVERT(value, NSNumber) intValue]) animated:YES];
                break;
            default:
                break;
        }
    }
}

@implementation LynxUIListView

- (void)layoutSubviews {
    [super layoutSubviews];
}

- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy {
    self = [super init];
    if(self != nil) {
        proxy_ = proxy;
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return self;
}
@end
