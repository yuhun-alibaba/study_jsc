// Copyright 2017 The Lynx Authors. All rights reserved.

#import "listview_controller.h"
#import "render_object_attr.h"

@implementation PlatformUIListViewController

- (instancetype) init:(UITableView *)table_view WithProxy:(lynx::RenderObjectProxyIOS*)proxy
{
    table_view_ = table_view;
    proxy_ = proxy;
    scroll_event_enable = false;
    return self;
}

- (void)dataSetChange:(lynx::RenderObjectProxyIOS *)proxy {
    children_.clear();
    [self buildChidrenProxy:proxy];
    [table_view_ reloadData];
}

-(void)buildChidrenProxy:(lynx::RenderObjectProxyIOS *)proxy
{
    lynx::RenderObjectProxyIOS* child = static_cast<lynx::RenderObjectProxyIOS *>(proxy->FirstChild());
    while(child) {
        if (child->render_object_type() == lynx::LYNX_LISTSHADOW) {
            [self buildChidrenProxy:child];
        } else {
            children_.push_back(child);
        }
        child = static_cast<lynx::RenderObjectProxyIOS*>(child->Next());
    }
}

-(NSInteger) tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (children_.empty()) {
        return 0;
    }
    int count = (int) children_.size();
    return count;
}

-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] init];
    // 设置listview的cell背景透明
    cell.backgroundColor = [UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];
    // 去除press后的颜色变化
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.contentView.clipsToBounds = YES;
    cell.clipsToBounds = YES;
    NSInteger row = [indexPath row];
    lynx::RenderObjectProxyIOS *element = (lynx::RenderObjectProxyIOS *)(children_.at((int)row));
    UIView * child_view = [self buildChildView:element];
    [cell.contentView addSubview:child_view];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger row = [indexPath row];
    lynx::RenderObjectProxyIOS *element = (lynx::RenderObjectProxyIOS *)(children_.at((int)row));
    CGFloat height = element->position_.GetHeight();
    return height;
}

- (UIView *) buildChildView:(lynx::RenderObjectProxyIOS *)proxy {
    if (!proxy->GetPlatformRenderImpl()) {
        proxy->CreatePlatformRenderImpl();
    }
    UIView * view = proxy->GetPlatformRenderImpl()->GetPlatformUI();
    return view;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
}

- (void) scrollViewDidScroll:(UIScrollView *)scrollView {
    proxy_->SyncBaseAttr(lynx::RenderObjectAttr::SCROLL_TOP, [NSNumber numberWithUnsignedInteger:scrollView.contentOffset.y]);
    if (scroll_event_enable) {
        NSMutableArray *array = [[NSMutableArray alloc] init];
        NSMutableDictionary *event = [[NSMutableDictionary alloc] init];
        [event setValue:@"scroll" forKey:@"type"];
        array[0] = event;
        proxy_->DispatchEvent("scroll", array);
    }
}

- (void) setScrollEventEnable:(bool) enable {
    scroll_event_enable = enable;
}

@end
