// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render_tree_host_impl_ios.h"

namespace lynx {
    
    RenderTreeHostImplIOS::RenderTreeHostImplIOS(jscore::ThreadManager* thread_manager, RenderTreeHost* host, RenderObjectImpl* root) : RenderTreeHostImpl(thread_manager, host, root) {
        
    }
    
    RenderTreeHostImplIOS::~RenderTreeHostImplIOS() {
        
    }

    void RenderTreeHostImplIOS::OnVSync() {
        DoRenderAction();
    }
    
    void RenderTreeHostImplIOS::BeginFrame() {
        RenderTreeHostImpl::BeginFrame();
    }
    
    void RenderTreeHostImplIOS::PrepareCommit() {
        
    }
    
}