// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef lynx_ui_scrollview_h
#define lynx_ui_scrollview_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include "platform_render_impl.h"
#include "render_object_proxy_ios.h"

@interface LynxUIScrollView : UIScrollView<UIScrollViewDelegate> {
@private
    lynx::RenderObjectProxyIOS* proxy_;
}
- (void)layoutSubviews;
- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy;
@end

namespace lynx {
    
    class PlatformScrollViewRenderImpl : public PlatformRenderImpl {
    public:
        PlatformScrollViewRenderImpl(RenderObjectProxyIOS* proxy);
        virtual ~PlatformScrollViewRenderImpl() {}
        virtual void InsertChild(RenderObjectImpl* child, int index);
        virtual void UpdateStyle(const CSSStyle& style);
        virtual void SetPosition(const base::Position& position);
        virtual void SetBaseAttribute(RenderObjectAttr attr, id value);
        virtual void LinkRenderObjectProxy(RenderObjectProxyIOS* proxy);
    };
}
#endif /* lynx_ui_scrollview_h */
