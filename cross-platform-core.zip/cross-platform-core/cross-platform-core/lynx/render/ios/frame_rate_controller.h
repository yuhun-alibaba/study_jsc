// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef frame_rate_controller_h
#define frame_rate_controller_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include "render_tree_host_impl_ios.h"

@interface FrameRateController : NSObject
{
@private
    lynx::RenderTreeHostImpl::VSyncListener* vsync_listener_;
    CADisplayLink* display_link_;
}
-(instancetype)initWithVSyncListener:(lynx::RenderTreeHostImpl::VSyncListener*) vsync_listener;
-(void) start;
-(void) stop;
@end

#endif /* frame_rate_controller_h */
