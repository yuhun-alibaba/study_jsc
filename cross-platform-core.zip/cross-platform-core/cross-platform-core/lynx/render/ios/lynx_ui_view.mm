// Copyright 2017 The Lynx Authors. All rights reserved.

#import <CoreGraphics/CGGeometry.h>
#include "lynx_ui_view.h"
#include "common.h"

namespace lynx {
    
    PlatformViewRenderImpl::PlatformViewRenderImpl(RenderObjectProxyIOS* proxy) : PlatformRenderImpl(proxy) {
        if(proxy_->render_object_type() != LYNX_BODY &&
            proxy_->render_object_type() != LYNX_LISTSHADOW) {
            platform_view_ = [[LynxUIView alloc]initWithRenderObjectProxy:static_cast<RenderObjectProxyIOS*>(proxy)];
            LinkRenderObjectProxy(static_cast<RenderObjectProxyIOS*>(proxy));
        }
    }
    
    void PlatformViewRenderImpl::UpdateStyle(const CSSStyle& style) {
        if (!platform_view_) {
            return;
        }
        RenderObjectProxyIOS* proxy = static_cast<RenderObjectProxyIOS*>(proxy_);
        platform_view_.backgroundColor = COLOR_CONVERT(proxy->style_.background_color_);
        platform_view_.alpha = proxy->style_.opacity_;
        // Set border-radius
        if (proxy->style_.border_radius_ > 0) {
            platform_view_.layer.cornerRadius = proxy->style_.border_radius_ ;
            platform_view_.layer.masksToBounds = YES;
        } else {
            platform_view_.layer.masksToBounds = NO;
        }
        // Set border-width & border-color
        if (proxy->style_.border_width_ > 0) {
            platform_view_.layer.borderColor = [COLOR_CONVERT(proxy->style_.border_color_) CGColor];
            platform_view_.layer.borderWidth = proxy->style_.border_width_;
        }
    }
    
    void PlatformViewRenderImpl::InsertChild(RenderObjectImpl* child, int index) {
        RenderObjectProxyIOS* proxy = static_cast<RenderObjectProxyIOS*>(child);
        if (!proxy->GetPlatformRenderImpl()) {
            proxy->CreatePlatformRenderImpl();
        }
        if(index != -1) {
            [platform_view_ insertSubview:static_cast<PlatformRenderImpl*>(proxy->GetPlatformRenderImpl())->GetPlatformUI() atIndex:index];
        }else {
            [platform_view_ addSubview:static_cast<PlatformRenderImpl*>(proxy->GetPlatformRenderImpl())->GetPlatformUI()];
        }
    }
    
    void PlatformViewRenderImpl::AddEventListener(const std::string& event) {
        [(LynxUIView*)platform_view_ addEvent:event];
    }
    
    void PlatformViewRenderImpl::RemoveEventListener(const std::string& event) {
        [(LynxUIView*)platform_view_ removeEvent:event];
    }
    
    void PlatformViewRenderImpl::LinkRenderObjectProxy(lynx::RenderObjectProxyIOS* proxy) {
        UpdateStyle(proxy->style_);
        SetPosition(proxy->position_);
        if (!proxy->events_.empty()) {
            for (std::string event : proxy->events_) {
                AddEventListener(event);
            }
        }
    }
}

@implementation LynxUIView

- (void)layoutSubviews {
    [super layoutSubviews];
}

- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy {
    self = [super init];
    if(self != nil) {
        self.clipsToBounds = YES;
        proxy_ = proxy;
        single_tap_ = [[UITapGestureRecognizer alloc]
                       initWithTarget:self action:@selector(handleSingleTap:)];
    }
    return self;
}

- (void)addEvent:(const std::string&)event {
    [self addGestureRecognizer:single_tap_];
}

- (void)removeEvent:(const std::string&)event {
    [self removeGestureRecognizer:single_tap_];
}

-(void) handleSingleTap:(id)sender
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSMutableDictionary *event = [[NSMutableDictionary alloc] init];
    [event setValue:@"click" forKey:@"type"];
    array[0] = event;
    proxy_->DispatchEvent("click", array);
}

@end
