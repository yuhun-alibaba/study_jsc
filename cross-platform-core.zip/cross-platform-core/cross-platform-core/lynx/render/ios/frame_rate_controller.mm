// Copyright 2017 The Lynx Authors. All rights reserved.

#import "frame_rate_controller.h"


@implementation FrameRateController

-(instancetype)initWithVSyncListener:(lynx::RenderTreeHostImpl::VSyncListener *)vsync_listener
{
    self = [super init];
    if (self) {
        self->display_link_ = [CADisplayLink displayLinkWithTarget:self selector:@selector(onVSync)];
        self->vsync_listener_ = vsync_listener;
    }
    return self;
}

-(void)start
{
    display_link_.paused = NO;
    [display_link_ addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
}

-(void) stop
{
    display_link_.paused = YES;
    [display_link_ removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
}

-(void)onVSync
{
    vsync_listener_->OnVSync();
    display_link_.paused = NO;
}

@end
