// Copyright 2017 The Lynx Authors. All rights reserved.

#include "lynx_ui_scrollview.h"

#include "base/ios/common.h"

namespace lynx {
    
    PlatformScrollViewRenderImpl::PlatformScrollViewRenderImpl(RenderObjectProxyIOS* proxy) : PlatformRenderImpl(proxy) {
        if(proxy->render_object_type() == LYNX_SCROLLVIEW) {
            platform_view_ = [[LynxUIScrollView alloc]initWithRenderObjectProxy:proxy];
            LinkRenderObjectProxy(proxy);
        }
    }
    
    
    void PlatformScrollViewRenderImpl::SetPosition(const base::Position& position) {
        PlatformRenderImpl::SetPosition(position);
        if(position.IsEmpty() || !platform_view_) return;
        RenderObjectProxyIOS* current =static_cast<RenderObjectProxyIOS*>(proxy());
        RenderObjectProxyIOS* child = static_cast<RenderObjectProxyIOS*>(current->FirstChild());
        int contentWidth = 0;
        int contentHeight = 0;
        while(child) {
            contentWidth += child->position_.GetWidth();
            contentHeight += child->position_.GetHeight();
            child = static_cast<RenderObjectProxyIOS*>(child->Next());
        }
        if (contentHeight > position.GetHeight()) {
            contentHeight = position.GetHeight();
        }
        if (contentWidth < position.GetWidth()) {
            contentWidth = position.GetWidth();
        }
        ((LynxUIScrollView *)platform_view_).contentSize = CGSizeMake(contentWidth, contentHeight);
    }
    
    void PlatformScrollViewRenderImpl::UpdateStyle(const CSSStyle& style) {
        if (!platform_view_) {
            return;
        }
        platform_view_.backgroundColor = COLOR_CONVERT(style.background_color_);
        platform_view_.alpha = style.opacity_;
        // 设置圆角
        if (style.border_radius_ > 0) {
            platform_view_.layer.cornerRadius = style.border_radius_ ;
        } else {
            platform_view_.layer.cornerRadius = 0;
        }
        // 设置边框
        if (style.border_width_ > 0) {
            platform_view_.layer.borderColor = [COLOR_CONVERT(style.border_color_) CGColor];
            platform_view_.layer.borderWidth = style.border_width_;
        }
    }
    
    void PlatformScrollViewRenderImpl::InsertChild(RenderObjectImpl* child, int index) {
        RenderObjectProxyIOS* proxy = static_cast<RenderObjectProxyIOS*>(child);
        if (!proxy->GetPlatformRenderImpl()) {
            proxy->CreatePlatformRenderImpl();
        }
        if(index != -1) {
            [platform_view_ insertSubview:static_cast<PlatformRenderImpl*>(proxy->GetPlatformRenderImpl())->GetPlatformUI() atIndex:index];
        }else {
            [platform_view_ addSubview:static_cast<PlatformRenderImpl*>(proxy->GetPlatformRenderImpl())->GetPlatformUI()];
        }
    }
    
    void PlatformScrollViewRenderImpl::SetBaseAttribute(RenderObjectAttr attr, id value) {
        LynxUIScrollView *scrollView = SAFE_CONVERT(platform_view_, LynxUIScrollView);
        switch (attr) {
            case SCROLL_LEFT:
                [scrollView setContentOffset:CGPointMake([SAFE_CONVERT(value, NSNumber) intValue], 0) animated:YES];
                break;
            case SCROLL_TOP:
                [scrollView setContentOffset:CGPointMake(0, [SAFE_CONVERT(value, NSNumber) intValue]) animated:YES];
                break;
            default:
                break;
        }
    }
    
    void PlatformScrollViewRenderImpl::LinkRenderObjectProxy(RenderObjectProxyIOS* proxy) {
        UpdateStyle(proxy->style_);
        SetPosition(proxy->position_);
    }
}

@implementation LynxUIScrollView

- (void)layoutSubviews {
    [super layoutSubviews];
}

- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy {
    self = [super init];
    if(self != nil) {
        proxy_ = proxy;
        self.contentOffset = CGPointZero;
        self.scrollEnabled = YES;
        self.showsVerticalScrollIndicator = FALSE;
        self.showsHorizontalScrollIndicator = FALSE;
        // clipsToBound and maskToBounds are are functionally equivalent
        // http://stackoverflow.com/questions/1177775/how-is-the-relation-between-uiviews-clipstobounds-and-calayers-maskstobounds
        self.clipsToBounds = YES;
        self.delegate = self;
    }
    return self;
}

// 是否支持滑动至顶部
- (BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView
{
    return YES;
}

// 滑动到顶部时调用该方法
- (void)scrollViewDidScrollToTop:(UIScrollView *)scrollView
{
    
}

// scrollView 已经滑动
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
}

@end

