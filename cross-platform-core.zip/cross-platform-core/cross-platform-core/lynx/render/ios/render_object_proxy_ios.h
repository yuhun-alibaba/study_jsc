// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RENDER_OBJECT_PROXY_IOS_H_
#define LYNX_RENDER_OBJECT_PROXY_IOS_H_

#import <UIKit/UIKit.h>

#include <string>
#include <unordered_set>
#include "render_object_impl.h"
#include "platform_render_impl.h"
#include "render_object_attr.h"

namespace lynx {
    class RenderObjectProxyIOS :  public ContainerNode, public RenderObjectImpl {
    public:
        
        RenderObjectProxyIOS(jscore::ThreadManager* manager, RenderObjectType type);
        virtual ~RenderObjectProxyIOS() {}
        
        lynx::PlatformRenderImpl* CreatePlatformRenderImpl();
        
        void DispatchEvent(const std::string& event, NSMutableArray *array);
        void SyncBaseAttr(RenderObjectAttr attr, id value);
        inline lynx::PlatformRenderImpl* GetPlatformRenderImpl() {
            return platform_render_impl_.Get();
        }
        
    private:
        virtual void UpdateStyle(const CSSStyle& style);
        virtual void SetPosition(const base::Position& position);
        virtual void SetSize(const base::Size& size);
        virtual void InsertChild(RenderObjectImpl* child, int index);
        virtual void RemoveChild(RenderObjectImpl* child);
        virtual void SetText(const std::string& text);
        virtual void SetAttribute(const std::string& key, const std::string& value);
        virtual void RequestLayout();
        virtual void AddEventListener(const std::string& event);
        virtual void RemoveEventListener(const std::string& event);
        virtual void SetBaseAttribute(int attr, base::Value value);
        
        base::Value ConvertToValue(RenderObjectAttr attr, id value);
        id ConvertToOCValue(RenderObjectAttr attr, base::Value& value);
        void DispatchEventOnJSThread(const std::string& event, void* array);
        void SyncBaseAttrOnJSThread(int attr, base::Value value);

    public:
        base::Position position_;
        base::Size size_;
        lynx::CSSStyle style_;
        
        std::string text_;
        std::map<std::string, std::string> attributes_;
        std::unordered_set<std::string> events_;
        
    private:
        base::ScopedPtr<PlatformRenderImpl> platform_render_impl_;
    };

}

#endif /* LYNX_RENDER_OBJECT_PROXY_IOS_H_ */
