// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_UI_IMAGE_H_
#define LYNX_UI_IMAGE_H_

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include "platform_render_impl.h"
#include "render_object_proxy_ios.h"

@interface LynxUIImage : UIImageView {
@private
    lynx::RenderObjectProxyIOS* proxy_;
}
- (void)layoutSubviews;
- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy;
@end

namespace lynx {
    
    class PlatformImageRenderImpl : public PlatformRenderImpl {
    public:
        PlatformImageRenderImpl(RenderObjectProxyIOS* proxy);
        virtual ~PlatformImageRenderImpl() {}
        virtual void UpdateStyle(const CSSStyle& style);
        virtual void SetAttribute(const std::string& key, const std::string& value);
        virtual void LinkRenderObjectProxy(lynx::RenderObjectProxyIOS* proxy);
    private:
        void SetImageUrl(const std::string& url);
    };
}

#endif /* LYNX_UI_IMAGE_H_ */
