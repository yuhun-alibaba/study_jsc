// Copyright 2017 The Lynx Authors. All rights reserved.

#import "lynx_ui_image.h"
#import "image_downloader.h"
#include "lynx_ui_view.h"
#include "common.h"

namespace lynx {
    
    PlatformImageRenderImpl::PlatformImageRenderImpl(RenderObjectProxyIOS* proxy) : lynx::PlatformRenderImpl(proxy) {
        if(proxy->render_object_type() == LYNX_IMAGEVIEW) {
            platform_view_ = [[LynxUIImage alloc]initWithRenderObjectProxy:proxy];
            LinkRenderObjectProxy(proxy);
        }
    }
    
    void PlatformImageRenderImpl::SetAttribute(const std::string& key, const std::string& value) {
        if (key.empty() || value.empty()) return;
        if(key == "src") {
            SetImageUrl(value);
        }
        
    }
    
    void PlatformImageRenderImpl::UpdateStyle(const CSSStyle& style) {
        if (!platform_view_) {
            return;
        }
        // scale type
        LynxUIImage* imageView = SAFE_CONVERT(platform_view_, LynxUIImage);
        switch(style.css_object_fit_) {
            case CSSIMAGE_OBJECT_FIT_FILL:
                imageView.contentMode = UIViewContentModeScaleToFill;
                break;
            case CSSIMAGE_OBJECT_FIT_CONTAIN:
                imageView.contentMode = UIViewContentModeScaleAspectFit;
                break;
            case CSSIMAGE_OBJECT_FIT_COVER:
                imageView.contentMode = UIViewContentModeScaleAspectFill;
                break;
            default:
                break;
        }
    }
    
    void PlatformImageRenderImpl::SetImageUrl(const std::string& url) {
        if(url.empty()) return;
        [[ImageDownLoader shareInstance] downloadImage: [NSString stringWithCString: (url.c_str())
                                                                           encoding:[NSString defaultCStringEncoding]]
                                                  then:^(UIImage* image){
                                                      [((UIImageView *) platform_view_) setImage:image];
                                                  }];
    }
    
    void PlatformImageRenderImpl::LinkRenderObjectProxy(lynx::RenderObjectProxyIOS* proxy) {
        UpdateStyle(proxy->style_);
        SetImageUrl(proxy->attributes_["src"]);
        SetPosition(proxy->position_);
    }
    
}

@implementation LynxUIImage

- (void)layoutSubviews {
    [super layoutSubviews];
}

- (id)initWithRenderObjectProxy:(lynx::RenderObjectProxyIOS*)proxy {
    self = [super init];
    if(self != nil) {
        proxy_ = static_cast<lynx::RenderObjectProxyIOS*>(proxy);
        
        self.clipsToBounds = YES;
        self.contentMode = UIViewContentModeScaleAspectFill;
    }
    return self;
}

@end
