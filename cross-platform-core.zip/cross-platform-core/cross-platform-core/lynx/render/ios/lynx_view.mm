// Copyright 2017 The Lynx Authors. All rights reserved.

#include "lynx_view.h"
#include "jsc_runtime.h"
#include "css_style.h"

#include "render_object_proxy_ios.h"
#include "config/global_config_data.h"

#include "parser/render_parser.h"

using namespace lynx;

@implementation LynxView

-(id) init
{
    CGRect screenRect = [UIScreen mainScreen].bounds;
    self = [self initWithFrame: CGRectMake(0, 0, screenRect.size.width, screenRect.size.height)];
    return self;
}

-(id) initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        runtime_ = new jscore::JSCRuntime();
        
        config::GlobalConfigData::GetInstance()->SetScreenConfig(frame.size.width, frame.size.height, 1);
        // Create RenderTreeHost
        lynx:RenderTreeHost* render_tree_host = runtime_->SetupRenderHost();
        render_tree_host_impl_ = reinterpret_cast<lynx::RenderTreeHostImplIOS*>(render_tree_host->host_impl());
        
        // Create proxy
        proxy_ = static_cast<lynx::RenderObjectProxyIOS*>(render_tree_host->render_root()->impl());
        
        // Connect RenderTreeHost and BodyView
        lynx::PlatformBodyRenderImpl* body_render_impl = reinterpret_cast<lynx::PlatformBodyRenderImpl*>(proxy_->CreatePlatformRenderImpl());
        body_render_impl->ResetView(self);
        
        // Create FrameRateController
        controller_ = [[FrameRateController alloc] initWithVSyncListener:render_tree_host_impl_];
        
        // Update viewport
        render_tree_host_impl_->UpdateViewport(frame.size.width, frame.size.height);
        
        runtime_->InitRuntime("");
        
        self.clipsToBounds = YES;
        [self setBackgroundColor:[UIColor whiteColor]];
    }
    return self;
}


-(void) loadScriptData:(NSString*)source {
    base::PlatformString scoped_source(source);
    runtime_->RunScript(scoped_source);
}

-(void) loadScriptFile:(NSString*)scriptFile
{
    if (nil != scriptFile)
    {
        NSString* file = [[NSBundle mainBundle] pathForResource:scriptFile ofType:@"js"];
        NSData* fileData = [NSData dataWithContentsOfFile:file];
        if (nil != fileData && fileData.length > 0)
        {
            NSString* scriptString = [[NSString alloc] initWithData:fileData
                                                           encoding:NSUTF8StringEncoding];
            if (nil != scriptString && scriptString.length > 0)
            {
                [self loadScriptData:scriptString];
            }
        }
    }
}

-(void) parseFile:(NSString*)scriptFile
{
    if (nil != scriptFile)
    {
        NSString* file = [[NSBundle mainBundle] pathForResource:scriptFile ofType:@"js"];
        NSData* fileData = [NSData dataWithContentsOfFile:file];
        if (nil != fileData && fileData.length > 0)
        {
            NSString* scriptString = [[NSString alloc] initWithData:fileData
                                                           encoding:NSUTF8StringEncoding];
            if (nil != scriptString && scriptString.length > 0)
            {
                base::PlatformString scoped_source(scriptString);
                parser::RenderParser parser(runtime_->render_tree_host(), runtime_->thread_manager());
                parser.Insert(scoped_source.ToString());
            }
        }
    }
}

-(void) loadUrl:(NSString*)url
{
    runtime_->LoadUrl(std::string([url UTF8String]));
}

- (void)layoutSubviews
{
    [super layoutSubviews];
}

-(void)didMoveToWindow
{
    [super didMoveToWindow];
    if (self.window) {
        [controller_ start];
    } else {
        [controller_ stop];
    }
}

@end
