// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_PLATFORM_ELEMENT_H_
#define LYNX_PLATFORM_ELEMENT_H_

#include "render_object_impl.h"

#import <UIKit/UIKit.h>
#import "render_object_attr.h"

namespace lynx {
    class PlatformRenderImpl {
    public:
        PlatformRenderImpl(RenderObjectImpl* proxy) : proxy_(proxy){}
        
        virtual ~PlatformRenderImpl() {platform_view_ = nil;}
        
        UIView* GetPlatformUI() {return platform_view_;}
        
        bool IsEmpty() {return platform_view_ == nil;}
        
        virtual void UpdateStyle(const CSSStyle& style) {}
        virtual void SetPosition(const base::Position& position);
        virtual void SetSize(const base::Size& size) {}
        virtual void InsertChild(RenderObjectImpl* child, int index) {}
        virtual void InsertChildForListView(RenderObjectImpl* child, int index) {}
        virtual void SetText(const std::string& text) {}
        virtual void SetAttribute(const std::string& key, const std::string& value) {}
        virtual void RequestLayout() {}
        virtual void SetBaseAttribute(RenderObjectAttr attr, id value) {}
        
        virtual void AddEventListener(const std::string& event){}
        virtual void RemoveEventListener(const std::string& event){}
        
        RenderObjectImpl* proxy() {
            return proxy_;
        }
        
        static PlatformRenderImpl* New(RenderObjectImpl* proxy);
    protected:
        RenderObjectImpl* proxy_;
        UIView* platform_view_;
    };
}

#endif /* LYNX_PLATFORM_ELEMENT_H_ */
