// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef lynx_VIEW_H_
#define lynx_VIEW_H_

#import <UIKit/UIKit.h>

#include "lynx_ui_view.h"
#include "runtime.h"
#include "render_object.h"
#include "render_tree_host_impl_ios.h"
#include "frame_rate_controller.h"

@interface LynxView : LynxUIView {
    @private
    jscore::Runtime* runtime_;
    FrameRateController* controller_;
    lynx::RenderTreeHostImplIOS* render_tree_host_impl_;
}

-(id) init;

-(id) initWithFrame:(CGRect)frame;

-(void) loadScriptData:(NSString*)source;

-(void) loadScriptFile:(NSString*)scriptFile;

-(void) parseFile:(NSString*)scriptFile;

-(void) loadUrl:(NSString*)url;

- (void)layoutSubviews;
@end

namespace lynx {
    
    class PlatformBodyRenderImpl : public PlatformViewRenderImpl {
    public:
        PlatformBodyRenderImpl(RenderObjectProxyIOS* proxy) : PlatformViewRenderImpl(proxy) {}
        virtual ~PlatformBodyRenderImpl() {}
        void ResetView(LynxUIView* view) {
            platform_view_ = view;
            LinkRenderObjectProxy(static_cast<lynx::RenderObjectProxyIOS*>(proxy_));
        }
    };
}

#endif /* lynx_VIEW_H_ */
