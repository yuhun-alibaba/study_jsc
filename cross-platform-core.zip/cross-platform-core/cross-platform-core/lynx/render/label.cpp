// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/label.h"
#include "render/label_measurer.h"
#include "render/impl/render_object_impl.h"

namespace lynx {

Label::Label(jscore::ThreadManager* manager,
             const char* tag_name,
             uint64_t id,
             RenderTreeHost* host)
    : RenderObject(tag_name,
                   LYNX_LABEL,
                   id,
                   RenderObjectImpl::Create(manager, LYNX_LABEL),
                   host) {
}

base::Size Label::Measure(int width, int height) {
    width = style_.ClampWidth(base::Size::Descriptor::GetSize(width));
    height = style_.ClampHeight(base::Size::Descriptor::GetSize(height));
    base::Size size =
        LabelMeasurer::MeasureLabelSize(
            base::Size(width, height),
            GetText(),
            style_);
    size.width_ = style_.ClampWidth(size.width_);
    size.height_ = style_.ClampHeight(size.height_);
    measured_size_ = size;
    return size;
}

void Label::Layout(int left, int top, int right, int bottom) {
    RenderObject::Layout(left, top, right, bottom);
}
}  // namespace lynx
