//
//  Element.hpp
//  samples
//
//  Created by dli on 10/27/16.
//
//

#ifndef LYNX_RENDER_RENDER_OBJECT_H_
#define LYNX_RENDER_RENDER_OBJECT_H_

#include <string>

#include "base/position.h"
#include "base/scoped_ptr.h"
#include "base/scoped_ptr_map.h"
#include "base/scoped_vector.h"
#include "base/size.h"
#include "base/value.h"
#include "render/event_target.h"
#include "render/render_tree_host.h"
#include "render/render_object_type.h"
#include "layout/css_style.h"
#include "layout/layout_object.h"
#include "runtime/thread_manager.h"
#include "runtime/js_function.h"

namespace lynx {
class TouchEvent;
class RenderObjectImpl;
class RenderObject : public LayoutObject, public EventTarget {
 public:
    RenderObject(const char* tag_name, RenderObjectType type,
        uint64_t id, RenderObjectImpl* proxy, RenderTreeHost* host);
    virtual ~RenderObject();

    // impl virtual method in LayoutObject
    virtual base::Size Measure(int width, int height) {return base::Size();}
    virtual void Layout(int left, int top, int right, int bottom);
    virtual void SetStyle(const std::string& key, const std::string& value);
    
    void FlushStyle();

    // impl virtual method in ConatinerNode
    virtual void InsertChild(ContainerNode* child, int index);
    virtual void RemoveChild(ContainerNode* child);

    // impl virtual method in EventTarget
    virtual void RegisterEvent(const std::string& event,
        RegisterEventType type);

    void SetText(const std::string& text);
    const std::string& GetText() {return text_;}

    RenderObject* NextSibling();


    void AppendChild(RenderObject* child);

    RenderObject* RemoveChildByIndex(int index);

    virtual void InsertBefore(RenderObject* child, RenderObject* reference);

    void SetAttribute(const std::string& key, const std::string& value);
    bool HasAttribute(const std::string& key);
    void RemoveAttribute(const std::string& key);

    // Sync attributes from element proxy
    void SyncAttr(int attr, base::Value value);

    inline std::string& tag_name() { return tag_name_;}

    inline void set_offset_top(int offset_top) { offset_top_ = offset_top; }

    inline int offset_top() { return offset_top_; }

    inline int offset_left() { return offset_left_; }

    inline int offset_width() { return offset_width_; }

    inline int offset_height() { return offset_height_; }

    inline void set_scroll_height(int scroll_height) {
        scroll_height_ = scroll_height;
    }

    inline int scroll_height() { return scroll_height_; }

    inline void set_scroll_width(int scroll_width) {
        scroll_width_ = scroll_width;
    }

    inline int scroll_width() { return scroll_width_; }

    void SetScrollLeft(int scroll_left);

    inline int scroll_left() { return scroll_left_; }

    void SetScrollTop(int scroll_top);

    inline int scroll_top() { return scroll_top_; }

    inline void SetForceScrollAnimate(bool animate);

    RenderObjectImpl* impl() {
        return impl_.Get();
    }

    const RenderObject* Parent() {
        RenderObject* parent = static_cast<RenderObject*>(parent_);
        if (parent && parent->IsPrivate()) {
            parent = static_cast<RenderObject*>(parent->parent_);
        }
        return parent;
    }

    const RenderObject* Get(int index) {
        return static_cast<RenderObject*>(Find(index));
    }

    const RenderObjectType render_object_type() { return render_object_type_; }

    const bool IsInvisible() {
        return render_object_type_ == LYNX_LAYOUT_VIEW;
    }

    const bool IsPrivate() {
        return render_object_type_ == LYNX_CELLVIEW;
    }

    void SetHost(RenderTreeHost* host) {
        render_tree_host_ = host;
    }

    RenderTreeHost* render_tree_host() {
        return render_tree_host_;
    }

    void SetJSRef(void* js_ref) {
        SetTarget(js_ref);
    }

    void* GetJSRef() {
        return GetTarget();
    }

    void PerformTouch(TouchEvent* event);
    void PerformMotion(TouchEvent* event);
    void OnCapturingTouchEvent(TouchEvent* event);
    bool IsEventListenerEmpty();
    const std::vector<RenderObject*> GetFixedNodes();

    uint64_t id() {
        return id_;
    }

 private:
    enum RENDER_OBJECT_ATTRS {
        SCROLL_TOP,
        SCROLL_LEFT,
        GET_TEXT
    };

    void GetVisiableChildren(RenderObject* renderer,
        std::vector<RenderObject *>& visible_chidren);
    void RecalcLayoutPosition(base::Position& position);
    void HandleFixedStyle();
    void AddFixedChildIfHave(RenderObject* child);
    void RemoveFixedChildIfHave(RenderObject* removed);
    void AddFixedChild(RenderObject* fixed_child);
    void RemoveFixedChild(RenderObject* fixed_child);
    

    // Set attributes from v8 and will sync to element proxy
    void SetBaseAttr(int attr, base::Value value);

    std::string tag_name_;
    uint64_t id_;

    int offset_top_;
    int offset_left_;
    int offset_width_;
    int offset_height_;

    int scroll_height_;
    int scroll_width_;
    int scroll_top_;
    int scroll_left_;

    std::string text_;

    std::map<std::string, std::string> attributes_;

    bool is_fixed_;
    std::vector<RenderObject*> fixed_children_;

    RenderObjectType render_object_type_;

    base::ScopedRefPtr<RenderObjectImpl> impl_;

    RenderTreeHost* render_tree_host_;

    base::WeakPtr<RenderObject> weak_ptr_;

    DISALLOW_COPY_AND_ASSIGN(RenderObject);
};

}  // namespace lynx

#endif  // LYNX_RENDER_RENDER_OBJECT_H_

