// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/android/render_object_impl_android.h"

#include <string>
#include <base/android/jni_helper.h>

#include "base/android/android_jni.h"
#include "base/android/convert.h"
#include "base/android/java_type.h"
#include "runtime/v8/v8_helper.h"

#include "RenderObjectImpl_jni.h"

void DispatchEvent(JNIEnv* env,
                   jobject jcaller,
                   jlong nativePtr,
                   jstring event,
                   jobjectArray args) {
    lynx::RenderObjectImplAndroid* impl =
        reinterpret_cast<lynx::RenderObjectImplAndroid*>(nativePtr);
    if (impl != NULL) {
        impl->DispatchEvent(env, event, args);
    }
}

void SyncBaseAttr(JNIEnv* env,
                  jobject jcaller,
                  jlong native_ptr,
                  jint attr,
                  jobject value) {
    lynx::RenderObjectImplAndroid* impl =
        reinterpret_cast<lynx::RenderObjectImplAndroid*>(native_ptr);
    if (impl != NULL) {
        impl->SyncBaseAttr(env, attr, value);
    }
}

namespace lynx {

bool RenderObjectImplAndroid::RegisterJNIUtils(JNIEnv* env) {
    return RegisterNativesImpl(env);
}

RenderObjectImplAndroid::RenderObjectImplAndroid(
    jscore::ThreadManager* manager,
    RenderObjectType type)
    : RenderObjectImpl(manager, type) {

    JNIEnv* env = base::android::AttachCurrentThread();
    render_object_impl_java_impl_.Reset(nullptr,
                                        Java_RenderObjectImpl_create(
                                            env,
                                            type,
                                            reinterpret_cast<long>(this)));
}

RenderObjectImplAndroid::~RenderObjectImplAndroid() {
}

void RenderObjectImplAndroid::UpdateStyle(const lynx::CSSStyle& style) {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_updateStyle(
            env,
            render_object_impl_java_impl_.Get(),
            base::Convert::StyleConvert(style).Get());
    }
}

void RenderObjectImplAndroid::SetPosition(const base::Position& position) {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_setPosition(
            env,
            render_object_impl_java_impl_.Get(),
            base::Convert::PositionConvert(position).Get());
    }
}

void RenderObjectImplAndroid::SetSize(const base::Size& size) {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_setSize(env,
                                      render_object_impl_java_impl_.Get(),
                                      base::Convert::SizeConvert(size).Get());
    }
}

void RenderObjectImplAndroid::InsertChild(RenderObjectImpl* child, int index) {
    RenderObjectImplAndroid* element_proxy =
        static_cast<RenderObjectImplAndroid*>(child);
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_insertChild(env,
                                          render_object_impl_java_impl_.Get(),
                                          element_proxy->java_impl(), index);
    }
}

void RenderObjectImplAndroid::RemoveChild(RenderObjectImpl* child) {
    RenderObjectImplAndroid* element_proxy =
        static_cast<RenderObjectImplAndroid*>(child);
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_removeChild(
            env,
            render_object_impl_java_impl_.Get(),
            element_proxy->java_impl());
    }
}

void RenderObjectImplAndroid::SetText(const std::string& text) {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_setText(
            env,
            render_object_impl_java_impl_.Get(),
            (jstring)base::android::JType::NewString(env, text.c_str()).Get());
    }
}

void RenderObjectImplAndroid::SetAttribute(
    const std::string& key,
    const std::string& value) {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_setAttribute(
            env,
            render_object_impl_java_impl_.Get(),
            (jstring)base::android::JType::NewString(env, key.c_str()).Get(),
            (jstring)base::android::JType::NewString(env, value.c_str()).Get());
    }
}

void RenderObjectImplAndroid::RequestLayout() {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_requestLayout(
            env,
            render_object_impl_java_impl_.Get());
    }
}

void RenderObjectImplAndroid::AddEventListener(const std::string& event) {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_addEventListener(
            env,
            render_object_impl_java_impl_.Get(),
            (jstring)base::android::JType::NewString(env, event.c_str()).Get());
    }
}

void RenderObjectImplAndroid::RemoveEventListener(const std::string& event) {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        Java_RenderObjectImpl_removeEventListener(
            env,
            render_object_impl_java_impl_.Get(),
            (jstring)base::android::JType::NewString(env, event.c_str()).Get());
    }
}

void RenderObjectImplAndroid::SetBaseAttribute(int attr, base::Value value) {
    if (!render_object_impl_java_impl_.IsNull()) {
        JNIEnv* env = base::android::AttachCurrentThread();
        base::android::ScopedLocalJavaRef<jobject> jvalue =
            base::android::JNIHelper::ConvertToJObject(env, value);
        Java_RenderObjectImpl_setBaseAttr(
            env,
            render_object_impl_java_impl_.Get(),
            attr,
            jvalue.Get());
    }
}

void RenderObjectImplAndroid::DispatchEvent(
    JNIEnv* env,
    jstring event,
    jobjectArray args) {
    std::string event_str = base::android::JNIHelper::ConvertToString(env, event);
    jscore::JSArray* array = base::android::JNIHelper::ConvertToJSArray(env, args);
    base::ScopedPtr<jscore::JSArray> scoped_args(array);
    base::ScopedRefPtr<RenderObjectImplAndroid> ref(this);
    thread_manager_->RunOnJSThread(
        base::Bind(&RenderObjectImplAndroid::DispatchEventOnJSThread,
                   ref,
                   event_str,
                   scoped_args));
}

void RenderObjectImplAndroid::SyncBaseAttr(JNIEnv *env,
        jint attr,
        jobject value) {
    base::Value value_transformed =
            base::android::JNIHelper::ConvertToValue(env, value);
    base::ScopedRefPtr<RenderObjectImplAndroid> ref(this);
    thread_manager_->RunOnJSThread(
        base::Bind(&RenderObjectImplAndroid::SyncBaseAttrOnJSThread,
                   ref,
                   attr, value_transformed));
}

void RenderObjectImplAndroid::DispatchEventOnJSThread(
    const std::string& event,
    const base::ScopedPtr<jscore::JSArray> args) {
    if (render_object_weak_ptr_.IsValid()) {
        render_object_weak_ptr_->DispatchEvent(
            event,
            args);
    }
}

void RenderObjectImplAndroid::SyncBaseAttrOnJSThread(
    int attr,
    base::Value value) {
    if (render_object_weak_ptr_.IsValid()) {
        render_object_weak_ptr_->SyncAttr(attr, value);
    }
}

}  // namespace lynx
