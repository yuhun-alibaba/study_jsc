// Copyright 2017 The Lynx Authors. All rights reserved.

#include <string>

#include "base/android/android_jni.h"
#include "base/android/convert.h"
#include "base/size.h"
#include "base/android/java_type.h"
#include "render/label_measurer.h"

#include "LabelMeasurer_jni.h"


namespace lynx {

base::Size LabelMeasurer::MeasureLabelSize(const base::Size& size,
        const std::string& text,
        const lynx::CSSStyle& style) {
    JNIEnv* env = base::android::AttachCurrentThread();
    base::android::ScopedLocalJavaRef<jobject>  style_obj =
        base::Convert::StyleConvert(style);

    base::android::ScopedLocalJavaRef<jobject> size_obj(
        Java_LabelMeasurer_measureLabelSize(
            env,
            (jstring)base::android::JType::NewString(
                env, text.c_str()).Get(),
            style_obj.Get(), size.width_, size.height_));

    base::Size measured_size = base::Convert::SizeConvert(size_obj.Get());
    base::android::CheckException(env);
    return measured_size;
}

bool LabelMeasurer::RegisterJNIUtils(JNIEnv* env) {
    return RegisterNativesImpl(env);
}

}  // namespace lynx
