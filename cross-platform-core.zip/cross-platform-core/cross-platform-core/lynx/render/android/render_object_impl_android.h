// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RENDER_ANDROID_RENDER_OBJECT_IMPL_ANDROID_H_
#define LYNX_RENDER_ANDROID_RENDER_OBJECT_IMPL_ANDROID_H_

#include <jni.h>
#include <string>

#include "base/android/scoped_java_ref.h"
#include "base/value.h"
#include "render/render_object.h"
#include "render/impl/render_object_impl.h"
#include "runtime/thread_manager.h"
#include "runtime/js_array.h"

namespace lynx {
class RenderObjectImplAndroid : public RenderObjectImpl {
 public:
    RenderObjectImplAndroid(
        jscore::ThreadManager* manager,
        RenderObjectType type);

    virtual ~RenderObjectImplAndroid();

    jobject java_impl() { return render_object_impl_java_impl_.Get(); }

    void DispatchEvent(JNIEnv* env, jstring event, jobjectArray args);
    static bool RegisterJNIUtils(JNIEnv* env);

    void SyncBaseAttr(JNIEnv *env, jint attr, jobject value);

 private:
    virtual void UpdateStyle(const lynx::CSSStyle& style);
    virtual void SetPosition(const base::Position& position);
    virtual void SetSize(const base::Size& size);
    virtual void InsertChild(RenderObjectImpl* child, int index);
    virtual void RemoveChild(RenderObjectImpl* child);
    virtual void SetText(const std::string& text);
    virtual void SetAttribute(const std::string& key, const std::string& value);
    virtual void RequestLayout();
    virtual void AddEventListener(const std::string& event);
    virtual void RemoveEventListener(const std::string& event);
    virtual void SetBaseAttribute(int attr, base::Value value);

    void DispatchEventOnJSThread(
        const std::string& event,
        const base::ScopedPtr<jscore::JSArray> args);
    void SyncBaseAttrOnJSThread(int attr, base::Value value);

 private:
    base::android::ScopedGlobalJavaRef<jobject> render_object_impl_java_impl_;
};
}  // namespace lynx


#endif  // LYNX_RENDER_ANDROID_RENDER_OBJECT_IMPL_ANDROID_H_
