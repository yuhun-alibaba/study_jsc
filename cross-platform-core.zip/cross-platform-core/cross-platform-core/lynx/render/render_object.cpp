// Copyright 2017 The Lynx Authors. All rights reserved.

#include <sstream>
#include <vector>
#include <runtime/js_value.h>

#include "render/render_object.h"
#include "render/impl/render_command.h"
#include "render/render_object_type.h"
#include "render/render_tree_host.h"
#include "render/impl/render_object_impl.h"
#include "render/touch/touch_event.h"
#include "runtime/js_array.h"

namespace lynx {

RenderObject::RenderObject(const char* tag_name,
                           RenderObjectType type,
                           uint64_t id,
                           RenderObjectImpl* proxy,
                           RenderTreeHost* host)
    : tag_name_(tag_name),
      id_(id),
      offset_top_(0),
      offset_left_(0),
      offset_width_(0),
      offset_height_(0),
      scroll_height_(0),
      scroll_width_(0),
      scroll_top_(0),
      scroll_left_(0),
      text_(""),
      is_fixed_(false),
      render_object_type_(type),
      impl_(proxy),
      render_tree_host_(host),
      weak_ptr_(this) {
        if (proxy != NULL) {
            proxy->SetRenderObjectWeakRef(weak_ptr_);
        }
}

RenderObject::~RenderObject() {
    weak_ptr_.Invalidate();
}

void RenderObject::RegisterEvent(const std::string& event,
                                 RegisterEventType type) {
    RenderCommand* cmd = new RenderCommand(impl());
    cmd->cmd_src_ = event;
    switch (type) {
    case EVENT_ADD:
        cmd->type_ = RenderCommand::CMD_ADD_EVENT_LISTENER;
        break;
    case EVENT_REMOVE:
        cmd->type_ = RenderCommand::CMD_REMOVE_EVENT_LISTENER;
        break;
    default:
        break;
    }
    render_tree_host_->UpdateRenderObject(cmd);
}

void RenderObject::GetVisiableChildren(
    RenderObject* renderer,
    std::vector<RenderObject *>& visible_chidren) {
    if (!renderer->IsInvisible()) {
        visible_chidren.push_back(renderer);
        return;
    }
    RenderObject* child = static_cast<RenderObject*>(renderer->FirstChild());
    while (child) {
        GetVisiableChildren(child, visible_chidren);
        child = static_cast<RenderObject*>(child->Next());
    }
}

RenderObject* RenderObject::NextSibling() {
    RenderObject* next = static_cast<RenderObject*>(Next());

    if (next && next->IsPrivate()) {
        next = static_cast<RenderObject*>(next->Find(0));
    }
    return next;
}


void RenderObject::SetStyle(const std::string& key,
                            const std::string& value) {
    if (!key.empty()) {
        LayoutObject::SetStyle(key, value);
        HandleFixedStyle();
    } else {
        FlushStyle();
    }
}

void RenderObject::InsertChild(ContainerNode* child, int index) {
    if (child == NULL) return;
    LayoutObject::InsertChild(child, index);

    RenderObject *renderer = this;

    while (renderer->IsInvisible()) {
        renderer = const_cast<RenderObject *>(renderer->Parent());
        if (renderer == NULL)
            return;
    }

    std::vector<RenderObject *> visible_chidren;
    GetVisiableChildren(static_cast<RenderObject*>(child), visible_chidren);
    std::vector<RenderObject *>::iterator visible_child =
            visible_chidren.begin();
    for (; visible_child != visible_chidren.end(); ++visible_child) {
        RenderCommand *cmd = new RenderCommand(renderer->impl());
        cmd->type_ = RenderCommand::CMD_ADD_VIEW;
        cmd->child_ = (*visible_child)->impl_;
        cmd->insert_index_ = index;
        render_tree_host_->UpdateRenderObject(cmd);
    }

    AddFixedChildIfHave(static_cast<RenderObject*>(child));
}


void RenderObject::RecalcLayoutPosition(base::Position& position) {
    RenderObject* parent = const_cast<RenderObject*>(Parent());
    while (parent && parent->IsInvisible()) {
        base::Vector2D offset = parent->measured_position_.Offset();
        position.Update(offset);
        parent = const_cast<RenderObject*>(parent->Parent());
    }
}

void RenderObject::Layout(int left, int top, int right, int bottom) {
    offset_top_ = top;
    offset_left_ = left;
    offset_height_ = bottom - top;
    offset_width_ = right - left;

    if (measured_position_.Update(left, top, right, bottom) && !IsInvisible()) {
        base::Position position(measured_position_);
        RecalcLayoutPosition(position);
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_SET_POSITION;
        cmd->position_ = position;
        render_tree_host_->UpdateRenderObject(cmd);
    }
    LayoutObject::Layout(left, top, right, bottom);
}

void RenderObject::SetText(const std::string& text) {
    text_ = text;
    if (!IsInvisible()) {
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_SET_LABEL_TEXT;
        cmd->cmd_src_ = text;
        render_tree_host_->UpdateRenderObject(cmd);
    }
    Dirty();
}

void RenderObject::AppendChild(RenderObject *child) {
    InsertChild(child, -1);
}

RenderObject* RenderObject::RemoveChildByIndex(int index) {
    return static_cast<RenderObject*>(ContainerNode::RemoveChild(index));
}

void RenderObject::InsertBefore(RenderObject* child,
                                RenderObject* reference) {
    if (child == NULL) return;
    InsertChild(child, Find(reference));
}

void RenderObject::RemoveChild(ContainerNode* child) {
    if (child == NULL) return;

    RemoveFixedChildIfHave(static_cast<RenderObject*>(child));

    ContainerNode::RemoveChild(child);
    Dirty();

    RenderObject *renderer = this;

    while (renderer->IsInvisible()) {
        renderer = const_cast<RenderObject *>(renderer->Parent());
        if (renderer == NULL)
            return;
    }

    std::vector<RenderObject *> visible_chidren;
    GetVisiableChildren(static_cast<RenderObject*>(child),
                        visible_chidren);
    std::vector<RenderObject*>::iterator visible_child =
        visible_chidren.begin();
    for (; visible_child != visible_chidren.end(); ++visible_child) {
        RenderCommand* cmd = new RenderCommand(renderer->impl());
        cmd->type_ = RenderCommand::CMD_REMOVE_VIEW;
        cmd->child_ = (*visible_child)->impl_;
        render_tree_host_->UpdateRenderObject(cmd);
    }
}

void RenderObject::SetAttribute(const std::string &key,
                                const std::string &value) {
    if (!IsInvisible()) {
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_SET_ATTR;
        cmd->cmd_key_ = key;
        cmd->cmd_src_ = value;
        render_tree_host_->UpdateRenderObject(cmd);

        attributes_[key] = value;
    }
}

bool RenderObject::HasAttribute(const std::string &key) {
    return attributes_.find(key) != attributes_.end();
}

void RenderObject::RemoveAttribute(const std::string &key) {
    std::map<std::string, std::string>::iterator iter = attributes_.find(key);
    if(attributes_.find(key) != attributes_.end()) {
        attributes_.erase(iter);
    }
}

void RenderObject::FlushStyle() {
    if (!IsInvisible()) {
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_SET_STYLE;
        cmd->style_ = style_;
        render_tree_host_->UpdateRenderObject(cmd);
    }
    Dirty();
}

void RenderObject::SetScrollLeft(int scrol_left) {
    base::Value param;
    param.type_ = base::Value::VALUE_INT;
    param.data_.i = scrol_left;
    SetBaseAttr(RENDER_OBJECT_ATTRS::SCROLL_LEFT, param);
}

void RenderObject::SetScrollTop(int scroll_top) {
    base::Value param;
    param.type_ = base::Value::VALUE_INT;
    param.data_.i = scroll_top;
    SetBaseAttr(RENDER_OBJECT_ATTRS::SCROLL_TOP, param);
}

void RenderObject::SyncAttr(int attr, base::Value value) {
    switch (attr) {
    case RENDER_OBJECT_ATTRS::SCROLL_TOP:
        scroll_top_ = value.data_.i;
        break;
    case RENDER_OBJECT_ATTRS::SCROLL_LEFT:
        scroll_left_ = value.data_.i;
        break;
    case RENDER_OBJECT_ATTRS::GET_TEXT:
        text_ = value.data_.i;
    default:
        break;
    }
}

void RenderObject::SetBaseAttr(int attr, base::Value value) {
    switch (attr) {
    case RENDER_OBJECT_ATTRS::SCROLL_TOP:
        scroll_top_ = value.data_.i;
        break;
    case RENDER_OBJECT_ATTRS::SCROLL_LEFT:
        scroll_left_ = value.data_.i;
        break;
    default:
        break;
    }
    if (!IsInvisible()) {
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_SET_BASE_ATTR;
        cmd->cmd_base_attr_key_ = attr;
        cmd->cmd_base_attr_value_ = value;
        render_tree_host_->UpdateRenderObject(cmd);
    }
}

void RenderObject::HandleFixedStyle() {

    CSSStyleType cur_fixed_state = style_.css_position_type();
    if (parent_ == NULL) return;

    if (is_fixed_
        && (cur_fixed_state != CSSStyleType::CSS_POSITION_FIXED
        || style_.visible_ == CSSStyleType::CSS_HIDDEN
        || style_.css_display_type_ == CSSStyleType::CSS_DISPLAY_NONE)) {
        is_fixed_ = false;
        static_cast<RenderObject*>(parent_)->RemoveFixedChild(this);
    } else if (!is_fixed_
               && cur_fixed_state == CSSStyleType::CSS_POSITION_FIXED
               && style_.visible_ == CSSStyleType::CSS_VISIBLE
               && style_.css_display_type_ != CSSStyleType::CSS_DISPLAY_NONE) {
        is_fixed_ = true;
        static_cast<RenderObject*>(parent_)->AddFixedChild(this);
    }

}

void RenderObject::AddFixedChildIfHave(RenderObject* child) {
    if (child->style_.css_position_type() == CSSStyleType::CSS_POSITION_FIXED) {
        AddFixedChild(child);
    }
    if (child->fixed_children_.size() > 0) {
        for (int i = 0; i < child->fixed_children_.size(); ++i) {
            AddFixedChild(child->fixed_children_.at(i));
        }
    }
}

void RenderObject::RemoveFixedChildIfHave(RenderObject* removed) {
    if(removed->style_.css_position_type()== CSSStyleType::CSS_POSITION_FIXED) {
        RemoveFixedChild(removed);
    }

    while (removed->fixed_children_.size() > 0) {
        RenderObject* fixed = removed->fixed_children_.at(0);
        removed->RemoveFixedChild(fixed);
    }

}

void RenderObject::AddFixedChild(RenderObject* fixed_child) {
    fixed_children_.push_back(fixed_child);
    if (parent_ != NULL) {
        static_cast<RenderObject *>(parent_)->AddFixedChild(fixed_child);
    }
    if (this == fixed_child->parent_) {
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_REMOVE_VIEW;
        cmd->child_ = fixed_child->impl_;
        render_tree_host_->UpdateRenderObject(cmd);
    }
    if (this->render_object_type_ == RenderObjectType::LYNX_BODY) {
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_ADD_VIEW;
        cmd->child_ = fixed_child->impl_;
        cmd->insert_index_ = -1;
        render_tree_host_->UpdateRenderObject(cmd);
    }
}

void RenderObject::RemoveFixedChild(RenderObject* fixed_child) {
    for (auto it = fixed_children_.cbegin(); it != fixed_children_.cend(); ++it) {
        if (*it == fixed_child) {
            fixed_children_.erase(it);
            if (parent_ != NULL) {
                static_cast<RenderObject *>(parent_)->RemoveFixedChild(fixed_child);
            }
            break;
        }
    }
    if (this == fixed_child->parent_) {
        int index = Find(fixed_child);
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_ADD_VIEW;
        cmd->child_ = fixed_child->impl_;
        cmd->insert_index_ = index;
        render_tree_host_->UpdateRenderObject(cmd);
    }
    if (this->render_object_type_ == RenderObjectType::LYNX_BODY) {
        RenderCommand* cmd = new RenderCommand(impl());
        cmd->type_ = RenderCommand::CMD_REMOVE_VIEW;
        cmd->child_ = fixed_child->impl_;
        render_tree_host_->UpdateRenderObject(cmd);
    }
}

void RenderObject::PerformTouch(TouchEvent* event) {
    auto it = event_listener_map_.find(event->touch_event_type());
    if (it != event_listener_map_.end()) {
        jscore::JSArray* array = new jscore::JSArray();
        jscore::JSValue *value = jscore::JSValue::MakeTargetObject(event);
        array->Push(value);
        DispatchEvent(event->touch_event_type(), jscore::JSValue::MakeArrayScoped(array));
    }
}

void RenderObject::PerformMotion(TouchEvent* event) {
    auto it = event_listener_map_.find(event->motion_event_type());
    if (it != event_listener_map_.end()) {
        jscore::JSArray* array = new jscore::JSArray();
        jscore::JSValue* value = jscore::JSValue::MakeTargetObject(event);
        array->Push(value);
        DispatchEvent(event->motion_event_type(), jscore::JSValue::MakeArrayScoped(array));
    }
}

void RenderObject::OnCapturingTouchEvent(TouchEvent* event) {
}

bool RenderObject::IsEventListenerEmpty() {
    return event_listener_map_.empty();
}

const std::vector<RenderObject*> RenderObject::GetFixedNodes() {
    return fixed_children_;
}

}  // namespace lynx
