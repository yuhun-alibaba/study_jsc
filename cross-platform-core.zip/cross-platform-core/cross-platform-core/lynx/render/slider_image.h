// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RENDER_SLIDER_IMAGE_H_
#define LYNX_RENDER_SLIDER_IMAGE_H_

#include "render/render_object.h"

namespace lynx {
class SliderImage : public RenderObject {
 public:
    SliderImage(jscore::ThreadManager* manager,
                const char *tag_name,
                uint64_t id,
                RenderTreeHost* host);
    virtual ~SliderImage() {}
    virtual base::Size Measure(int width, int height);
    virtual void Layout(int left, int top, int right, int bottom);
};

}  // namespace lynx

#endif  // LYNX_RENDER_SLIDER_IMAGE_H_
