// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/scroll_view.h"
#include "render/render_object_type.h"

namespace lynx {

ScrollView::ScrollView(jscore::ThreadManager* manager,
                       const char* tag_name,
                       uint64_t id,
                       RenderTreeHost* host)
    : View(manager,
           tag_name,
           LYNX_SCROLLVIEW,
           id,
           RenderObjectImpl::Create(manager, LYNX_SCROLLVIEW),
           host) {
}

base::Size ScrollView::Measure(int width, int height) {
    if (IsDirty()) {
        measured_size_ = CSSStaticLayout::Measure(this, width, height);
        set_scroll_width(measured_size_.width_);
        set_scroll_height(measured_size_.height_);
        int width_temp = 0;
        int height_temp = 0;
        for (int i = 0; i < GetChildCount(); i++) {
            RenderObject* child = static_cast<RenderObject *>(Find(i));
            if (child->style_.css_position_type() == CSS_POSITION_ABSOLUTE) {
                continue;
            }
            width_temp += child->measured_size_.width_
                          + child->style_.margin_right()
                          + child->style_.margin_left();
            height_temp += child->measured_size_.height_
                           + child->style_.margin_bottom()
                           + child->style_.margin_top();
        }
        if (style_.flex_direction() == CSSFLEX_DIRECTION_ROW) {
            measured_size_.width_ = width_temp;
            set_scroll_width(width_temp);
        } else {
            measured_size_.height_ = height_temp;
            set_scroll_height(height_temp);
        }
        if (!CSS_IS_UNDEFINED(style_.width())) {
            measured_size_.width_ = style_.width();
        }
        if (!CSS_IS_UNDEFINED(style_.height())) {
            measured_size_.height_ = style_.height();
        }
    }
    return measured_size_;
}

void ScrollView::Layout(int left, int top, int right, int bottom) {
    View::Layout(left, top, right, bottom);
}

}  // namespace lynx

