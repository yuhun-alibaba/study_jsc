// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/slider_image.h"
#include "render/impl/render_object_impl.h"

namespace lynx {

SliderImage::SliderImage(jscore::ThreadManager *manager,
                         const char* tag_name,
                         uint64_t id,
                         RenderTreeHost* host)
    : RenderObject(tag_name,
                   LYNX_SLIDER_IMAGE,
                   id,
                   RenderObjectImpl::Create(manager, LYNX_SLIDER_IMAGE),
                   host) {
}

base::Size SliderImage::Measure(int width, int height) {
    measured_size_.height_ = base::Size::Descriptor::GetSize(height);
    measured_size_.width_ = base::Size::Descriptor::GetSize(width);
    if (!CSS_IS_UNDEFINED(style_.width())) {
        measured_size_.width_ = style_.width();
    }
    if (!CSS_IS_UNDEFINED(style_.height())) {
        measured_size_.height_ = style_.height();
    }
    return measured_size_;
}

void SliderImage::Layout(int left, int top, int right, int bottom) {
    RenderObject::Layout(left, top, right, bottom);
}

}  // namespace lynx
