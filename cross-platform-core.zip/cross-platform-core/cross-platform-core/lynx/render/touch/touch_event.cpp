// Copyright 2017 The Lynx Authors. All rights reserved.

#include <runtime/js_value.h>
#include "render/touch/touch_event.h"

namespace lynx {

    TouchEvent::TouchEvent(TouchEventInfo& info) : JSEvent(info.touch_event_type()),
                                                   touch_event_type_(info.touch_event_type()),
                                                   motion_event_type_(info.motion_event_type()),
                                                   x_(info.GetX()),
                                                   y_(info.GetY()) {
        RegisterAccessorCallback("changedTouches", GetTouchesCallback, 0);
        RegisterAccessorCallback("touches", GetTouchesCallback, 0);
    }

    TouchEvent::~TouchEvent() {

    }

    void TouchEvent::Recycle() {

    }

    TouchEvent* TouchEvent::Obtain(TouchEventInfo info) {
        TouchEvent* event = new TouchEvent(info);
        return event;
    }

    base::ScopedPtr<jscore::JSValue> TouchEvent::GetTouchesCallback(jscore::JSTargetObject* object) {
        jscore::JSArray* touches = new jscore::JSArray();
        jscore::JSObject* axis = new jscore::JSObject();

        float x = static_cast<TouchEvent*>(object)->x();
        float y = static_cast<TouchEvent*>(object)->y();
        jscore::JSValue* x_value = jscore::JSValue::MakeFloat(x);
        jscore::JSValue* y_value = jscore::JSValue::MakeFloat(y);
        axis->Set("clientX", x_value);
        axis->Set("clientY", y_value);
        axis->Set("screenX", x_value);
        axis->Set("screenY", y_value);

        touches->Push(axis);
        return jscore::JSValue::MakeValueScoped(touches);
    }

}