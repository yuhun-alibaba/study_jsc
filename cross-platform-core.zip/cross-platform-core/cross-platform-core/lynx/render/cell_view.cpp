// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/cell_view.h"
#include "render/render_object_type.h"

namespace lynx {

CellView::CellView(jscore::ThreadManager* manager, RenderTreeHost* host)
    : View("cell", LYNX_CELLVIEW, 1,
            RenderObjectImpl::Create(manager, LYNX_CELLVIEW), host) {
    style_.set_flex_direction(CSSFLEX_DIRECTION_COLUMN);
}

void CellView::Layout(int left, int top, int right, int bottom) {
    View::Layout(0, 0, right - left, bottom - top);
    if (GetChildCount() > 0) {
        RenderObject* child = static_cast<RenderObject *>(Find(0));
        child->set_offset_top(top);
    }
}
}  // namespace lynx
