// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/event_target.h"

#include "render/impl/render_command.h"
#include "runtime/js_array.h"

namespace lynx {

void EventTarget::DispatchEvent(const std::string& event, base::ScopedPtr<jscore::JSArray> args) {
    EventListenerMap::iterator iter = event_listener_map_.find(event);
    if (iter == event_listener_map_.end()) return;
    for (int i = 0; i < iter->second->size(); i++) {
        if (target_data_ != NULL) {
            (*iter->second)[i]->function_->Run(target_data_, args.Get());
        }
    }
}

void EventTarget::AddEventListener(const std::string& event,
                                    jscore::JSFunction* function,
                                    bool capture) {
    EventListenerMap::iterator iter = event_listener_map_.find(event);

    if (iter == event_listener_map_.end()) {
        iter = event_listener_map_.add(event,
                        new base::ScopedVector<EventListener>()).first;
    }
    iter->second->push_back(new EventListener(function, capture));

    RegisterEvent(event, EVENT_ADD);
}

void EventTarget::RemoveEventListener(const std::string& event,
                                      jscore::JSFunction* function) {
    EventListenerMap::iterator iter = event_listener_map_.find(event);
    if (iter == event_listener_map_.end()) {
        return;
    }

    base::ScopedVector<EventListener>::iterator vec_iter =
                                                    iter->second->begin();

    for (vec_iter; vec_iter != iter->second->end(); vec_iter++) {
        if ((*vec_iter)->function_->GetKey() == function->GetKey()) {
            iter->second->erase(vec_iter);
            break;
        }
    }

    RegisterEvent(event, EVENT_REMOVE);
}
}  // namespace lynx
