// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RENDER_LABEL_MEASURER_H_
#define LYNX_RENDER_LABEL_MEASURER_H_

#include <string>

#if OS_ANDROID
#include "jni.h"
#endif

namespace base {
class Size;
}

namespace lynx {
class CSSStyle;
class LabelMeasurer {
 public:
    static base::Size MeasureLabelSize(
        const base::Size& size,
        const std::string& text,
        const CSSStyle& style);

#if OS_ANDROID
    static bool RegisterJNIUtils(JNIEnv* env);
#endif
};

}  // namespace lynx

#endif  // LYNX_RENDER_LABEL_MEASURER_H_
