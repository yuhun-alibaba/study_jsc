// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/slider_view.h"

#include "render/impl/render_object_impl.h"

namespace lynx {
SliderView::SliderView(
    jscore::ThreadManager *manager,
    const char *tag_name,
    uint64_t id,
    RenderTreeHost *host)
    : RenderObject(
          tag_name,
          LYNX_SLIDER_VIEW,
          id,
          RenderObjectImpl::Create(manager, LYNX_SLIDER_VIEW), host) {
}

base::Size SliderView::Measure(int width, int height) {
    measured_size_.height_ = base::Size::Descriptor::GetSize(height);
    measured_size_.width_ = base::Size::Descriptor::GetSize(width);
    if (!CSS_IS_UNDEFINED(style_.width())) {
        measured_size_.width_ = style_.width();
    }
    if (!CSS_IS_UNDEFINED(style_.height())) {
        measured_size_.height_ = style_.height();
    }
    return measured_size_;
}

void SliderView::Layout(int left, int top, int right, int bottom) {
    RenderObject::Layout(left, top, right, bottom);
}

}  // namespace lynx

