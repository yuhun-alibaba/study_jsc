// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/impl/command_collector.h"

namespace lynx {

RenderCommandCollector::RenderCommandCollector() {
    commands_ = new base::ScopedVector<RenderCommand>();
}

RenderCommandCollector::~RenderCommandCollector() {
    delete commands_;
}

void RenderCommandCollector::Collect(RenderCommand* command) {
    commands_->push_back(command);
}

void RenderCommandCollector::Push() {
    base::AutoLock lock(lock_);
    collectors_.push(commands_);
    commands_ = new base::ScopedVector<RenderCommand>();
}

base::ScopedVector<RenderCommand>* RenderCommandCollector::Pop() {
    base::AutoLock lock(lock_);

    RenderCommands* collector = NULL;
    if (!collectors_.empty()) {
        collector = collectors_.front();
        collectors_.pop();
    }
    return collector;
}
}  // namespace lynx
