// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RENDER_IMPL_RENDER_COMMAND_H_
#define LYNX_RENDER_IMPL_RENDER_COMMAND_H_

#include <string>

#include "base/task/callback.h"
#include "base/position.h"
#include "base/size.h"
#include "base/weak_ptr.h"
#include "base/value.h"
#include "layout/css_style.h"

namespace lynx {
class RenderObjectImpl;
class RenderCommand : public base::Clouse {
 public:
    explicit RenderCommand(RenderObjectImpl* host);
    ~RenderCommand();

    enum CommandType {
        CMD_SET_POSITION,
        CMD_SET_SIZE,
        CMD_SET_STYLE,
        CMD_SET_ATTR,
        CMD_ADD_VIEW,
        CMD_REMOVE_VIEW,
        CMD_REQUEST_LAYOUT,
        CMD_SET_LABEL_TEXT,
        CMD_SET_IMAGE_SRC,
        CMD_ADD_EVENT_LISTENER,
        CMD_REMOVE_EVENT_LISTENER,
        CMD_SET_BASE_ATTR,
    };

    void ExecuteCommand();
    void Execute();

    virtual void Run() {
        Execute();
    }

    friend class RenderObject;
    friend class Body;
    friend class Label;
    friend class Input;
    friend class ListView;
 protected:
    RenderObjectImpl* host_;
    base::WeakPtr<RenderCommand> weak_ptr_;

    CommandType type_;
    base::Position position_;
    base::Size size_;
    CSSStyle style_;
    std::string cmd_src_;
    std::string cmd_key_;
    base::ScopedRefPtr<RenderObjectImpl> child_;
    int insert_index_;
    base::Value cmd_base_attr_value_;
    int cmd_base_attr_key_;
};
}  // namespace lynx

#endif  // LYNX_RENDER_IMPL_RENDER_COMMAND_H_
