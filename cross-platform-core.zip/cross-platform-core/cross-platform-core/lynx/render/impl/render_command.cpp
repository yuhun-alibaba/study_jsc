// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/impl/render_command.h"

#include "render/render_object.h"
#include "render/impl/render_object_impl.h"

namespace lynx {
RenderCommand::RenderCommand(RenderObjectImpl *host)
    : host_(host),
      weak_ptr_(this) {
    host_->AddRef();
}

RenderCommand::~RenderCommand() {
    host_->Release();
    weak_ptr_.Invalidate();
}

void RenderCommand::ExecuteCommand() {
    host_->thread_manager_->RunOnUIThread(
        base::Bind(&RenderCommand::Execute, weak_ptr_));
}

void RenderCommand::Execute() {
    switch (type_) {
    case CMD_SET_POSITION:
        host_->SetPosition(position_);
        host_->RequestLayout();
        break;
    case CMD_SET_SIZE:
        host_->SetSize(size_);
        break;
    case CMD_SET_STYLE:
        host_->UpdateStyle(style_);
        break;
    case CMD_ADD_VIEW:
        host_->InsertChild(child_.Get(), insert_index_);
        break;
    case CMD_REMOVE_VIEW:
        host_->RemoveChild(child_.Get());
        break;
    case CMD_SET_LABEL_TEXT:
        host_->SetText(cmd_src_);
        break;
    case CMD_SET_ATTR:
        host_->SetAttribute(cmd_key_, cmd_src_);
        break;
    case CMD_REQUEST_LAYOUT:
        host_->RequestLayout();
        break;
    case CMD_ADD_EVENT_LISTENER:
        host_->AddEventListener(cmd_src_);
        break;
    case CMD_REMOVE_EVENT_LISTENER:
        host_->RemoveEventListener(cmd_src_);
        break;
    case CMD_SET_BASE_ATTR:
        host_->SetBaseAttribute(cmd_base_attr_key_, cmd_base_attr_value_);
        break;
    default:
        break;
    }
}
}  // namespace lynx
