// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/label_measurer.h"
#include "render/input.h"
#include "render/impl/render_object_impl.h"

namespace lynx {
Input::Input(jscore::ThreadManager *manager,
             const char *tag_name,
             uint64_t id,
             RenderTreeHost* host)
    : RenderObject(tag_name,
                   LYNX_INPUT,
                   id,
                   RenderObjectImpl::Create(manager, LYNX_INPUT), host) {
}

base::Size Input::Measure(int width, int height) {
    width = style_.ClampWidth(width);
    height = style_.ClampHeight(height);

    base::Size size =
        LabelMeasurer::MeasureLabelSize(
            base::Size(width, height),
            GetText(),
            style_);

    size.width_ = style_.ClampWidth(size.width_);
    size.height_ = style_.ClampHeight(size.height_);
    return size;
}

void Input::Layout(int left, int top, int right, int bottom) {
    RenderObject::Layout(left, top, right, bottom);
}
}  // namespace lynx
