// Copyright 2017 The Lynx Authors. All rights reserved.

#include "render/view.h"
#include "render/render_object_type.h"

namespace lynx {

View::View(const char* tag_name,
           RenderObjectType type,
           uint64_t id,
           RenderObjectImpl* proxy,
           RenderTreeHost* host)
    : RenderObject(tag_name, type, id, proxy, host) {
}

View::View(const char* tag_name,
           uint64_t id,
           RenderObjectImpl* proxy,
           RenderTreeHost* host)
    : RenderObject(tag_name, LYNX_VIEW, id, proxy, host) {
}

View::View(jscore::ThreadManager* manager,
           const char* tag_name,
           uint64_t id,
           RenderObjectImpl* proxy,
           RenderTreeHost* host)
    : RenderObject(tag_name,
                   LYNX_VIEW,
                   id,
                   proxy ? proxy : RenderObjectImpl::Create(
                       manager,
                       LYNX_VIEW),
                   host) {
}

View::View(
    jscore::ThreadManager* manager,
    const char* tag_name,
    RenderObjectType type,
    uint64_t id,
    RenderObjectImpl* proxy,
    RenderTreeHost* host)
    : RenderObject(tag_name,
                   type,
                   id,
                   proxy ? proxy : RenderObjectImpl::Create(
                       manager,
                       type),
                   host) {
}

base::Size View::Measure(int width, int height) {
    if (IsDirty()) {
        measured_size_ = CSSStaticLayout::Measure(this, width, height);
    }
    return measured_size_;
}

void View::Layout(int left, int top, int right, int bottom) {
    if (IsDirty()) {
        RenderObject *parent = static_cast<RenderObject *>(parent_);
        if (parent != NULL && parent->render_object_type() == LYNX_LISTSHADOW) {
            RenderObject::Layout(left, 0, right, bottom - top);
        } else {
            RenderObject::Layout(left, top, right, bottom);
        }
        CSSStaticLayout::Layout(this, right - left, bottom - top);
    }
}
}  // namespace lynx
