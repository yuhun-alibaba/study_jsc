// Copyright 2017 The Lynx Authors. All rights reserved.

#ifndef LYNX_RENDER_RENDER_FACTORY_H_
#define LYNX_RENDER_RENDER_FACTORY_H_

#include <stdint.h>
#include <string>

#include "render/body.h"
#include "render/image_view.h"
#include "render/label.h"
#include "render/layout_view.h"
#include "render/list_shadow.h"
#include "render/list_view.h"
#include "render/scroll_view.h"
#include "render/view.h"
#include "render/input.h"
#include "render/slider_image.h"
#include "render/slider_view.h"
#include "runtime/thread_manager.h"

namespace lynx {
class RenderFactory {
 public:
    static RenderObject* CreateRenderObject(
        jscore::ThreadManager* manager,
        const std::string& tag,
        RenderTreeHost* host) {
        static uint64_t id = 10;
        if (tag.compare("body") == 0) {
            RenderObject*renderer = new ListView(manager, "listview", ++id, host);
            host->render_root()->AppendChild(renderer);
            return renderer;
        } else if (tag.compare("view") == 0) {
            return new View(manager, "view", ++id, NULL, host);
        } else if (tag.compare("label") == 0) {
            return new Label(manager, "label", ++id, host);
        } else if (tag.compare("listview") == 0) {
            return new ListView(manager, "listview", ++id, host);
        } else if (tag.compare("listview-shadow") == 0) {
            return new ListShadow(manager, "listview-shadow", ++id, host);
        } else if (tag.compare("image") == 0) {
            return new ImageView(manager, "image", ++id, host);
        } else if (tag.compare("scrollview") == 0) {
            return new ScrollView(manager, "scrollview", ++id, host);
        } else if (tag.compare("xinput") == 0) {
#if OS_ANDROID
            return new Input(manager, "xinput", ++id, host);
#endif
        } else if (tag.compare("slider-image") == 0) {
#if OS_ANDROID
            return new SliderImage(manager, "slider-image", ++id, host);
#endif
        } else if (tag.compare("slider-view") == 0) {
#if OS_ANDROID
            return new SliderView(manager, "slider-view", ++id, host);
#endif
        } else if (tag.compare("layout-view") == 0) {
            return new LayoutView(manager, "layout-view", ++id, host);
        }
        return NULL;
    }
};
}  // namespace lynx


#endif  // LYNX_RENDER_RENDER_FACTORY_H_
