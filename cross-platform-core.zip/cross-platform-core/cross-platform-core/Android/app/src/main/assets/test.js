var wrap = document.createElement('view');
var middle = document.createElement('view');


wrap.setStyle({
  flexDirection: 'row',
  width: 500,
  height: 700,
  backgroundColor: '#666',
});
wrap.a = new Array();
for (var i = 0; i < 9; i++) {

    var circle = document.createElement('view');
    circle.setStyle({
      borderWidth: 1.3,
      borderColor: '#333',
      borderRadius: 4,
      width: 50,
      height: 50,
      marginRight: 0,
      marginTop: 0,
      backgroundColor: '#aaa',
    });
    wrap.appendChild(circle);
//    wrap.a.push(circle);
}


middle.setStyle({
  width: 50,
  height: 400,
  backgroundColor: '#eee',
});


//middle.appendChild(circle);
document.body.appendChild(wrap);

var marginTopValue = 0;
var down = true;
setInterval(function() {
    if (down) {
        marginTopValue++;
    } else {
        marginTopValue--;
    }
    if (marginTopValue <= 0) {
        down = true;
    }
    if (marginTopValue >= 500) {
        down = false;
    }

    for (var i = 0; i < 9; i++) {
        var child = wrap.getChildByIndex(i);
        if (child != null && child != undefined) {
            child.setStyle({
                        marginTop: marginTopValue,
                    });
        }

    }

}, 10);
