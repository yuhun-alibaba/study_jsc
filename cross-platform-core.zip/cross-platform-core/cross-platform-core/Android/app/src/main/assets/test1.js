
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/*!*************************************!*\
  !*** ./source/pages/hello/index.js ***!
  \*************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	var _xcoreVue = __webpack_require__(/*! @mogu/xcore-vue */ 1);

	var _xcoreVue2 = _interopRequireDefault(_xcoreVue);

	var _app = __webpack_require__(/*! ./app */ 2);

	var _app2 = _interopRequireDefault(_app);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	new _xcoreVue2.default({
	  el: '#app',
	  render: function render() {
	    return this._h('app');
	  },
	  components: {
	    App: _app2.default
	  }
	});

/***/ },
/* 1 */
/*!****************************************************!*\
  !*** ./~/@mogu/xcore-vue/dist/xcore-vue.common.js ***!
  \****************************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';/*  *//**
	 * is lower device
	 */var _typeof=typeof Symbol==="function"&&typeof Symbol.iterator==="symbol"?function(obj){return typeof obj;}:function(obj){return obj&&typeof Symbol==="function"&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":typeof obj;};function isLowDevice(){var ua=navigator.userAgent.toLocaleLowerCase();var lowerDevice=/android 4.2|android 4.3/;return lowerDevice.test(ua)&&ua.indexOf('xcore')<0;}/**
	 * Convert a value to a string that is actually rendered.
	 */function _toString(val){return val==null?'':(typeof val==='undefined'?'undefined':_typeof(val))==='object'?JSON.stringify(val,null,2):String(val);}/**
	 * Convert a input value to a number for persistence.
	 * If the conversion fails, return original string.
	 */function toNumber(val){var n=parseFloat(val,10);return n||n===0?n:val;}/**
	 * Make a map and return a function for checking if a key
	 * is in that map.
	 */function makeMap(str,expectsLowerCase){var map=Object.create(null);var list=str.split(',');for(var i=0;i<list.length;i++){map[list[i]]=true;}return expectsLowerCase?function(val){return map[val.toLowerCase()];}:function(val){return map[val];};}/**
	 * Check if a tag is a built-in tag.
	 */var isBuiltInTag=makeMap('slot,component',true);/**
	 * Remove an item from an array
	 */function remove(arr,item){if(arr.length){var index=arr.indexOf(item);if(index>-1){return arr.splice(index,1);}}}/**
	 * Check whether the object has the property.
	 */var hasOwnProperty=Object.prototype.hasOwnProperty;function hasOwn(obj,key){return hasOwnProperty.call(obj,key);}/**
	 * Check if value is primitive
	 */function isPrimitive(value){return typeof value==='string'||typeof value==='number';}/**
	 * Create a cached version of a pure function.
	 */function cached(fn){var cache=Object.create(null);return function cachedFn(str){var hit=cache[str];return hit||(cache[str]=fn(str));};}/**
	 * Camelize a hyphen-delmited string.
	 */var camelizeRE=/-(\w)/g;var camelize=cached(function(str){return str.replace(camelizeRE,function(_,c){return c?c.toUpperCase():'';});});/**
	 * Capitalize a string.
	 */var capitalize=cached(function(str){return str.charAt(0).toUpperCase()+str.slice(1);});/**
	 * Hyphenate a camelCase string.
	 */var hyphenateRE=/([^-])([A-Z])/g;var hyphenate=cached(function(str){return str.replace(hyphenateRE,'$1-$2').replace(hyphenateRE,'$1-$2').toLowerCase();});/**
	 * Simple bind, faster than native
	 */function bind$1(fn,ctx){function boundFn(a){var l=arguments.length;return l?l>1?fn.apply(ctx,arguments):fn.call(ctx,a):fn.call(ctx);}// record original fn length
	boundFn._length=fn.length;return boundFn;}/**
	 * Convert an Array-like object to a real Array.
	 */function toArray(list,start){start=start||0;var i=list.length-start;var ret=new Array(i);while(i--){ret[i]=list[i+start];}return ret;}/**
	 * Mix properties into target object.
	 */function extend(to,_from){for(var key in _from){to[key]=_from[key];}return to;}/**
	 * Quick object check - this is primarily used to tell
	 * Objects from primitive values when we know the value
	 * is a JSON-compliant type.
	 */function isObject(obj){return obj!==null&&(typeof obj==='undefined'?'undefined':_typeof(obj))==='object';}/**
	 * Strict object type check. Only returns true
	 * for plain JavaScript objects.
	 */var toString=Object.prototype.toString;var OBJECT_STRING='[object Object]';function isPlainObject(obj){return toString.call(obj)===OBJECT_STRING;}/**
	 * Merge an Array of Objects into a single Object.
	 */function toObject(arr){var res={};for(var i=0;i<arr.length;i++){if(arr[i]){extend(res,arr[i]);}}return res;}function isEmptyObject(obj){if(!obj||(typeof obj==='undefined'?'undefined':_typeof(obj))!=='object'){return true;}for(var k in obj){if({}.hasOwnProperty.call(obj,k)){return false;}}return true;}/**
	 * 节流函数
	 * @param  {function} fn 传入函数
	 * @param  {number} delay 执行的时间间隔
	 * @param  {number} mustRunDelay 每隔 xx ms至少执行一次
	 * @return {function} 返回函数
	 */function throttle(fn,delay,mustRunDelay){var timer=null;var tStart;return function(){var arguments$1=arguments;var context=this;var tCurr=+new Date();var args=new Array(arguments.length);for(var i=0,l=arguments.length;i<l;i++){args[i]=arguments$1[i];}clearTimeout(timer);if(!tStart){tStart=tCurr;}if(tCurr-tStart>=mustRunDelay){fn.apply(context,args);tStart=tCurr;}else{timer=setTimeout(function(){fn.apply(context,args);},delay);}};}/**
	 * Perform no operation.
	 */function noop(){}/**
	 * Always return false.
	 */var no=function no(){return false;};/**
	 * Generate a static keys string from compiler modules.
	 */function genStaticKeys(modules){return modules.reduce(function(keys,m){return keys.concat(m.staticKeys||[]);},[]).join(',');}/**
	 * Check if two values are loosely equal - that is,
	 * if they are plain objects, do they have the same shape?
	 */function looseEqual(a,b){/* eslint-disable eqeqeq */return a==b||(isObject(a)&&isObject(b)?JSON.stringify(a)===JSON.stringify(b):false);/* eslint-enable eqeqeq */}function looseIndexOf(arr,val){for(var i=0;i<arr.length;i++){if(looseEqual(arr[i],val)){return i;}}return-1;}/**
	 * Object.assign Polyfill
	 */var objectAssign=Object.assign||function(target){var arguments$1=arguments;for(var i=1;i<arguments.length;i++){var source=arguments$1[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};/*  */var config={/**
	   * Option merge strategies (used in core/util/options)
	   */optionMergeStrategies:Object.create(null),/**
	   * Whether to suppress warnings.
	   */silent:false,/**
	   * Whether to enable devtools
	   */devtools:"developement"!=='production',/**
	   * Error handler for watcher errors
	   */errorHandler:null,/**
	   * Ignore certain custom elements
	   */ignoredElements:null,/**
	   * Custom user key aliases for v-on
	   */keyCodes:Object.create(null),/**
	   * Check if a tag is reserved so that it cannot be registered as a
	   * component. This is platform-dependent and may be overwritten.
	   */isReservedTag:no,/**
	   * Check if a tag is an unknown element.
	   * Platform-dependent.
	   */isUnknownElement:no,/**
	   * Check if an attribute must be bound using property, e.g. value
	   * Platform-dependent.
	   */mustUseProp:no,/**
	   * List of asset types that a component can own.
	   */_assetTypes:['component','directive','filter'],/**
	   * List of lifecycle hooks.
	   */_lifecycleHooks:['beforeCreate','created','beforeMount','mounted','beforeUpdate','updated','beforeDestroy','destroyed','activated','deactivated'],/**
	   * Max circular updates allowed in a scheduler flush cycle.
	   */_maxUpdateCount:100};/*  *//**
	 * Check if a string starts with $ or _
	 */function isReserved(str){var c=(str+'').charCodeAt(0);return c===0x24||c===0x5F;}/**
	 * Define a property.
	 */function def(obj,key,val,enumerable){Object.defineProperty(obj,key,{value:val,enumerable:!!enumerable,writable:true,configurable:true});}/**
	 * Parse simple path.
	 */var bailRE=/[^\w\.\$]/;function parsePath(path){if(bailRE.test(path)){return;}else{var segments=path.split('.');return function(obj){for(var i=0;i<segments.length;i++){if(!obj){return;}obj=obj[segments[i]];}return obj;};}}/**
	 * update query string parameter
	 */function updateQueryStringParameter(uri,key,value){var re=new RegExp('([?&])'+key+'=.*?(&|$)','i');var separator=uri.indexOf('?')!==-1?'&':'?';if(uri.match(re)){return uri.replace(re,'$1'+key+'='+encodeURIComponent(value)+'$2');}else{return uri+separator+key+'='+encodeURIComponent(value);}}/*  */// can we use __proto__?
	var hasProto='__proto__'in{};// Browser environment sniffing
	var inBrowser=typeof window!=='undefined'&&Object.prototype.toString.call(window)!=='[object Object]';var UA=inBrowser&&window.navigator.userAgent.toLowerCase();var isIE=UA&&/msie|trident/.test(UA);var isIE9=UA&&UA.indexOf('msie 9.0')>0;var isEdge=UA&&UA.indexOf('edge/')>0;var isAndroid=UA&&UA.indexOf('android')>0;var isIOS=UA&&/iphone|ipad|ipod|ios/.test(UA);// detect devtools
	var devtools=inBrowser&&window.__VUE_DEVTOOLS_GLOBAL_HOOK__;/* istanbul ignore next */function isNative(Ctor){return /native code/.test(Ctor.toString());}/**
	 * Defer a task to execute it asynchronously.
	 */var nextTick=function(){var callbacks=[];var pending=false;function nextTickHandler(){pending=false;var copies=callbacks.slice(0);callbacks.length=0;for(var i=0;i<copies.length;i++){copies[i]();}}var timerFunc=function timerFunc(){setTimeout(nextTickHandler,0);};return function queueNextTick(cb,ctx){var func=ctx?function(){cb.call(ctx);}:cb;callbacks.push(func);if(!pending){pending=true;timerFunc();}};}();var _Set;/* istanbul ignore if */if(typeof Set!=='undefined'&&isNative(Set)){// use native Set when available.
	_Set=Set;}else{// a non-standard Set polyfill that only works with primitive keys.
	_Set=function(){function Set(){this.set=Object.create(null);}Set.prototype.has=function has(key){return this.set[key]!==undefined;};Set.prototype.add=function add(key){this.set[key]=1;};Set.prototype.clear=function clear(){this.set=Object.create(null);};return Set;}();}/* not type checking this file because flow doesn't play well with Proxy */var hasProxy;var proxyHandlers;var initProxy;{var allowedGlobals=makeMap('Infinity,undefined,NaN,isFinite,isNaN,'+'parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,'+'Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,'+'require'// for Webpack/Browserify
	);hasProxy=typeof Proxy!=='undefined'&&Proxy.toString().match(/native code/);proxyHandlers={has:function has(target,key){var has=key in target;var isAllowed=allowedGlobals(key)||key.charAt(0)==='_';if(!has&&!isAllowed){warn("Property or method \""+key+"\" is not defined on the instance but "+"referenced during render. Make sure to declare reactive data "+"properties in the data option.",target);}return has||!isAllowed;}};initProxy=function initProxy(vm){if(hasProxy){vm._renderProxy=new Proxy(vm,proxyHandlers);}else{vm._renderProxy=vm;}};}/*  */var uid$2=0;/**
	 * A dep is an observable that can have multiple
	 * directives subscribing to it.
	 */var Dep=function Dep(){this.id=uid$2++;this.subs=[];};Dep.prototype.addSub=function addSub(sub){this.subs.push(sub);};Dep.prototype.removeSub=function removeSub(sub){remove(this.subs,sub);};Dep.prototype.depend=function depend(){if(Dep.target){Dep.target.addDep(this);}};Dep.prototype.notify=function notify(){// stablize the subscriber list first
	var subs=this.subs.slice();for(var i=0,l=subs.length;i<l;i++){subs[i].update();}};// the current target watcher being evaluated.
	// this is globally unique because there could be only one
	// watcher being evaluated at any time.
	Dep.target=null;var targetStack=[];function pushTarget(_target){if(Dep.target){targetStack.push(Dep.target);}Dep.target=_target;}function popTarget(){Dep.target=targetStack.pop();}/*  */var queue=[];var has$1={};var circular={};var waiting=false;var flushing=false;var index=0;/**
	 * Reset the scheduler's state.
	 */function resetSchedulerState(){queue.length=0;has$1={};{circular={};}waiting=flushing=false;}/**
	 * Flush both queues and run the watchers.
	 */function flushSchedulerQueue(){flushing=true;// Sort queue before flush.
	// This ensures that:
	// 1. Components are updated from parent to child. (because parent is always
	//    created before the child)
	// 2. A component's user watchers are run before its render watcher (because
	//    user watchers are created before the render watcher)
	// 3. If a component is destroyed during a parent component's watcher run,
	//    its watchers can be skipped.
	queue.sort(function(a,b){return a.id-b.id;});// do not cache length because more watchers might be pushed
	// as we run existing watchers
	for(index=0;index<queue.length;index++){var watcher=queue[index];var id=watcher.id;has$1[id]=null;watcher.run();// in dev build, check and stop circular updates.
	if("developement"!=='production'&&has$1[id]!=null){circular[id]=(circular[id]||0)+1;if(circular[id]>config._maxUpdateCount){warn('You may have an infinite update loop '+(watcher.user?"in watcher with expression \""+watcher.expression+"\"":"in a component render function."),watcher.vm);break;}}}// devtool hook
	/* istanbul ignore if */if(devtools&&config.devtools){devtools.emit('flush');}resetSchedulerState();}/**
	 * Push a watcher into the watcher queue.
	 * Jobs with duplicate IDs will be skipped unless it's
	 * pushed when the queue is being flushed.
	 */function queueWatcher(watcher){var id=watcher.id;if(has$1[id]==null){has$1[id]=true;if(!flushing){queue.push(watcher);}else{// if already flushing, splice the watcher based on its id
	// if already past its id, it will be run next immediately.
	var i=queue.length-1;while(i>=0&&queue[i].id>watcher.id){i--;}queue.splice(Math.max(i,index)+1,0,watcher);}// queue the flush
	if(!waiting){waiting=true;nextTick(flushSchedulerQueue);}}}/*  */var uid$1=0;/**
	 * A watcher parses an expression, collects dependencies,
	 * and fires callback when the expression value changes.
	 * This is used for both the $watch() api and directives.
	 */var Watcher=function Watcher(vm,expOrFn,cb,options){if(options===void 0)options={};this.vm=vm;vm._watchers.push(this);// options
	this.deep=!!options.deep;this.user=!!options.user;this.lazy=!!options.lazy;this.sync=!!options.sync;this.expression=expOrFn.toString();this.cb=cb;this.id=++uid$1;// uid for batching
	this.active=true;this.dirty=this.lazy;// for lazy watchers
	this.deps=[];this.newDeps=[];this.depIds=new _Set();this.newDepIds=new _Set();// parse expression for getter
	if(typeof expOrFn==='function'){this.getter=expOrFn;}else{this.getter=parsePath(expOrFn);if(!this.getter){this.getter=function(){};"developement"!=='production'&&warn("Failed watching path: \""+expOrFn+"\" "+'Watcher only accepts simple dot-delimited paths. '+'For full control, use a function instead.',vm);}}this.value=this.lazy?undefined:this.get();};/**
	 * Evaluate the getter, and re-collect dependencies.
	 */Watcher.prototype.get=function get(){pushTarget(this);var value=this.getter.call(this.vm,this.vm);// "touch" every property so they are all tracked as
	// dependencies for deep watching
	if(this.deep){traverse(value);}popTarget();this.cleanupDeps();return value;};/**
	 * Add a dependency to this directive.
	 */Watcher.prototype.addDep=function addDep(dep){var id=dep.id;if(!this.newDepIds.has(id)){this.newDepIds.add(id);this.newDeps.push(dep);if(!this.depIds.has(id)){dep.addSub(this);}}};/**
	 * Clean up for dependency collection.
	 */Watcher.prototype.cleanupDeps=function cleanupDeps(){var this$1=this;var i=this.deps.length;while(i--){var dep=this$1.deps[i];if(!this$1.newDepIds.has(dep.id)){dep.removeSub(this$1);}}var tmp=this.depIds;this.depIds=this.newDepIds;this.newDepIds=tmp;this.newDepIds.clear();tmp=this.deps;this.deps=this.newDeps;this.newDeps=tmp;this.newDeps.length=0;};/**
	 * Subscriber interface.
	 * Will be called when a dependency changes.
	 */Watcher.prototype.update=function update(){/* istanbul ignore else */if(this.lazy){this.dirty=true;}else if(this.sync){this.run();}else{queueWatcher(this);}};/**
	 * Scheduler job interface.
	 * Will be called by the scheduler.
	 */Watcher.prototype.run=function run(){if(this.active){var value=this.get();if(value!==this.value||// Deep watchers and watchers on Object/Arrays should fire even
	// when the value is the same, because the value may
	// have mutated.
	isObject(value)||this.deep){// set new value
	var oldValue=this.value;this.value=value;if(this.user){try{this.cb.call(this.vm,value,oldValue);}catch(e){"developement"!=='production'&&warn("Error in watcher \""+this.expression+"\"",this.vm);/* istanbul ignore else */if(config.errorHandler){config.errorHandler.call(null,e,this.vm);}else{throw e;}}}else{this.cb.call(this.vm,value,oldValue);}}}};/**
	 * Evaluate the value of the watcher.
	 * This only gets called for lazy watchers.
	 */Watcher.prototype.evaluate=function evaluate(){this.value=this.get();this.dirty=false;};/**
	 * Depend on all deps collected by this watcher.
	 */Watcher.prototype.depend=function depend(){var this$1=this;var i=this.deps.length;while(i--){this$1.deps[i].depend();}};/**
	 * Remove self from all dependencies' subcriber list.
	 */Watcher.prototype.teardown=function teardown(){var this$1=this;if(this.active){// remove self from vm's watcher list
	// this is a somewhat expensive operation so we skip it
	// if the vm is being destroyed or is performing a v-for
	// re-render (the watcher list is then filtered by v-for).
	if(!this.vm._isBeingDestroyed&&!this.vm._vForRemoving){remove(this.vm._watchers,this);}var i=this.deps.length;while(i--){this$1.deps[i].removeSub(this$1);}this.active=false;}};/**
	 * Recursively traverse an object to evoke all converted
	 * getters, so that every nested property inside the object
	 * is collected as a "deep" dependency.
	 */var seenObjects=new _Set();function traverse(val,seen){var i,keys;if(!seen){seen=seenObjects;seen.clear();}var isA=Array.isArray(val);var isO=isObject(val);if((isA||isO)&&Object.isExtensible(val)){if(val.__ob__){var depId=val.__ob__.dep.id;if(seen.has(depId)){return;}else{seen.add(depId);}}if(isA){i=val.length;while(i--){traverse(val[i],seen);}}else if(isO){keys=Object.keys(val);i=keys.length;while(i--){traverse(val[keys[i]],seen);}}}}/*
	 * not type checking this file because flow doesn't play well with
	 * dynamically accessing methods on Array prototype
	 */var arrayProto=Array.prototype;var arrayMethods=Object.create(arrayProto);['push','pop','shift','unshift','splice','sort','reverse'].forEach(function(method){// cache original method
	var original=arrayProto[method];def(arrayMethods,method,function mutator(){var arguments$1=arguments;// avoid leaking arguments:
	// http://jsperf.com/closure-with-arguments
	var i=arguments.length;var args=new Array(i);while(i--){args[i]=arguments$1[i];}var result=original.apply(this,args);var ob=this.__ob__;var inserted;switch(method){case'push':inserted=args;break;case'unshift':inserted=args;break;case'splice':inserted=args.slice(2);break;}if(inserted){ob.observeArray(inserted);}// notify change
	ob.dep.notify();return result;});});/*  */var arrayKeys=Object.getOwnPropertyNames(arrayMethods);/**
	 * By default, when a reactive property is set, the new value is
	 * also converted to become reactive. However when passing down props,
	 * we don't want to force conversion because the value may be a nested value
	 * under a frozen data structure. Converting it would defeat the optimization.
	 */var observerState={shouldConvert:true,isSettingProps:false};/**
	 * Observer class that are attached to each observed
	 * object. Once attached, the observer converts target
	 * object's property keys into getter/setters that
	 * collect dependencies and dispatches updates.
	 */var Observer=function Observer(value){this.value=value;this.dep=new Dep();this.vmCount=0;def(value,'__ob__',this);if(Array.isArray(value)){var augment=hasProto?protoAugment:copyAugment;augment(value,arrayMethods,arrayKeys);this.observeArray(value);}else{this.walk(value);}};/**
	 * Walk through each property and convert them into
	 * getter/setters. This method should only be called when
	 * value type is Object.
	 */Observer.prototype.walk=function walk(obj){var keys=Object.keys(obj);for(var i=0;i<keys.length;i++){defineReactive$$1(obj,keys[i],obj[keys[i]]);}};/**
	 * Observe a list of Array items.
	 */Observer.prototype.observeArray=function observeArray(items){for(var i=0,l=items.length;i<l;i++){observe(items[i]);}};// helpers
	/**
	 * Augment an target Object or Array by intercepting
	 * the prototype chain using __proto__
	 */function protoAugment(target,src){/* eslint-disable no-proto */target.__proto__=src;/* eslint-enable no-proto */}/**
	 * Augment an target Object or Array by defining
	 * hidden properties.
	 *
	 * istanbul ignore next
	 */function copyAugment(target,src,keys){for(var i=0,l=keys.length;i<l;i++){var key=keys[i];def(target,key,src[key]);}}/**
	 * Attempt to create an observer instance for a value,
	 * returns the new observer if successfully observed,
	 * or the existing observer if the value already has one.
	 */function observe(value){if(!isObject(value)){return;}var ob;if(hasOwn(value,'__ob__')&&value.__ob__ instanceof Observer){ob=value.__ob__;}else if(observerState.shouldConvert&&(Array.isArray(value)||isPlainObject(value))&&Object.isExtensible(value)&&!value._isVue){ob=new Observer(value);}return ob;}/**
	 * Define a reactive property on an Object.
	 */function defineReactive$$1(obj,key,val,customSetter){var dep=new Dep();var property=Object.getOwnPropertyDescriptor(obj,key);if(property&&property.configurable===false){return;}// cater for pre-defined getter/setters
	var getter=property&&property.get;var setter=property&&property.set;var childOb=observe(val);Object.defineProperty(obj,key,{enumerable:true,configurable:true,get:function reactiveGetter(){var value=getter?getter.call(obj):val;if(Dep.target){dep.depend();if(childOb){childOb.dep.depend();}if(Array.isArray(value)){dependArray(value);}}return value;},set:function reactiveSetter(newVal){var value=getter?getter.call(obj):val;if(newVal===value){return;}if("developement"!=='production'&&customSetter){customSetter();}if(setter){setter.call(obj,newVal);}else{val=newVal;}childOb=observe(newVal);dep.notify();}});}/**
	 * Set a property on an object. Adds the new property and
	 * triggers change notification if the property doesn't
	 * already exist.
	 */function set(obj,key,val){if(Array.isArray(obj)){obj.splice(key,1,val);return val;}if(hasOwn(obj,key)){obj[key]=val;return;}var ob=obj.__ob__;if(obj._isVue||ob&&ob.vmCount){"developement"!=='production'&&warn('Avoid adding reactive properties to a Vue instance or its root $data '+'at runtime - declare it upfront in the data option.');return;}if(!ob){obj[key]=val;return;}defineReactive$$1(ob.value,key,val);ob.dep.notify();return val;}/**
	 * Delete a property and trigger change if necessary.
	 */function del(obj,key){var ob=obj.__ob__;if(obj._isVue||ob&&ob.vmCount){"developement"!=='production'&&warn('Avoid deleting properties on a Vue instance or its root $data '+'- just set it to null.');return;}if(!hasOwn(obj,key)){return;}delete obj[key];if(!ob){return;}ob.dep.notify();}/**
	 * Collect dependencies on array elements when the array is touched, since
	 * we cannot intercept array element access like property getters.
	 */function dependArray(value){for(var e=void 0,i=0,l=value.length;i<l;i++){e=value[i];e&&e.__ob__&&e.__ob__.dep.depend();if(Array.isArray(e)){dependArray(e);}}}/*  */function initState(vm){vm._watchers=[];initProps(vm);initData(vm);initComputed(vm);initMethods(vm);initWatch(vm);}function initProps(vm){var props=vm.$options.props;if(props){var propsData=vm.$options.propsData||{};var keys=vm.$options._propKeys=Object.keys(props);var isRoot=!vm.$parent;// root instance props should be converted
	observerState.shouldConvert=isRoot;var loop=function loop(i){var key=keys[i];/* istanbul ignore else */{defineReactive$$1(vm,key,validateProp(key,props,propsData,vm),function(){if(vm.$parent&&!observerState.isSettingProps){warn("Avoid mutating a prop directly since the value will be "+"overwritten whenever the parent component re-renders. "+"Instead, use a data or computed property based on the prop's "+"value. Prop being mutated: \""+key+"\"",vm);}});}};for(var i=0;i<keys.length;i++){loop(i);}observerState.shouldConvert=true;}}function initData(vm){var data=vm.$options.data;data=vm._data=typeof data==='function'?data.call(vm):data||{};if(!isPlainObject(data)){data={};"developement"!=='production'&&warn('data functions should return an object.',vm);}// proxy data on instance
	var keys=Object.keys(data);var props=vm.$options.props;var i=keys.length;while(i--){if(props&&hasOwn(props,keys[i])){"developement"!=='production'&&warn("The data property \""+keys[i]+"\" is already declared as a prop. "+"Use prop default value instead.",vm);}else{proxy(vm,keys[i]);}}// observe data
	observe(data);data.__ob__&&data.__ob__.vmCount++;}function initComputed(vm){var computedSharedDefinition={enumerable:true,configurable:true,get:noop,set:noop};var computed=vm.$options.computed;if(computed){for(var key in computed){var userDef=computed[key];if(typeof userDef==='function'){computedSharedDefinition.get=makeComputedGetter(userDef,vm);computedSharedDefinition.set=noop;}else{computedSharedDefinition.get=userDef.get?userDef.cache!==false?makeComputedGetter(userDef.get,vm):bind$1(userDef.get,vm):noop;computedSharedDefinition.set=userDef.set?bind$1(userDef.set,vm):noop;}Object.defineProperty(vm,key,computedSharedDefinition);}}}function makeComputedGetter(getter,owner){var watcher=new Watcher(owner,getter,noop,{lazy:true});return function computedGetter(){if(watcher.dirty){watcher.evaluate();}if(Dep.target){watcher.depend();}return watcher.value;};}function initMethods(vm){var methods=vm.$options.methods;if(methods){for(var key in methods){vm[key]=methods[key]==null?noop:bind$1(methods[key],vm);if("developement"!=='production'&&methods[key]==null){warn("method \""+key+"\" has an undefined value in the component definition. "+"Did you reference the function correctly?",vm);}}}}function initWatch(vm){var watch=vm.$options.watch;if(watch){for(var key in watch){var handler=watch[key];if(Array.isArray(handler)){for(var i=0;i<handler.length;i++){createWatcher(vm,key,handler[i]);}}else{createWatcher(vm,key,handler);}}}}function createWatcher(vm,key,handler){var options;if(isPlainObject(handler)){options=handler;handler=handler.handler;}if(typeof handler==='string'){handler=vm[handler];}vm.$watch(key,handler,options);}function stateMixin(Vue){// flow somehow has problems with directly declared definition object
	// when using Object.defineProperty, so we have to procedurally build up
	// the object here.
	var dataDef={};dataDef.get=function(){return this._data;};{dataDef.set=function(newData){warn('Avoid replacing instance root $data. '+'Use nested data properties instead.',this);};}Object.defineProperty(Vue.prototype,'$data',dataDef);Vue.prototype.$set=set;Vue.prototype.$delete=del;Vue.prototype.$watch=function(expOrFn,cb,options){var vm=this;options=options||{};options.user=true;var watcher=new Watcher(vm,expOrFn,cb,options);if(options.immediate){cb.call(vm,watcher.value);}return function unwatchFn(){watcher.teardown();};};}function proxy(vm,key){if(!isReserved(key)){Object.defineProperty(vm,key,{configurable:true,enumerable:true,get:function proxyGetter(){return vm._data[key];},set:function proxySetter(val){vm._data[key]=val;}});}}/*  */var VNode=function VNode(tag,data,children,text,elm,context,componentOptions){this.tag=tag;this.data=data;this.children=children;this.text=text;this.elm=elm;this.context=context;this.functionalContext=undefined;this.key=data&&data.key;this.componentOptions=componentOptions;this.child=undefined;this.parent=undefined;this.raw=false;this.isStatic=false;this.isRootInsert=true;this.isComment=false;this.isCloned=false;};var emptyVNode=function emptyVNode(){var node=new VNode();node.text='';node.isComment=true;return node;};// optimized shallow clone
	// used for static nodes and slot nodes because they may be reused across
	// multiple renders, cloning them avoids errors when DOM manipulations rely
	// on their elm reference.
	function cloneVNode(vnode){var cloned=new VNode(vnode.tag,vnode.data,vnode.children,vnode.text,vnode.elm,vnode.context,vnode.componentOptions);cloned.isStatic=vnode.isStatic;cloned.key=vnode.key;cloned.isCloned=true;cloned.isComment=vnode.isComment;return cloned;}function cloneVNodes(vnodes){var res=new Array(vnodes.length);for(var i=0;i<vnodes.length;i++){res[i]=cloneVNode(vnodes[i]);}return res;}/*  */function mergeVNodeHook(def,hookKey,hook,key){key=key+hookKey;var injectedHash=def.__injected||(def.__injected={});if(!injectedHash[key]){injectedHash[key]=true;var oldHook=def[hookKey];if(oldHook){def[hookKey]=function(){oldHook.apply(this,arguments);hook.apply(this,arguments);};}else{def[hookKey]=hook;}}}/*  */function updateListeners(on,oldOn,add,remove$$1,vm){var name,cur,old,fn,event,capture;for(name in on){cur=on[name];old=oldOn[name];if(!cur){"developement"!=='production'&&warn("Invalid handler for event \""+name+"\": got "+String(cur),vm);}else if(!old){capture=name.charAt(0)==='!';event=capture?name.slice(1):name;if(Array.isArray(cur)){add(event,cur.invoker=arrInvoker(cur),capture);}else{if(!cur.invoker){fn=cur;cur=on[name]={};cur.fn=fn;cur.invoker=fnInvoker(cur);}add(event,cur.invoker,capture);}}else if(cur!==old){if(Array.isArray(old)){old.length=cur.length;for(var i=0;i<old.length;i++){old[i]=cur[i];}on[name]=old;}else{old.fn=cur;on[name]=old;}}}for(name in oldOn){if(!on[name]){event=name.charAt(0)==='!'?name.slice(1):name;remove$$1(event,oldOn[name].invoker);}}}function arrInvoker(arr){return function(ev){var arguments$1=arguments;var single=arguments.length===1;for(var i=0;i<arr.length;i++){single?arr[i](ev):arr[i].apply(null,arguments$1);}};}function fnInvoker(o){return function(ev){var single=arguments.length===1;single?o.fn(ev):o.fn.apply(null,arguments);};}/*  */function normalizeChildren(children,ns,nestedIndex){if(isPrimitive(children)){return[createTextVNode(children)];}if(Array.isArray(children)){var res=[];for(var i=0,l=children.length;i<l;i++){var c=children[i];var last=res[res.length-1];//  nested
	if(Array.isArray(c)){res.push.apply(res,normalizeChildren(c,ns,(nestedIndex||'')+"_"+i));}else if(isPrimitive(c)){if(last&&last.text){last.text+=String(c);}else if(c!==''){// convert primitive to vnode
	res.push(createTextVNode(c));}}else if(c instanceof VNode){if(c.text&&last&&last.text){last.text+=c.text;}else{// inherit parent namespace
	if(ns){applyNS(c,ns);}// default key for nested array children (likely generated by v-for)
	if(c.tag&&c.key==null&&nestedIndex!=null){c.key="__vlist"+nestedIndex+"_"+i+"__";}res.push(c);}}}return res;}}function createTextVNode(val){return new VNode(undefined,undefined,undefined,String(val));}function applyNS(vnode,ns){if(vnode.tag&&!vnode.ns){vnode.ns=ns;if(vnode.children){for(var i=0,l=vnode.children.length;i<l;i++){applyNS(vnode.children[i],ns);}}}}/*  */function getFirstComponentChild(children){return children&&children.filter(function(c){return c&&c.componentOptions;})[0];}/*  */var activeInstance=null;function initLifecycle(vm){var options=vm.$options;// locate first non-abstract parent
	var parent=options.parent;if(parent&&!options.abstract){while(parent.$options.abstract&&parent.$parent){parent=parent.$parent;}parent.$children.push(vm);}vm.$parent=parent;vm.$root=parent?parent.$root:vm;vm.$children=[];vm.$refs={};vm._watcher=null;vm._inactive=false;vm._isMounted=false;vm._isDestroyed=false;vm._isBeingDestroyed=false;}function lifecycleMixin(Vue){Vue.prototype._mount=function(el,hydrating){var vm=this;vm.$el=el;if(!vm.$options.render){vm.$options.render=emptyVNode;{/* istanbul ignore if */if(vm.$options.template){warn('You are using the runtime-only build of Vue where the template '+'option is not available. Either pre-compile the templates into '+'render functions, or use the compiler-included build.',vm);}else{warn('Failed to mount component: template or render function not defined.',vm);}}}callHook(vm,'beforeMount');vm._watcher=new Watcher(vm,function(){vm._update(vm._render(),hydrating);},noop);hydrating=false;// manually mounted instance, call mounted on self
	// mounted is called for render-created child components in its inserted hook
	if(vm.$vnode==null){vm._isMounted=true;callHook(vm,'mounted');}return vm;};Vue.prototype._update=function(vnode,hydrating){var vm=this;if(vm._isMounted){callHook(vm,'beforeUpdate');}var prevEl=vm.$el;var prevActiveInstance=activeInstance;activeInstance=vm;var prevVnode=vm._vnode;vm._vnode=vnode;if(!prevVnode){// Vue.prototype.__patch__ is injected in entry points
	// based on the rendering backend used.
	vm.$el=vm.__patch__(vm.$el,vnode,hydrating);}else{vm.$el=vm.__patch__(prevVnode,vnode);}activeInstance=prevActiveInstance;// update __vue__ reference
	if(prevEl){prevEl.__vue__=null;}if(vm.$el){vm.$el.__vue__=vm;}// if parent is an HOC, update its $el as well
	if(vm.$vnode&&vm.$parent&&vm.$vnode===vm.$parent._vnode){vm.$parent.$el=vm.$el;}if(vm._isMounted){callHook(vm,'updated');}};Vue.prototype._updateFromParent=function(propsData,listeners,parentVnode,renderChildren){var vm=this;var hasChildren=!!(vm.$options._renderChildren||renderChildren);vm.$options._parentVnode=parentVnode;vm.$options._renderChildren=renderChildren;// update props
	if(propsData&&vm.$options.props){observerState.shouldConvert=false;{observerState.isSettingProps=true;}var propKeys=vm.$options._propKeys||[];for(var i=0;i<propKeys.length;i++){var key=propKeys[i];vm[key]=validateProp(key,vm.$options.props,propsData,vm);}observerState.shouldConvert=true;{observerState.isSettingProps=false;}}// update listeners
	if(listeners){var oldListeners=vm.$options._parentListeners;vm.$options._parentListeners=listeners;vm._updateListeners(listeners,oldListeners);}// resolve slots + force update if has children
	if(hasChildren){vm.$slots=resolveSlots(renderChildren,vm._renderContext);vm.$forceUpdate();}};Vue.prototype.$forceUpdate=function(){var vm=this;if(vm._watcher){vm._watcher.update();}};Vue.prototype.$destroy=function(){var vm=this;if(vm._isBeingDestroyed){return;}callHook(vm,'beforeDestroy');vm._isBeingDestroyed=true;// remove self from parent
	var parent=vm.$parent;if(parent&&!parent._isBeingDestroyed&&!vm.$options.abstract){remove(parent.$children,vm);}// teardown watchers
	if(vm._watcher){vm._watcher.teardown();}var i=vm._watchers.length;while(i--){vm._watchers[i].teardown();}// remove reference from data ob
	// frozen object may not have observer.
	if(vm._data.__ob__){vm._data.__ob__.vmCount--;}// call the last hook...
	vm._isDestroyed=true;callHook(vm,'destroyed');// turn off all instance listeners.
	vm.$off();// remove __vue__ reference
	if(vm.$el){vm.$el.__vue__=null;}// invoke destroy hooks on current rendered tree
	vm.__patch__(vm._vnode,null);};}function callHook(vm,hook){var handlers=vm.$options[hook];if(handlers){for(var i=0,j=handlers.length;i<j;i++){handlers[i].call(vm);}}vm.$emit('hook:'+hook);}/*  */var hooks={init:init,prepatch:prepatch,insert:insert,destroy:destroy$1};var hooksToMerge=Object.keys(hooks);function createComponent(Ctor,data,context,children,tag){if(!Ctor){return;}if(isObject(Ctor)){Ctor=Vue$2.extend(Ctor);}if(typeof Ctor!=='function'){{warn("Invalid Component definition: "+String(Ctor),context);}return;}// async component
	if(!Ctor.cid){if(Ctor.resolved){Ctor=Ctor.resolved;}else{Ctor=resolveAsyncComponent(Ctor,function(){// it's ok to queue this on every render because
	// $forceUpdate is buffered by the scheduler.
	context.$forceUpdate();});if(!Ctor){// return nothing if this is indeed an async component
	// wait for the callback to trigger parent update.
	return;}}}data=data||{};// extract props
	var propsData=extractProps(data,Ctor);// functional component
	if(Ctor.options.functional){return createFunctionalComponent(Ctor,propsData,data,context,children);}// extract listeners, since these needs to be treated as
	// child component listeners instead of DOM listeners
	var listeners=data.on;// replace with listeners with .native modifier
	data.on=data.nativeOn;if(Ctor.options.abstract){// abstract components do not keep anything
	// other than props & listeners
	data={};}// merge component management hooks onto the placeholder node
	mergeHooks(data);// return a placeholder vnode
	var name=Ctor.options.name||tag;var vnode=new VNode("vue-component-"+Ctor.cid+(name?"-"+name:''),data,undefined,undefined,undefined,context,{Ctor:Ctor,propsData:propsData,listeners:listeners,tag:tag,children:children});return vnode;}function createFunctionalComponent(Ctor,propsData,data,context,children){var props={};var propOptions=Ctor.options.props;if(propOptions){for(var key in propOptions){props[key]=validateProp(key,propOptions,propsData);}}var vnode=Ctor.options.render.call(null,// ensure the createElement function in functional components
	// gets a unique context - this is necessary for correct named slot check
	bind$1(createElement,{_self:Object.create(context)}),{props:props,data:data,parent:context,children:normalizeChildren(children),slots:function slots(){return resolveSlots(children,context);}});if(vnode instanceof VNode){vnode.functionalContext=context;if(data.slot){(vnode.data||(vnode.data={})).slot=data.slot;}}return vnode;}function createComponentInstanceForVnode(vnode,// we know it's MountedComponentVNode but flow doesn't
	parent// activeInstance in lifecycle state
	){var vnodeComponentOptions=vnode.componentOptions;var options={_isComponent:true,parent:parent,propsData:vnodeComponentOptions.propsData,_componentTag:vnodeComponentOptions.tag,_parentVnode:vnode,_parentListeners:vnodeComponentOptions.listeners,_renderChildren:vnodeComponentOptions.children};// check inline-template render functions
	var inlineTemplate=vnode.data.inlineTemplate;if(inlineTemplate){options.render=inlineTemplate.render;options.staticRenderFns=inlineTemplate.staticRenderFns;}return new vnodeComponentOptions.Ctor(options);}function init(vnode,hydrating){if(!vnode.child||vnode.child._isDestroyed){var child=vnode.child=createComponentInstanceForVnode(vnode,activeInstance);child.$mount(hydrating?vnode.elm:undefined,hydrating);}}function prepatch(oldVnode,vnode){var options=vnode.componentOptions;var child=vnode.child=oldVnode.child;if(child){child._updateFromParent(options.propsData,// updated props
	options.listeners,// updated listeners
	vnode,// new parent vnode
	options.children// new children
	);}}function insert(vnode){if(!vnode.child._isMounted){vnode.child._isMounted=true;callHook(vnode.child,'mounted');}if(vnode.data.keepAlive){vnode.child._inactive=false;callHook(vnode.child,'activated');}}function destroy$1(vnode){if(!vnode.child._isDestroyed){if(!vnode.data.keepAlive){vnode.child.$destroy();}else{vnode.child._inactive=true;callHook(vnode.child,'deactivated');}}}function resolveAsyncComponent(factory,cb){if(factory.requested){// pool callbacks
	factory.pendingCallbacks.push(cb);}else{factory.requested=true;var cbs=factory.pendingCallbacks=[cb];var sync=true;var resolve=function resolve(res){if(isObject(res)){res=Vue$2.extend(res);}// cache resolved
	factory.resolved=res;// invoke callbacks only if this is not a synchronous resolve
	// (async resolves are shimmed as synchronous during SSR)
	if(!sync){for(var i=0,l=cbs.length;i<l;i++){cbs[i](res);}}};var reject=function reject(reason){"developement"!=='production'&&warn("Failed to resolve async component: "+String(factory)+(reason?"\nReason: "+reason:''));};var res=factory(resolve,reject);// handle promise
	if(res&&typeof res.then==='function'&&!factory.resolved){res.then(resolve,reject);}sync=false;// return in case resolved synchronously
	return factory.resolved;}}function extractProps(data,Ctor){// we are only extrating raw values here.
	// validation and default values are handled in the child
	// component itself.
	var propOptions=Ctor.options.props;if(!propOptions){return;}var res={};var attrs=data.attrs;var props=data.props;var domProps=data.domProps;if(attrs||props||domProps){for(var key in propOptions){var altKey=hyphenate(key);checkProp(res,props,key,altKey,true)||checkProp(res,attrs,key,altKey)||checkProp(res,domProps,key,altKey);}}return res;}function checkProp(res,hash,key,altKey,preserve){if(hash){if(hasOwn(hash,key)){res[key]=hash[key];if(!preserve){delete hash[key];}return true;}else if(hasOwn(hash,altKey)){res[key]=hash[altKey];if(!preserve){delete hash[altKey];}return true;}}return false;}function mergeHooks(data){if(!data.hook){data.hook={};}for(var i=0;i<hooksToMerge.length;i++){var key=hooksToMerge[i];var fromParent=data.hook[key];var ours=hooks[key];data.hook[key]=fromParent?mergeHook$1(ours,fromParent):ours;}}function mergeHook$1(a,b){// since all hooks have at most two args, use fixed args
	// to avoid having to use fn.apply().
	return function(_,__){a(_,__);b(_,__);};}/*  */// wrapper function for providing a more flexible interface
	// without getting yelled at by flow
	function createElement(tag,data,children){// 如果节点没有data，传入的第二个参数就是children
	// 例如：_h('view', [_h('view', { on: { "click": onClick } })])
	if(data&&(Array.isArray(data)||(typeof data==='undefined'?'undefined':_typeof(data))!=='object')){children=data;data=undefined;}// make sure to use real instance instead of proxy as context
	return _createElement(this._self,tag,data,children);}function _createElement(context,tag,data,children){if(data&&data.__ob__){"developement"!=='production'&&warn("Avoid using observed data object as vnode data: "+JSON.stringify(data)+"\n"+'Always create fresh vnode data objects in each render!',context);return;}if(!tag){// in case of component :is set to falsy value
	return emptyVNode();}if(typeof tag==='string'){var Ctor;if(config.isReservedTag(tag)){// platform built-in elements
	return new VNode(tag,data,normalizeChildren(children),undefined,undefined,context);}else if(Ctor=resolveAsset(context.$options,'components',tag)){// component
	return createComponent(Ctor,data,context,children,tag);}else{// unknown or unlisted namespaced elements
	// check at runtime because it may get assigned a namespace when its
	// parent normalizes children
	if("developement"!=='production'&&config.isUnknownElement(tag)){warn('Unknown custom element: <'+tag+'> - did you '+'register the component correctly? For recursive components, '+'make sure to provide the "name" option.');}return new VNode(tag,data,normalizeChildren(children),undefined,undefined,context);}}else{// direct component options / constructor
	return createComponent(tag,data,context,children);}}/*  */function initRender(vm){vm.$vnode=null;// the placeholder node in parent tree
	vm._vnode=null;// the root of the child tree
	vm._staticTrees=null;vm._renderContext=vm.$options._parentVnode&&vm.$options._parentVnode.context;vm.$slots=resolveSlots(vm.$options._renderChildren,vm._renderContext);// bind the public createElement fn to this instance
	// so that we get proper render context inside it.
	vm.$createElement=bind$1(createElement,vm);if(vm.$options.el){vm.$mount(vm.$options.el);}}function renderMixin(Vue){Vue.prototype.$nextTick=function(fn){nextTick(fn,this);};Vue.prototype._render=function(){var vm=this;var ref=vm.$options;var render=ref.render;var staticRenderFns=ref.staticRenderFns;var _parentVnode=ref._parentVnode;if(vm._isMounted){// clone slot nodes on re-renders
	for(var key in vm.$slots){vm.$slots[key]=cloneVNodes(vm.$slots[key]);}}if(staticRenderFns&&!vm._staticTrees){vm._staticTrees=[];}// set parent vnode. this allows render functions to have access
	// to the data on the placeholder node.
	vm.$vnode=_parentVnode;// render self
	var vnode;try{vnode=render.call(vm._renderProxy,vm.$createElement);}catch(e){{warn("Error when rendering "+formatComponentName(vm)+":");}/* istanbul ignore else */if(config.errorHandler){config.errorHandler.call(null,e,vm);}else{setTimeout(function(){throw e;},0);}// return previous vnode to prevent render error causing blank component
	vnode=vm._vnode;}// return empty vnode in case the render function errored out
	if(!(vnode instanceof VNode)){if("developement"!=='production'&&Array.isArray(vnode)){warn('Multiple root nodes returned from render function. Render function '+'should return a single root node.',vm);}vnode=emptyVNode();}// set parent
	vnode.parent=_parentVnode;return vnode;};// shorthands used in render functions
	Vue.prototype._h=createElement;// toString for mustaches
	Vue.prototype._s=_toString;// number conversion
	Vue.prototype._n=toNumber;// empty vnode
	Vue.prototype._e=emptyVNode;// loose equal
	Vue.prototype._q=looseEqual;// loose indexOf
	Vue.prototype._i=looseIndexOf;// render static tree by index
	Vue.prototype._m=function renderStatic(index,isInFor){var tree=this._staticTrees[index];// if has already-rendered static tree and not inside v-for,
	// we can reuse the same tree by doing a shallow clone.
	if(tree&&!isInFor){return Array.isArray(tree)?cloneVNodes(tree):cloneVNode(tree);}// otherwise, render a fresh tree.
	tree=this._staticTrees[index]=this.$options.staticRenderFns[index].call(this._renderProxy);if(Array.isArray(tree)){for(var i=0;i<tree.length;i++){if(typeof tree[i]!=='string'){tree[i].isStatic=true;tree[i].key="__static__"+index+"_"+i;}}}else{tree.isStatic=true;tree.key="__static__"+index;}return tree;};// filter resolution helper
	var identity=function identity(_){return _;};Vue.prototype._f=function resolveFilter(id){return resolveAsset(this.$options,'filters',id,true)||identity;};// render v-for
	Vue.prototype._l=function renderList(val,render){var ret,i,l,keys,key;if(Array.isArray(val)){ret=new Array(val.length);for(i=0,l=val.length;i<l;i++){ret[i]=render(val[i],i);}}else if(typeof val==='number'){ret=new Array(val);for(i=0;i<val;i++){ret[i]=render(i+1,i);}}else if(isObject(val)){keys=Object.keys(val);ret=new Array(keys.length);for(i=0,l=keys.length;i<l;i++){key=keys[i];ret[i]=render(val[key],key,i);}}return ret;};// renderSlot
	Vue.prototype._t=function(name,fallback){var slotNodes=this.$slots[name];// warn duplicate slot usage
	if(slotNodes&&"developement"!=='production'){slotNodes._rendered&&warn("Duplicate presence of slot \""+name+"\" found in the same render tree "+"- this will likely cause render errors.",this);slotNodes._rendered=true;}return slotNodes||fallback;};// apply v-bind object
	Vue.prototype._b=function bindProps(data,value,asProp){if(value){if(!isObject(value)){"developement"!=='production'&&warn('v-bind without argument expects an Object or Array value',this);}else{if(Array.isArray(value)){value=toObject(value);}for(var key in value){if(key==='class'||key==='style'){data[key]=value[key];}else{var hash=asProp||config.mustUseProp(key)?data.domProps||(data.domProps={}):data.attrs||(data.attrs={});hash[key]=value[key];}}}}return data;};// expose v-on keyCodes
	Vue.prototype._k=function getKeyCodes(key){return config.keyCodes[key];};}function resolveSlots(renderChildren,context){var slots={};if(!renderChildren){return slots;}var children=normalizeChildren(renderChildren)||[];var defaultSlot=[];var name,child;for(var i=0,l=children.length;i<l;i++){child=children[i];// named slots should only be respected if the vnode was rendered in the
	// same context.
	if((child.context===context||child.functionalContext===context)&&child.data&&(name=child.data.slot)){var slot=slots[name]||(slots[name]=[]);if(child.tag==='template'){slot.push.apply(slot,child.children);}else{slot.push(child);}}else{defaultSlot.push(child);}}// ignore single whitespace
	if(defaultSlot.length&&!(defaultSlot.length===1&&(defaultSlot[0].text===' '||defaultSlot[0].isComment))){slots.default=defaultSlot;}return slots;}/*  */function initEvents(vm){vm._events=Object.create(null);// init parent attached events
	var listeners=vm.$options._parentListeners;var on=bind$1(vm.$on,vm);var off=bind$1(vm.$off,vm);vm._updateListeners=function(listeners,oldListeners){updateListeners(listeners,oldListeners||{},on,off,vm);};if(listeners){vm._updateListeners(listeners);}}function eventsMixin(Vue){Vue.prototype.$on=function(event,fn){var vm=this;(vm._events[event]||(vm._events[event]=[])).push(fn);return vm;};Vue.prototype.$once=function(event,fn){var vm=this;function on(){vm.$off(event,on);fn.apply(vm,arguments);}on.fn=fn;vm.$on(event,on);return vm;};Vue.prototype.$off=function(event,fn){var vm=this;// all
	if(!arguments.length){vm._events=Object.create(null);return vm;}// specific event
	var cbs=vm._events[event];if(!cbs){return vm;}if(arguments.length===1){vm._events[event]=null;return vm;}// specific handler
	var cb;var i=cbs.length;while(i--){cb=cbs[i];if(cb===fn||cb.fn===fn){cbs.splice(i,1);break;}}return vm;};Vue.prototype.$emit=function(event){var vm=this;var cbs=vm._events[event];if(cbs){cbs=cbs.length>1?toArray(cbs):cbs;var args=toArray(arguments,1);for(var i=0,l=cbs.length;i<l;i++){cbs[i].apply(vm,args);}}return vm;};}/*  */var uid=0;function initMixin(Vue){Vue.prototype._init=function(options){var vm=this;// a uid
	vm._uid=uid++;// a flag to avoid this being observed
	vm._isVue=true;vm.$Vue=Vue;// merge options
	if(options&&options._isComponent){// optimize internal component instantiation
	// since dynamic options merging is pretty slow, and none of the
	// internal component options needs special treatment.
	initInternalComponent(vm,options);}else{vm.$options=mergeOptions(resolveConstructorOptions(vm),options||{},vm);}/* istanbul ignore else */{initProxy(vm);}// expose real self
	vm._self=vm;initLifecycle(vm);initEvents(vm);callHook(vm,'beforeCreate');initState(vm);callHook(vm,'created');initRender(vm);};function initInternalComponent(vm,options){var opts=vm.$options=Object.create(resolveConstructorOptions(vm));// doing this because it's faster than dynamic enumeration.
	opts.parent=options.parent;opts.propsData=options.propsData;opts._parentVnode=options._parentVnode;opts._parentListeners=options._parentListeners;opts._renderChildren=options._renderChildren;opts._componentTag=options._componentTag;if(options.render){opts.render=options.render;opts.staticRenderFns=options.staticRenderFns;}}function resolveConstructorOptions(vm){var Ctor=vm.constructor;var options=Ctor.options;if(Ctor.super){var superOptions=Ctor.super.options;var cachedSuperOptions=Ctor.superOptions;if(superOptions!==cachedSuperOptions){// super option changed
	Ctor.superOptions=superOptions;options=Ctor.options=mergeOptions(superOptions,Ctor.extendOptions);if(options.name){options.components[options.name]=Ctor;}}}return options;}}function Vue$2(options){if("developement"!=='production'&&!(this instanceof Vue$2)){warn('Vue is a constructor and should be called with the `new` keyword');}this._init(options);}initMixin(Vue$2);stateMixin(Vue$2);eventsMixin(Vue$2);lifecycleMixin(Vue$2);renderMixin(Vue$2);var warn=noop;var formatComponentName;{var hasConsole=typeof console!=='undefined';warn=function warn(msg,vm){if(hasConsole&&!config.silent){console.error("[Vue warn]: "+msg+" "+(vm?formatLocation(formatComponentName(vm)):''));}};formatComponentName=function formatComponentName(vm){if(vm.$root===vm){return'root instance';}var name=vm._isVue?vm.$options.name||vm.$options._componentTag:vm.name;return(name?"component <"+name+">":"anonymous component")+(vm._isVue&&vm.$options.__file?" at "+vm.$options.__file:'');};var formatLocation=function formatLocation(str){if(str==='anonymous component'){str+=" - use the \"name\" option for better debugging messages.";}return"\n(found in "+str+")";};}/*  *//**
	 * Option overwriting strategies are functions that handle
	 * how to merge a parent option value and a child option
	 * value into the final value.
	 */var strats=config.optionMergeStrategies;/**
	 * Options with restrictions
	 */{strats.el=strats.propsData=function(parent,child,vm,key){if(!vm){warn("option \""+key+"\" can only be used during instance "+'creation with the `new` keyword.');}return defaultStrat(parent,child);};}/**
	 * Helper that recursively merges two data objects together.
	 */function mergeData(to,from){var key,toVal,fromVal;for(key in from){toVal=to[key];fromVal=from[key];if(!hasOwn(to,key)){set(to,key,fromVal);}else if(isObject(toVal)&&isObject(fromVal)){mergeData(toVal,fromVal);}}return to;}/**
	 * Data
	 */strats.data=function(parentVal,childVal,vm){if(!vm){// in a Vue.extend merge, both should be functions
	if(!childVal){return parentVal;}if(typeof childVal!=='function'){"developement"!=='production'&&warn('The "data" option should be a function '+'that returns a per-instance value in component '+'definitions.',vm);return parentVal;}if(!parentVal){return childVal;}// when parentVal & childVal are both present,
	// we need to return a function that returns the
	// merged result of both functions... no need to
	// check if parentVal is a function here because
	// it has to be a function to pass previous merges.
	return function mergedDataFn(){return mergeData(childVal.call(this),parentVal.call(this));};}else if(parentVal||childVal){return function mergedInstanceDataFn(){// instance merge
	var instanceData=typeof childVal==='function'?childVal.call(vm):childVal;var defaultData=typeof parentVal==='function'?parentVal.call(vm):undefined;if(instanceData){return mergeData(instanceData,defaultData);}else{return defaultData;}};}};/**
	 * Hooks and param attributes are merged as arrays.
	 */function mergeHook(parentVal,childVal){return childVal?parentVal?parentVal.concat(childVal):Array.isArray(childVal)?childVal:[childVal]:parentVal;}config._lifecycleHooks.forEach(function(hook){strats[hook]=mergeHook;});/**
	 * Assets
	 *
	 * When a vm is present (instance creation), we need to do
	 * a three-way merge between constructor options, instance
	 * options and parent options.
	 */function mergeAssets(parentVal,childVal){var res=Object.create(parentVal||null);return childVal?extend(res,childVal):res;}config._assetTypes.forEach(function(type){strats[type+'s']=mergeAssets;});/**
	 * Watchers.
	 *
	 * Watchers hashes should not overwrite one
	 * another, so we merge them as arrays.
	 */strats.watch=function(parentVal,childVal){/* istanbul ignore if */if(!childVal){return parentVal;}if(!parentVal){return childVal;}var ret={};extend(ret,parentVal);for(var key in childVal){var parent=ret[key];var child=childVal[key];if(parent&&!Array.isArray(parent)){parent=[parent];}ret[key]=parent?parent.concat(child):[child];}return ret;};/**
	 * Other object hashes.
	 */strats.props=strats.methods=strats.computed=function(parentVal,childVal){if(!childVal){return parentVal;}if(!parentVal){return childVal;}var ret=Object.create(null);extend(ret,parentVal);extend(ret,childVal);return ret;};/**
	 * Default strategy.
	 */var defaultStrat=function defaultStrat(parentVal,childVal){return childVal===undefined?parentVal:childVal;};/**
	 * Make sure component options get converted to actual
	 * constructors.
	 */function normalizeComponents(options){if(options.components){var components=options.components;var def;for(var key in components){var lower=key.toLowerCase();if(isBuiltInTag(lower)||config.isReservedTag(lower)){"developement"!=='production'&&warn('Do not use built-in or reserved HTML elements as component '+'id: '+key);continue;}def=components[key];if(isPlainObject(def)){components[key]=Vue$2.extend(def);}}}}/**
	 * Ensure all props option syntax are normalized into the
	 * Object-based format.
	 */function normalizeProps(options){var props=options.props;if(!props){return;}var res={};var i,val,name;if(Array.isArray(props)){i=props.length;while(i--){val=props[i];if(typeof val==='string'){name=camelize(val);res[name]={type:null};}else{warn('props must be strings when using array syntax.');}}}else if(isPlainObject(props)){for(var key in props){val=props[key];name=camelize(key);res[name]=isPlainObject(val)?val:{type:val};}}options.props=res;}/**
	 * Normalize raw function directives into object format.
	 */function normalizeDirectives(options){var dirs=options.directives;if(dirs){for(var key in dirs){var def=dirs[key];if(typeof def==='function'){dirs[key]={bind:def,update:def};}}}}/**
	 * Merge two option objects into a new one.
	 * Core utility used in both instantiation and inheritance.
	 */function mergeOptions(parent,child,vm){normalizeComponents(child);normalizeProps(child);normalizeDirectives(child);var extendsFrom=child.extends;if(extendsFrom){parent=typeof extendsFrom==='function'?mergeOptions(parent,extendsFrom.options,vm):mergeOptions(parent,extendsFrom,vm);}if(child.mixins){for(var i=0,l=child.mixins.length;i<l;i++){var mixin=child.mixins[i];if(mixin.prototype instanceof Vue$2){mixin=mixin.options;}parent=mergeOptions(parent,mixin,vm);}}var options={};var key;for(key in parent){mergeField(key);}for(key in child){if(!hasOwn(parent,key)){mergeField(key);}}function mergeField(key){var strat=strats[key]||defaultStrat;options[key]=strat(parent[key],child[key],vm,key);}return options;}/**
	 * Resolve an asset.
	 * This function is used because child instances need access
	 * to assets defined in its ancestor chain.
	 */function resolveAsset(options,type,id,warnMissing){/* istanbul ignore if */if(typeof id!=='string'){return;}var assets=options[type];var res=assets[id]||// camelCase ID
	assets[camelize(id)]||// Pascal Case ID
	assets[capitalize(camelize(id))];if("developement"!=='production'&&warnMissing&&!res){warn('Failed to resolve '+type.slice(0,-1)+': '+id,options);}return res;}/*  */function validateProp(key,propOptions,propsData,vm){var prop=propOptions[key];var absent=!hasOwn(propsData,key);var value=propsData[key];// handle boolean props
	if(isBooleanType(prop.type)){if(absent&&!hasOwn(prop,'default')){value=false;}else if(value===''||value===hyphenate(key)){value=true;}}// check default value
	if(value===undefined){value=getPropDefaultValue(vm,prop,key);// since the default value is a fresh copy,
	// make sure to observe it.
	var prevShouldConvert=observerState.shouldConvert;observerState.shouldConvert=true;observe(value);observerState.shouldConvert=prevShouldConvert;}{assertProp(prop,key,value,vm,absent);}return value;}/**
	 * Get the default value of a prop.
	 */function getPropDefaultValue(vm,prop,name){// no default, return undefined
	if(!hasOwn(prop,'default')){return undefined;}var def=prop.default;// warn against non-factory defaults for Object & Array
	if(isObject(def)){"developement"!=='production'&&warn('Invalid default value for prop "'+name+'": '+'Props with type Object/Array must use a factory function '+'to return the default value.',vm);}// call factory function for non-Function types
	return typeof def==='function'&&prop.type!==Function?def.call(vm):def;}/**
	 * Assert whether a prop is valid.
	 */function assertProp(prop,name,value,vm,absent){if(prop.required&&absent){warn('Missing required prop: "'+name+'"',vm);return;}if(value==null&&!prop.required){return;}var type=prop.type;var valid=!type||type===true;var expectedTypes=[];if(type){if(!Array.isArray(type)){type=[type];}for(var i=0;i<type.length&&!valid;i++){var assertedType=assertType(value,type[i]);expectedTypes.push(assertedType.expectedType);valid=assertedType.valid;}}if(!valid){warn('Invalid prop: type check failed for prop "'+name+'".'+' Expected '+expectedTypes.map(capitalize).join(', ')+', got '+Object.prototype.toString.call(value).slice(8,-1)+'.',vm);return;}var validator=prop.validator;if(validator){if(!validator(value)){warn('Invalid prop: custom validator check failed for prop "'+name+'".',vm);}}}/**
	 * Assert the type of a value
	 */function assertType(value,type){var valid;var expectedType=getType(type);if(expectedType==='String'){valid=(typeof value==='undefined'?'undefined':_typeof(value))===(expectedType='string');}else if(expectedType==='Number'){valid=(typeof value==='undefined'?'undefined':_typeof(value))===(expectedType='number');}else if(expectedType==='Boolean'){valid=(typeof value==='undefined'?'undefined':_typeof(value))===(expectedType='boolean');}else if(expectedType==='Function'){valid=(typeof value==='undefined'?'undefined':_typeof(value))===(expectedType='function');}else if(expectedType==='Object'){valid=isPlainObject(value);}else if(expectedType==='Array'){valid=Array.isArray(value);}else{valid=value instanceof type;}return{valid:valid,expectedType:expectedType};}/**
	 * Use function string name to check built-in types,
	 * because a simple equality check will fail when running
	 * across different vms / iframes.
	 */function getType(fn){var match=fn&&fn.toString().match(/^\s*function (\w+)/);return match&&match[1];}function isBooleanType(fn){if(!Array.isArray(fn)){return getType(fn)==='Boolean';}for(var i=0,len=fn.length;i<len;i++){if(getType(fn[i])==='Boolean'){return true;}}/* istanbul ignore next */return false;}// window width cache
	var winWidth=null;/**
	 * animate frame
	 * @param {function} 帧函数
	 * @return {int} 帧函数timer
	 */var rAF$$1=window.requestAnimationFrame||function(callback){window.setTimeout(callback,1000/60);};/**
	 * 停止 animate frame
	 * @param {int} 帧函数timer
	 */var stopRAF$$1=window.cancelAnimationFrame||window.clearTimeout;// 设计稿宽度，默认为750
	var designWidth=750;/**
	 * 设置设计稿宽度
	 * @param {int} dw 设计稿宽度，默认为750
	 */function setBaseDesignWidth$$1(dw){if(dw===void 0)dw=750;designWidth=dw;}/**
	 * 按照比例缩放尺寸，并且取整
	 * @param {int} value 原始尺寸
	 */function Ruler$$1(value){if(winWidth===null){winWidth=document.body.clientWidth;var ua=navigator.userAgent.toLowerCase();if(false){var ScreenWidthResolutionReg=/screenwidthresolution=(\d*)/;var ScreenDensityReg=/screendensity=([\d|\.]*)/;var ScreenWidthResolution=0;var ScreenDensity=1;var ScreenWidthResolutionMatch=ua.match(ScreenWidthResolutionReg);if(ScreenWidthResolutionMatch&&ScreenWidthResolutionMatch[1]&&!isNaN(ScreenWidthResolutionMatch[1])){ScreenWidthResolution=+ScreenWidthResolutionMatch[1];}var ScreenDensityMatch=ua.match(ScreenDensityReg);if(ScreenDensityMatch&&ScreenDensityMatch[1]&&!isNaN(ScreenDensityMatch[1])){ScreenDensity=+ScreenDensityMatch[1];}if(ScreenWidthResolution!==0){winWidth=Math.round(ScreenWidthResolution/ScreenDensity);}}}return Math.round(value*winWidth/designWidth);}/**
	 * 获取元素距离父亲的offsetTop
	 * @param {element} el 待计算的元素
	 * @param {element} parent el 相对的元素，可选，不传则指向上层body
	 * @return {int} offsetTop
	 */function offsetTop$$1(el,parentEl){if(!el){return null;}var curEl=el;var offsetTop$$1=0;var flag=false;var toBody=!parentEl;do{if(toBody){if(curEl.tag==='body'){flag=true;break;}}else{if(curEl===parentEl){flag=true;break;}}offsetTop$$1+=curEl.offsetTop;curEl=curEl.parentNode;}while(curEl);return flag?offsetTop$$1:null;}/**
	 * 获取元素距离父亲的offsetLeft
	 * @param {element} el 待计算的元素
	 * @param {element} parent el 相对的元素，可选，不传则指向上层body
	 * @return {int} offsetLeft
	 */function offsetLeft$$1(el,parentEl){if(!el){return null;}var curEl=el;var offsetLeft$$1=0;var flag=false;var toBody=!parentEl;do{if(toBody){if(curEl.tag==='body'){flag=true;break;}}else{if(curEl===parentEl){flag=true;break;}}offsetLeft$$1+=curEl.offsetLeft;curEl=curEl.parentNode;}while(curEl);return flag?offsetLeft$$1:null;}var bodyLazyInfos=null;function effectImageLazyerListener(el,src,placeholder){if(el.__lazyTimes===undefined){el.__lazyTimes=0;}// max 10 times
	if(el.__lazyTimes>=10){return;}var bodyNode=null;var parentNode=el.parentNode;while(parentNode){if(parentNode.tag==='body'){bodyNode=parentNode;break;}parentNode=parentNode.parentNode;}// 还没有在listview中
	if(!bodyNode){// push to nextTick
	nextTick(function(){el.__lazyTimes++;effectImageLazyerListener(el,src,placeholder);},this);return;}// 获取元素距离listview上方位置
	var elOffsetTop=offsetTop$$1(el);// listview 滚动事件监听
	if(!bodyLazyInfos){bodyLazyInfos={images:{},handle:function handle(){var scrollView=document.body;if(!bodyLazyInfos||isEmptyObject(bodyLazyInfos.images)){return;}var scrollClientTopPos=scrollView.scrollTop;var scrollClientHeight=scrollView.offsetHeight;var scrollClientBottomPos=scrollClientTopPos+scrollClientHeight;var images=bodyLazyInfos.images;for(var k in images){var image=images[k];if(scrollClientBottomPos+scrollClientHeight>=image.offsetTop&&scrollClientTopPos<=image.offsetBottom+scrollClientHeight){// 预加载一屏，多保留一屏
	// 可视区域
	if(!image.show){image.elm.setAttribute('src',image.src);image.show=true;}}else{// 非可视区域
	if(image.show){image.elm.setAttribute('src',image.placeholder);image.show=false;}}}}};window.addEventListener('scroll',throttle(bodyLazyInfos.handle,50,100));}bodyLazyInfos.images[el.createId]={elm:el,src:src,show:false,placeholder:placeholder,offsetTop:elOffsetTop,offsetBottom:elOffsetTop+el.offsetHeight};nextTick(function(){if(bodyLazyInfos&&bodyLazyInfos.handle){bodyLazyInfos.handle();}},this);}// get parent scrollview or listview
	function getParentScrollView(el){var bodyNode=null;var parentNode=el.parentNode;while(parentNode){if(parentNode.tag==='body'){bodyNode=parentNode;break;}parentNode=parentNode.parentNode;}return bodyNode||null;}// get lazyInfos
	function getImageLazyInfos(el,scroller){if(!bodyLazyInfos||!bodyLazyInfos.images){return null;}var infos=bodyLazyInfos.images[el.createId];return infos||null;}function removeImageLazyInfos(el){if(!bodyLazyInfos||!bodyLazyInfos.images){return null;}if(bodyLazyInfos.images[el.createId]){delete bodyLazyInfos.images[el.createId];}}// init image lazy
	function initImageInfo(el,src,placeholder){if(false){placeholder=placeholder||'http://s17.mogucdn.com/p1/160411/upload_ie4wmytcme3tay3eg4zdambqgqyde_1x1.gif';el.setAttribute('src',placeholder);effectImageLazyerListener(el,src,placeholder);el.__isLazyer=true;}}// set recently
	function updateInfos(el,src,placeholder){var scroller=getParentScrollView(el);if(!scroller){return;}var image=getImageLazyInfos(el,scroller);if(image){if(image.src!==src||image.placeholder!==placeholder){var elOffsetTop=offsetTop$$1(el);image.src=src;image.placeholder=placeholder;image.offsetTop=elOffsetTop;image.offsetBottom=elOffsetTop+el.offsetHeight;var scrollClientTopPos=scroller.scrollTop;var scrollClientHeight=scroller.offsetHeight;var scrollClientBottomPos=scrollClientTopPos+scrollClientHeight;if(scrollClientBottomPos+scrollClientHeight>=image.offsetTop&&scrollClientTopPos<=image.offsetBottom+scrollClientHeight){// 预加载一屏，多保留一屏
	// 可视区域
	image.elm.setAttribute('src',image.src);image.show=true;}else{// 非可视区域
	image.elm.setAttribute('src',image.placeholder);image.show=false;}}}}/**
	 * 注册image元素lazyload
	 */// export function imageLazyerRegister(el) {
	// }
	/**
	 * 取消注册image元素lazyload
	 */function imageLazyerUnRegister$$1(el){removeImageLazyInfos(el);}/**
	 * 为image元素设置lazyload
	 * @param {element} el 待设置的image元素
	 * @param {string} src 图片地址
	 * @param {string} placeholder placeholder图片地址
	 */function imageLazyer$$1(el,src,placeholder){if(el.__isLazyer){// update
	updateInfos(el,src,placeholder);}else{// init
	initImageInfo(el,src,placeholder);}}var util=Object.freeze({defineReactive:defineReactive$$1,isLowDevice:isLowDevice,_toString:_toString,toNumber:toNumber,makeMap:makeMap,isBuiltInTag:isBuiltInTag,remove:remove,hasOwn:hasOwn,isPrimitive:isPrimitive,cached:cached,camelize:camelize,capitalize:capitalize,hyphenate:hyphenate,bind:bind$1,toArray:toArray,extend:extend,isObject:isObject,isPlainObject:isPlainObject,toObject:toObject,isEmptyObject:isEmptyObject,throttle:throttle,noop:noop,no:no,genStaticKeys:genStaticKeys,looseEqual:looseEqual,looseIndexOf:looseIndexOf,objectAssign:objectAssign,isReserved:isReserved,def:def,parsePath:parsePath,updateQueryStringParameter:updateQueryStringParameter,hasProto:hasProto,inBrowser:inBrowser,UA:UA,isIE:isIE,isIE9:isIE9,isEdge:isEdge,isAndroid:isAndroid,isIOS:isIOS,devtools:devtools,nextTick:nextTick,get _Set(){return _Set;},mergeOptions:mergeOptions,resolveAsset:resolveAsset,get warn(){return warn;},get formatComponentName(){return formatComponentName;},validateProp:validateProp,rAF:rAF$$1,stopRAF:stopRAF$$1,setBaseDesignWidth:setBaseDesignWidth$$1,Ruler:Ruler$$1,offsetTop:offsetTop$$1,offsetLeft:offsetLeft$$1,imageLazyerUnRegister:imageLazyerUnRegister$$1,imageLazyer:imageLazyer$$1});/*  */function initUse(Vue){Vue.use=function(plugin){/* istanbul ignore if */if(plugin.installed){return;}// additional parameters
	var args=toArray(arguments,1);args.unshift(this);if(typeof plugin.install==='function'){plugin.install.apply(plugin,args);}else{plugin.apply(null,args);}plugin.installed=true;return this;};}/*  */function initMixin$1(Vue){Vue.mixin=function(mixin){Vue.options=mergeOptions(Vue.options,mixin);};}/*  */function initExtend(Vue){/**
	   * Each instance constructor, including Vue, has a unique
	   * cid. This enables us to create wrapped "child
	   * constructors" for prototypal inheritance and cache them.
	   */Vue.cid=0;var cid=1;/**
	   * Class inheritance
	   */Vue.extend=function(extendOptions){extendOptions=extendOptions||{};var Super=this;var isFirstExtend=Super.cid===0;if(isFirstExtend&&extendOptions._Ctor){return extendOptions._Ctor;}var name=extendOptions.name||Super.options.name;{if(!/^[a-zA-Z][\w-]*$/.test(name)){warn('Invalid component name: "'+name+'". Component names '+'can only contain alphanumeric characaters and the hyphen.');name=null;}}var Sub=function VueComponent(options){this._init(options);};Sub.prototype=Object.create(Super.prototype);Sub.prototype.constructor=Sub;Sub.cid=cid++;Sub.options=mergeOptions(Super.options,extendOptions);Sub['super']=Super;// allow further extension
	Sub.extend=Super.extend;// create asset registers, so extended classes
	// can have their private assets too.
	config._assetTypes.forEach(function(type){Sub[type]=Super[type];});// enable recursive self-lookup
	if(name){Sub.options.components[name]=Sub;}// keep a reference to the super options at extension time.
	// later at instantiation we can check if Super's options have
	// been updated.
	Sub.superOptions=Super.options;Sub.extendOptions=extendOptions;// cache constructor
	if(isFirstExtend){extendOptions._Ctor=Sub;}return Sub;};}/*  */function initAssetRegisters(Vue){/**
	   * Create asset registration methods.
	   */config._assetTypes.forEach(function(type){Vue[type]=function(id,definition){if(!definition){return this.options[type+'s'][id];}else{/* istanbul ignore if */{if(type==='component'&&config.isReservedTag(id)){warn('Do not use built-in or reserved HTML elements as component '+'id: '+id);}}if(type==='component'&&isPlainObject(definition)){definition.name=definition.name||id;definition=Vue.extend(definition);}if(type==='directive'&&typeof definition==='function'){definition={bind:definition,update:definition};}this.options[type+'s'][id]=definition;return definition;}};});}/*  */var reservedTags='body,view,label,image,listview,listview-shadow,scrollview';var reservedTagsMap=registerTag();var webTransferTag={// default div
	image:'img'};/**
	 * regist a tag
	 * @param  {string} tag tagName [option]
	 * @param  {string} styles support for tag, like 'width,height,...' [option]
	 * @param  {string} origin tag, default 'div' [option]
	 * @return {function} is reserved tag function
	 */function registerTag(tag,styles,originTag){if(typeof tag==='string'){var tags=reservedTags.split(',');if(tags.indexOf(tag)<0){tags.push(tag);reservedTags=tags.join(',');if(typeof styles==='string'){tagStyleSupport[tag]=makeMap(styles);}}}if(tag&&originTag){webTransferTag[tag]=originTag;}reservedTagsMap=makeMap(reservedTags);return reservedTagsMap;}var webTagMap=webTransferTag;function isReservedTag(){return reservedTagsMap.apply(this,arguments);}var tagStyleSupport={'view':makeMap('width,height,minWidth,maxWidth,minHeight,maxHeight,'+'marginLeft,marginTop,marginRight,marginBottom,'+'paddingLeft,paddingTop,paddingRight,paddingBottom,'+'left,top,right,bottom,borderWidth,borderColor,borderRadius,'+'position,display,backgroundColor,opacity,'+'flexDirection,flexWrap,justifyContent,alignItems,'+'alignSelf,flex,zIndex,'+'boxShadow'),'label':makeMap('width,height,minWidth,maxWidth,minHeight,maxHeight,'+'marginLeft,marginTop,marginRight,marginBottom,'+'left,top,right,bottom,borderWidth,borderColor,borderRadius,'+'position,display,backgroundColor,opacity,'+'color,fontSize,textAlign,fontWeight,whiteSpace,textOverflow,textDecoration,'+'alignSelf,flex,zIndex'),'listview':makeMap('width,height,minWidth,maxWidth,minHeight,maxHeight,'+'marginLeft,marginTop,marginRight,marginBottom,'+'left,top,right,bottom,borderWidth,borderColor,borderRadius,'+'position,display,backgroundColor,opacity,'+'alignSelf,flex,zIndex'),'listview-shadow':makeMap(''),'scrollview':makeMap('width,height,minWidth,maxWidth,minHeight,maxHeight,'+'marginLeft,marginTop,marginRight,marginBottom,'+'paddingLeft,paddingTop,paddingRight,paddingBottom,'+'left,top,right,bottom,borderWidth,borderColor,borderRadius,'+'position,display,backgroundColor,opacity,'+'flexDirection,flexWrap,justifyContent,alignItems,'+'alignSelf,flex,zIndex'),'image':makeMap('width,height,minWidth,maxWidth,minHeight,maxHeight,'+'marginLeft,marginTop,marginRight,marginBottom,'+'left,top,right,bottom,borderWidth,borderColor,borderRadius,'+'position,display,backgroundColor,opacity,'+'alignSelf,flex,objectFit,zIndex')};var isUnaryTag=makeMap('image',true);// Elements that you can, intentionally, leave open
	// (and which close themselves)
	var canBeLeftOpenTag=makeMap('',true);// HTML5 tags https://html.spec.whatwg.org/multipage/indices.html#elements-3
	// Phrasing Content https://html.spec.whatwg.org/multipage/dom.html#phrasing-content
	// export const isNonPhrasingTag = makeMap(
	//   'view',
	//   true
	// )
	function isUnknownElement(tag){// XCore中所有未注册和不在reservedTags里的标签都不允许使用，包括除此之外的HTML标签
	return!reservedTagsMap.apply(this,arguments);}var KeepAlive={name:'keep-alive',abstract:true,created:function created(){this.cache=Object.create(null);},render:function render(){var vnode=getFirstComponentChild(this.$slots.default);if(vnode&&vnode.componentOptions){var opts=vnode.componentOptions;var key=vnode.key==null// same constructor may get registered as different local components
	// so cid alone is not enough (#3269)
	?opts.Ctor.cid+'::'+opts.tag:vnode.key;if(this.cache[key]){vnode.child=this.cache[key].child;}else{this.cache[key]=vnode;}vnode.data.keepAlive=true;}return vnode;},destroyed:function destroyed(){var this$1=this;for(var key in this.cache){var vnode=this$1.cache[key];callHook(vnode.child,'deactivated');vnode.child.$destroy();}}};var builtInComponents={KeepAlive:KeepAlive};/*  */function initGlobalAPI(Vue){// config
	var configDef={};configDef.get=function(){return config;};{configDef.set=function(){warn('Do not replace the Vue.config object, set individual fields instead.');};}Object.defineProperty(Vue,'config',configDef);Vue.util=util;Vue.set=set;Vue.delete=del;Vue.nextTick=nextTick;Vue.registerTag=registerTag;Vue.options=Object.create(null);config._assetTypes.forEach(function(type){Vue.options[type+'s']=Object.create(null);});extend(Vue.options.components,builtInComponents);initUse(Vue);initMixin$1(Vue);initExtend(Vue);initAssetRegisters(Vue);}initGlobalAPI(Vue$2);Vue$2.version='1.0.5';/*  */// attributes that should be using props for binding
	var mustUseProp=makeMap('');var isEnumeratedAttr=makeMap('');var isBooleanAttr=makeMap('');var isXlink=function isXlink(name){return name.charAt(5)===':'&&name.slice(0,5)==='xlink';};var isFalsyAttrValue=function isFalsyAttrValue(val){return val==null||val===false;};/*  */function mergeClassData(child,parent){return{staticClass:concat(child.staticClass,parent.staticClass),class:child.class?[child.class,parent.class]:parent.class};}function genClassFromData(data){var dynamicClass=data.class;var staticClass=data.staticClass;if(staticClass||dynamicClass){return concat(staticClass,stringifyClass(dynamicClass));}/* istanbul ignore next */return'';}function concat(a,b){return a?b?a+' '+b:a:b||'';}function stringifyClass(value){var res='';if(!value){return res;}if(typeof value==='string'){return value;}if(Array.isArray(value)){var stringified;for(var i=0,l=value.length;i<l;i++){if(value[i]){if(stringified=stringifyClass(value[i])){res+=stringified+' ';}}}return res.slice(0,-1);}if(isObject(value)){for(var key in value){if(value[key]){res+=key+' ';}}return res.slice(0,-1);}/* istanbul ignore next */return res;}/*  *//**
	 * Query an element selector if it's not an element already.
	 */function query(el){if(typeof el==='string'){if(true){return document.createElement('view');}else{var selector=el;el=document.querySelector(el);if(!el){"developement"!=='production'&&warn('Cannot find element: '+selector);return document.createElement('div');}}}return el;}/*  */var hackWhileList=makeMap('display,wordBreak,overflowX,overflowY,WebkitOverflowScrolling,WebkitFlexDirection,'+'transform,transition,transitionProperty,transitionDuration');// number or 'auto'
	var ruleStyles=makeMap('width,height,minWidth,maxWidth,minHeight,maxHeight,'+'marginLeft,marginTop,marginRight,marginBottom,'+'paddingLeft,paddingTop,paddingRight,paddingBottom,'+'left,top,right,bottom,borderWidth,borderRadius,'+'fontSize');// string or enum
	var stringStyles=makeMap('borderColor,flexDirection,flexWrap,justifyContent,alignItems,alignSelf,'+'position,display,backgroundColor,'+'color,textAlign,fontWeight,whiteSpace,textOverflow,textDecoration,'+'objectFit,boxShadow');// number
	var numberStyles=makeMap('flex,opacity,zIndex');// web prefix style
	var webPrefixStyles=makeMap('flexDirection,flexWrap,justifyContent,alignItems,alignSelf,flex,boxOrient,'+'boxPack,boxAlign,boxFlex,boxLines,transform,transitionDuration');// web older style
	var webExtraStyles={flexDirection:[{hack:'boxOrient',values:{'row':'horizontal','column':'vertical'}}],justifyContent:[{hack:'boxPack',values:{'flex-start':'start','flex-end':'end','space-between':'justify','space-around':'justify'}}],alignItems:[{hack:'boxAlign',values:{'flex-start':'start','flex-end':'end'}}],flex:[{hack:'boxFlex',values:{}}],flexWrap:[{hack:'boxLines',values:{'wrap':'multiple','nowrap':'single'}}]};/**
	 * 获取设备像素，web只能为1
	 * @return {int} 设备1像素
	 */var DevicePixel= false?1:+(1/window.devicePixelRatio).toFixed(2);/**
	 * check is style support
	 */function checkSupport(name,tagName){var isSupport=isStyleSupport(name);var tagMsg='';if(typeof tagName==='string'&&tagStyleSupport[tagName]){tagMsg="in "+tagName+" ";isSupport=tagStyleSupport[tagName](name)||hackWhileList(name);}{if(!isSupport){warn('style '+name+' '+"is not support "+tagMsg+"now.");}}return!!isSupport;}/**
	 * replace style prop with finial effect prop
	 */function effectProp(name){if(false){return camelize('-webkit-'+hyphenate(name));}else{return name;}}/**
	 * append older style for web
	 */function extraProp(name,value){if(false){var hackStyle=webExtraStyles[name];var hackMap={};hackStyle.forEach(function(item){var k=camelize(item.hack);var v=item.values[value];if(value===''){hackMap[k]=v;}else if(v){hackMap[k]=v;}else{hackMap[k]=value;}});return hackMap;}else{return null;}}/**
	 * check is style name support
	 */function isStyleSupport(name){return!!(ruleStyles(name)||stringStyles(name)||numberStyles(name)||("native")==='web'&&hackWhileList(name));}/**
	 * set style
	 */function setStyle(elm,name,value){if(!name||!elm){return;}if(!checkSupport(name,elm.tag)){return;}// reset to default
	if(value===''){if(false){elm.style[effectProp(name)]=value;// css hack
	var hackMap=extraProp(name,value);if(hackMap){for(var k in hackMap){elm.style[effectProp(k)]=value;}}}else{var sobj={};sobj[effectProp(name)]=value;elm.setStyle(sobj);}return;}if(ruleStyles(name)){if(typeof value==='number'){value=Ruler$$1(value)+("native")==='web'?'px':0;}else if(value==='pixel'){value=DevicePixel;}else if(typeof value==='string'&&value.match(/^[-+]?[0-9]*\.?[0-9]+px$/)){value=parseFloat(value);}}if(false){if(ruleStyles(name)&&value!=='100%'){value+='px';}elm.style[effectProp(name)]=value;// css hack
	var hackMap$1=extraProp(name,value);if(hackMap$1){for(var k$1 in hackMap$1){elm.style[effectProp(k$1)]=hackMap$1[k$1];}}}else{if(value==='100%'){return;}var sobj$1={};sobj$1[effectProp(name)]=value;elm.setStyle(sobj$1);}}/**
	 * set styles
	 */function setStyles(elm,cssMap){if(!cssMap||isEmptyObject(cssMap)){return;}var effectCssMap={};for(var name in cssMap){var value=cssMap[name];if(!name){continue;}if(!checkSupport(name,elm.tag)){continue;}// reset to default
	if(value===''){if(false){elm.style[effectProp(name)]=value;// css hack
	var hackMap=extraProp(name,value);if(hackMap){for(var k in hackMap){elm.style[effectProp(k)]=value;}}}else{effectCssMap[effectProp(name)]=value;}continue;}if(ruleStyles(name)){if(typeof value==='number'){value=Ruler$$1(value);}else if(value==='pixel'){value=DevicePixel;}else if(typeof value==='string'&&value.match(/^[-+]?[0-9]*\.?[0-9]+px$/)){value=parseFloat(value);}}if(false){if(ruleStyles(name)&&value!=='100%'){value+='px';}elm.style[effectProp(name)]=value;// css hack
	var hackMap$1=extraProp(name,value);if(hackMap$1){for(var k$1 in hackMap$1){elm.style[effectProp(k$1)]=hackMap$1[k$1];}}}else{if(value==='100%'){continue;}effectCssMap[effectProp(name)]=value;}}if(("native")==='native'&&!isEmptyObject(effectCssMap)){elm.setStyle(effectCssMap);}}function elemExtra(elem,opt){if(opt==='createElement'){switch(elem.tag){case'body':if(true){setStyles(elem,{flex:1});}// 代理scroll方法
	elem.setScrollTop=function(val){var minTop=0;var maxTop=this.scrollHeight-this.offsetHeight;val=val<minTop?minTop:val;val=val>maxTop?maxTop:val;this.scrollTop=val;}.bind(elem);elem.setScrollLeft=function(val){var minLeft=0;var maxLeft=this.scrollWidth-this.offsetWidth;val=val<minLeft?minLeft:val;val=val>maxLeft?maxLeft:val;this.scrollLeft=val;}.bind(elem);break;case'scrollview':/**
	         * 设置垂直滚动
	         * @param {Number} val   目标值
	         */elem.setScrollTop=function(val){var minTop=0;var maxTop=this.scrollHeight-this.offsetHeight;val=val<minTop?minTop:val;val=val>maxTop?maxTop:val;if(elem.forceScrollAnimate&&("native")==='web'){stopRAF$$1(this._scrollTopTime);// scroll animate
	var s0=this.scrollTop;var s1=val;var totalTime=0.2;// 0.2s滑动到指定位置
	var fps=60;var times=Math.ceil(totalTime*fps);var v=(s1-s0)/times;var maxTimes=times;var run=function run(times){var this$1=this;if(times<=0){this.scrollTop=s1;return;}else{this.scrollTop=s0+v*(maxTimes-times);}this._scrollTopTime=rAF$$1(function(){run.call(this$1,--times);});};run.call(this,--times);}else{this.scrollTop=val;}}.bind(elem);/**
	         * 设置水平滚动
	         * @param {Number} val   目标值
	         */elem.setScrollLeft=function(val){var minLeft=0;var maxLeft=this.scrollWidth-this.offsetWidth;val=val<minLeft?minLeft:val;val=val>maxLeft?maxLeft:val;if(elem.forceScrollAnimate&&("native")==='web'){stopRAF$$1(this._scrollLeftTime);// scroll animate
	var s0=this.scrollLeft;var s1=val;var totalTime=0.2;// 0.2s滑动到指定位置
	var fps=60;var times=Math.ceil(totalTime*fps);var v=(s1-s0)/times;var maxTimes=times;var run=function run(times){var this$1=this;if(times<=0){this.scrollLeft=s1;return;}else{this.scrollLeft=s0+v*(maxTimes-times);}this._scrollLeftTime=rAF$$1(function(){run.call(this$1,--times);});};run.call(this,--times);}else{this.scrollLeft=val;}}.bind(elem);if(false){// 低版本设备
	if(isLowDevice()){setStyles(elem,{'transform':''// 取消加速
	});}elem.addEventListener('touchstart',function(){var posStart={x:this.scrollLeft,y:this.scrollTop};var scrolled=false;var fire=function fire(type,context){var event=document.createEvent('Events');event.initEvent(type,false,false);context.dispatchEvent(event);};var touchmoveHandle=function touchmoveHandle(){var posMove={x:this.scrollLeft,y:this.scrollTop};if((posMove.x!==posStart.x||posMove.y!==posStart.y)&&!scrolled){fire('scrollstart',this);scrolled=true;}};var touchendHandle=function touchendHandle(){if(scrolled){fire('scrollcancel',this);fire('scrollend',this);}this.removeEventListener('scroll',touchmoveHandle);this.removeEventListener('touchend',touchendHandle);};this.addEventListener('scroll',touchmoveHandle);this.addEventListener('touchend',touchendHandle);});}break;default:break;}}}/*  */function setText(elem,text){text=text?text.trim():'';if(false){elem.innerHTML=text;}else{elem.setText(text);}}var elementIdCount=1;function createElement$1(tagName){var elem;if(true){if(tagName==='body'){elem=document.createElement('listview');document.body.appendChild(elem);}else{elem=document.createElement(tagName);}}else{if(tagName==='body'){elem=document.body;}else{elem=document.createElement(webTagMap[tagName]||'div');}elem.setAttribute('tag',tagName);}elem.tag=tagName;elem.createId=tagName+elementIdCount++;elemExtra(elem,'createElement');return elem;}function createTextNode(text){return{text:text,nodeType:3};}function createComment(text){if(false){return document.createComment(text);}else{return document.createElement('view');}}function insertBefore(parentNode,newNode,referenceNode){if(newNode.nodeType===3){// 处理文本节点
	newNode.curParent=parentNode;newNode.__defineGetter__('parentNode',function(){return this.curParent;});if(parentNode.tag==='label'){setText(parentNode,newNode.text);newNode.__defineSetter__('textContent',function(text){if(this.curParent){setText(this.curParent,text);}});}}else{if(newNode.tag!=='body'){parentNode.insertBefore(newNode,referenceNode);}}elemExtra(newNode,'insertBefore');}function removeChild(node,child){if(!child){return;}// 空节点处理
	if(child.nodeType===3){// 处理文本节点
	if(node.tag==='label'){if(false){node.innerHTML='';}else{node.setText('');}child.curParent=undefined;}}else{if(node){node.removeChild(child);}}}function appendChild(node,child){if(!child){return;}// 空节点处理
	if(child.nodeType===3){// 处理文本节点
	child.curParent=node;child.__defineGetter__('parentNode',function(){return this.curParent;});if(node.tag==='label'){setText(node,child.text);child.__defineSetter__('textContent',function(text){if(this.curParent){setText(this.curParent,text);}});}}else{node.appendChild(child);}elemExtra(child,'appendChild');}function parentNode(node){return node.parentNode;}function nextSibling(node){return node.nextSibling;}function tagName(node){return node.tag||node.tagName;}function setTextContent(node,text){node.textContent=text;}function childNodes(node){return node.childNodes;}// export function setAttribute (node: Element, key: string, val: string) {
	//   node.setAttribute(key, val)
	// }
	function setAttributes(node,attrs){if(!attrs||isEmptyObject(attrs)){return;}var preAttrs={};for(var key in attrs){var value=attrs[key];if(isBooleanAttr(key)){// set attribute for blank value
	// e.g. <option disabled>Select one</option>
	if(isFalsyAttrValue(value)){if(false){node.removeAttribute(key);}else{preAttrs[key]=value;}}else{if(false){node.setAttribute(key,key);}else{preAttrs[key]=key;}}}else if(isEnumeratedAttr(key)){var v=isFalsyAttrValue(value)||value==='false'?'false':'true';if(false){node.setAttribute(key,v);}else{preAttrs[key]=v;}}else{if(isFalsyAttrValue(value)){if(false){node.removeAttribute(key);}else{preAttrs[key]=value;}}else{if(false){node.setAttribute(key,value);}else{preAttrs[key]=value;}}}}if(true){node.setAttribution(preAttrs);}}function removeAttributes(node,attrs){if(!attrs||isEmptyObject(attrs)){return;}var preAttrs={};for(var key in attrs){if(false){node.removeAttribute(key);}else{preAttrs[key]=null;}}if(true){node.setAttribution(preAttrs);}}var nodeOps=Object.freeze({createElement:createElement$1,createTextNode:createTextNode,createComment:createComment,insertBefore:insertBefore,removeChild:removeChild,appendChild:appendChild,parentNode:parentNode,nextSibling:nextSibling,tagName:tagName,setTextContent:setTextContent,childNodes:childNodes,setAttributes:setAttributes,removeAttributes:removeAttributes});/*  */var ref={create:function create(_,vnode){registerRef(vnode);},update:function update(oldVnode,vnode){if(oldVnode.data.ref!==vnode.data.ref){registerRef(oldVnode,true);registerRef(vnode);}},destroy:function destroy(vnode){registerRef(vnode,true);}};function registerRef(vnode,isRemoval){var key=vnode.data.ref;if(!key){return;}var vm=vnode.context;var ref=vnode.child||vnode.elm;var refs=vm.$refs;if(isRemoval){if(Array.isArray(refs[key])){remove(refs[key],ref);}else if(refs[key]===ref){refs[key]=undefined;}}else{if(vnode.data.refInFor){if(Array.isArray(refs[key])){refs[key].push(ref);}else{refs[key]=[ref];}}else{refs[key]=ref;}}}/**
	 * Virtual DOM patching algorithm based on Snabbdom by
	 * Simon Friis Vindum (@paldepind)
	 * Licensed under the MIT License
	 * https://github.com/paldepind/snabbdom/blob/master/LICENSE
	 *
	 * modified by Evan You (@yyx990803)
	 *

	/*
	 * Not type-checking this because this file is perf-critical and the cost
	 * of making flow understand it is not worth it.
	 */var emptyNode=new VNode('',{},[]);var hooks$1=['create','update','remove','destroy'];function isUndef(s){return s==null;}function isDef(s){return s!=null;}function sameVnode(vnode1,vnode2){function sameData(vnode1,vnode2){if(isEmptyObject(vnode1.data)&&isEmptyObject(vnode2.data)){return true;}return!vnode1.data===!vnode2.data;}return vnode1.key===vnode2.key&&vnode1.tag===vnode2.tag&&vnode1.isComment===vnode2.isComment&&sameData(vnode1,vnode2);}function createKeyToOldIdx(children,beginIdx,endIdx){var i,key;var map={};for(i=beginIdx;i<=endIdx;++i){key=children[i].key;if(isDef(key)){map[key]=i;}}return map;}function createPatchFunction(backend){var i,j;var cbs={};var modules=backend.modules;var nodeOps=backend.nodeOps;for(i=0;i<hooks$1.length;++i){cbs[hooks$1[i]]=[];for(j=0;j<modules.length;++j){if(modules[j][hooks$1[i]]!==undefined){cbs[hooks$1[i]].push(modules[j][hooks$1[i]]);}}}function emptyNodeAt(elm){return new VNode(nodeOps.tagName(elm).toLowerCase(),{},[],undefined,elm);}function createRmCb(childElm,listeners){function remove$$1(){if(--remove$$1.listeners===0){removeElement(childElm);}}remove$$1.listeners=listeners;return remove$$1;}function removeElement(el){var parent=nodeOps.parentNode(el);nodeOps.removeChild(parent,el);}function createElm(vnode,insertedVnodeQueue,nested){var i;var data=vnode.data=vnode.data||{};vnode.isRootInsert=!nested;if(isDef(data)){if(isDef(i=data.hook)&&isDef(i=i.init)){i(vnode);}// after calling the init hook, if the vnode is a child component
	// it should've created a child instance and mounted it. the child
	// component also has set the placeholder vnode's elm.
	// in that case we can just return the element and be done.
	if(isDef(i=vnode.child)){initComponent(vnode,insertedVnodeQueue);return vnode.elm;}}var children=vnode.children;var tag=vnode.tag;if(isDef(tag)){{if(!(config.ignoredElements&&config.ignoredElements.indexOf(tag)>-1)&&config.isUnknownElement(tag)){warn('Unknown custom element: <'+tag+'> - did you '+'register the component correctly? For recursive components, '+'make sure to provide the "name" option.',vnode.context);}}vnode.elm=vnode.elm=nodeOps.createElement(tag,vnode);setScope(vnode);createChildren(vnode,children,insertedVnodeQueue);if(isDef(data)){invokeCreateHooks(vnode,insertedVnodeQueue);}}else if(vnode.isComment){vnode.elm=nodeOps.createComment(vnode.text);}else{vnode.elm=nodeOps.createTextNode(vnode.text);}return vnode.elm;}function createChildren(vnode,children,insertedVnodeQueue){if(Array.isArray(children)){for(var i=0;i<children.length;++i){nodeOps.appendChild(vnode.elm,createElm(children[i],insertedVnodeQueue,true));}}else if(isPrimitive(vnode.text)){nodeOps.appendChild(vnode.elm,nodeOps.createTextNode(vnode.text));}}function isPatchable(vnode){while(vnode.child){vnode=vnode.child._vnode;}return isDef(vnode.tag);}function invokeCreateHooks(vnode,insertedVnodeQueue){for(var i$1=0;i$1<cbs.create.length;++i$1){cbs.create[i$1](emptyNode,vnode);}i=vnode.data.hook;// Reuse variable
	if(isDef(i)){if(i.create){i.create(emptyNode,vnode);}if(i.insert){insertedVnodeQueue.push(vnode);}}}function initComponent(vnode,insertedVnodeQueue){if(vnode.data.pendingInsert){insertedVnodeQueue.push.apply(insertedVnodeQueue,vnode.data.pendingInsert);}vnode.elm=vnode.child.$el;if(isPatchable(vnode)){invokeCreateHooks(vnode,insertedVnodeQueue);setScope(vnode);}else{// empty component root.
	// skip all element-related modules except for ref (#3455)
	registerRef(vnode);// make sure to invoke the insert hook
	insertedVnodeQueue.push(vnode);}}// set scope id attribute for scoped CSS.
	// this is implemented as a special case to avoid the overhead
	// of going through the normal attribute patching process.
	function setScope(vnode){var i;if(isDef(i=vnode.context)&&isDef(i=i.$options._scopeId)){nodeOps.setAttribute(vnode.elm,i,'');}if(isDef(i=activeInstance)&&i!==vnode.context&&isDef(i=i.$options._scopeId)){nodeOps.setAttribute(vnode.elm,i,'');}}function addVnodes(parentElm,before,vnodes,startIdx,endIdx,insertedVnodeQueue){for(;startIdx<=endIdx;++startIdx){nodeOps.insertBefore(parentElm,createElm(vnodes[startIdx],insertedVnodeQueue),before);}}function invokeDestroyHook(vnode){var i,j;var data=vnode.data;if(vnode.tag==='image'){imageLazyerUnRegister$$1(vnode.elm);}if(isDef(data)){if(isDef(i=data.hook)&&isDef(i=i.destroy)){i(vnode);}for(i=0;i<cbs.destroy.length;++i){cbs.destroy[i](vnode);}}if(isDef(i=vnode.children)){for(j=0;j<vnode.children.length;++j){invokeDestroyHook(vnode.children[j]);}}}function removeVnodes(parentElm,vnodes,startIdx,endIdx){for(;startIdx<=endIdx;++startIdx){var ch=vnodes[startIdx];if(isDef(ch)){if(isDef(ch.tag)){removeAndInvokeRemoveHook(ch);invokeDestroyHook(ch);}else{// Text node
	nodeOps.removeChild(parentElm,ch.elm);}}}}function removeAndInvokeRemoveHook(vnode,rm){if(rm||isDef(vnode.data)){var listeners=cbs.remove.length+1;if(!rm){// directly removing
	rm=createRmCb(vnode.elm,listeners);}else{// we have a recursively passed down rm callback
	// increase the listeners count
	rm.listeners+=listeners;}// recursively invoke hooks on child component root node
	if(isDef(i=vnode.child)&&isDef(i=i._vnode)&&isDef(i.data)){removeAndInvokeRemoveHook(i,rm);}for(i=0;i<cbs.remove.length;++i){cbs.remove[i](vnode,rm);}if(isDef(i=vnode.data.hook)&&isDef(i=i.remove)){i(vnode,rm);}else{rm();}}else{removeElement(vnode.elm);}}function updateChildren(parentElm,oldCh,newCh,insertedVnodeQueue,removeOnly){var oldStartIdx=0;var newStartIdx=0;var oldEndIdx=oldCh.length-1;var oldStartVnode=oldCh[0];var oldEndVnode=oldCh[oldEndIdx];var newEndIdx=newCh.length-1;var newStartVnode=newCh[0];var newEndVnode=newCh[newEndIdx];var oldKeyToIdx,idxInOld,elmToMove,before;// removeOnly is a special flag used only by <transition-group>
	// to ensure removed elements stay in correct relative positions
	// during leaving transitions
	var canMove=!removeOnly;while(oldStartIdx<=oldEndIdx&&newStartIdx<=newEndIdx){if(isUndef(oldStartVnode)){oldStartVnode=oldCh[++oldStartIdx];// Vnode has been moved left
	}else if(isUndef(oldEndVnode)){oldEndVnode=oldCh[--oldEndIdx];}else if(sameVnode(oldStartVnode,newStartVnode)){patchVnode(oldStartVnode,newStartVnode,insertedVnodeQueue);oldStartVnode=oldCh[++oldStartIdx];newStartVnode=newCh[++newStartIdx];}else if(sameVnode(oldEndVnode,newEndVnode)){patchVnode(oldEndVnode,newEndVnode,insertedVnodeQueue);oldEndVnode=oldCh[--oldEndIdx];newEndVnode=newCh[--newEndIdx];}else if(sameVnode(oldStartVnode,newEndVnode)){// Vnode moved right
	patchVnode(oldStartVnode,newEndVnode,insertedVnodeQueue);canMove&&nodeOps.insertBefore(parentElm,oldStartVnode.elm,nodeOps.nextSibling(oldEndVnode.elm));oldStartVnode=oldCh[++oldStartIdx];newEndVnode=newCh[--newEndIdx];}else if(sameVnode(oldEndVnode,newStartVnode)){// Vnode moved left
	patchVnode(oldEndVnode,newStartVnode,insertedVnodeQueue);canMove&&nodeOps.insertBefore(parentElm,oldEndVnode.elm,oldStartVnode.elm);oldEndVnode=oldCh[--oldEndIdx];newStartVnode=newCh[++newStartIdx];}else{if(isUndef(oldKeyToIdx)){oldKeyToIdx=createKeyToOldIdx(oldCh,oldStartIdx,oldEndIdx);}idxInOld=isDef(newStartVnode.key)?oldKeyToIdx[newStartVnode.key]:null;if(isUndef(idxInOld)){// New element
	nodeOps.insertBefore(parentElm,createElm(newStartVnode,insertedVnodeQueue),oldStartVnode.elm);newStartVnode=newCh[++newStartIdx];}else{elmToMove=oldCh[idxInOld];/* istanbul ignore if */if("developement"!=='production'&&!elmToMove){warn('It seems there are duplicate keys that is causing an update error. '+'Make sure each v-for item has a unique key.');}if(elmToMove.tag!==newStartVnode.tag){// same key but different element. treat as new element
	nodeOps.insertBefore(parentElm,createElm(newStartVnode,insertedVnodeQueue),oldStartVnode.elm);newStartVnode=newCh[++newStartIdx];}else{patchVnode(elmToMove,newStartVnode,insertedVnodeQueue);oldCh[idxInOld]=undefined;canMove&&nodeOps.insertBefore(parentElm,newStartVnode.elm,oldStartVnode.elm);newStartVnode=newCh[++newStartIdx];}}}}if(oldStartIdx>oldEndIdx){before=isUndef(newCh[newEndIdx+1])?null:newCh[newEndIdx+1].elm;addVnodes(parentElm,before,newCh,newStartIdx,newEndIdx,insertedVnodeQueue);}else if(newStartIdx>newEndIdx){removeVnodes(parentElm,oldCh,oldStartIdx,oldEndIdx);}}function patchVnode(oldVnode,vnode,insertedVnodeQueue,removeOnly){if(oldVnode===vnode){return;}// reuse element for static trees.
	// note we only do this if the vnode is cloned -
	// if the new node is not cloned it means the render functions have been
	// reset by the hot-reload-api and we need to do a proper re-render.
	if(vnode.isStatic&&oldVnode.isStatic&&vnode.key===oldVnode.key&&vnode.isCloned){vnode.elm=oldVnode.elm;return;}var i;var data=vnode.data;var hasData=isDef(data);if(hasData&&isDef(i=data.hook)&&isDef(i=i.prepatch)){i(oldVnode,vnode);}var elm=vnode.elm=oldVnode.elm;var oldCh=oldVnode.children;var ch=vnode.children;if(hasData&&isPatchable(vnode)){for(i=0;i<cbs.update.length;++i){cbs.update[i](oldVnode,vnode);}if(isDef(i=data.hook)&&isDef(i=i.update)){i(oldVnode,vnode);}}if(isUndef(vnode.text)){if(isDef(oldCh)&&isDef(ch)){if(oldCh!==ch){updateChildren(elm,oldCh,ch,insertedVnodeQueue,removeOnly);}}else if(isDef(ch)){if(isDef(oldVnode.text)){nodeOps.setTextContent(elm,'');}addVnodes(elm,null,ch,0,ch.length-1,insertedVnodeQueue);}else if(isDef(oldCh)){removeVnodes(elm,oldCh,0,oldCh.length-1);}else if(isDef(oldVnode.text)){nodeOps.setTextContent(elm,'');}}else if(oldVnode.text!==vnode.text){nodeOps.setTextContent(elm,vnode.text);}if(hasData){if(isDef(i=data.hook)&&isDef(i=i.postpatch)){i(oldVnode,vnode);}}}function invokeInsertHook(vnode,queue,initial){// delay insert hooks for component root nodes, invoke them after the
	// element is really inserted
	if(initial&&vnode.parent){vnode.parent.data.pendingInsert=queue;}else{for(var i=0;i<queue.length;++i){queue[i].data.hook.insert(queue[i]);}}}var bailed=false;function hydrate(elm,vnode,insertedVnodeQueue){{if(!assertNodeMatch(elm,vnode)){return false;}}vnode.elm=elm;var tag=vnode.tag;var data=vnode.data;var children=vnode.children;if(isDef(data)){if(isDef(i=data.hook)&&isDef(i=i.init)){i(vnode,true/* hydrating */);}if(isDef(i=vnode.child)){// child component. it should have hydrated its own tree.
	initComponent(vnode,insertedVnodeQueue);return true;}}if(isDef(tag)){if(isDef(children)){var childNodes=nodeOps.childNodes(elm);// empty element, allow client to pick up and populate children
	if(!childNodes.length){createChildren(vnode,children,insertedVnodeQueue);}else{var childrenMatch=true;if(childNodes.length!==children.length){childrenMatch=false;}else{for(var i$1=0;i$1<children.length;i$1++){if(!hydrate(childNodes[i$1],children[i$1],insertedVnodeQueue)){childrenMatch=false;break;}}}if(!childrenMatch){if("developement"!=='production'&&typeof console!=='undefined'&&!bailed){bailed=true;console.warn('Parent: ',elm);console.warn('Mismatching childNodes vs. VNodes: ',childNodes,children);}return false;}}}if(isDef(data)){invokeCreateHooks(vnode,insertedVnodeQueue);}}return true;}function assertNodeMatch(node,vnode){if(vnode.tag){return vnode.tag.indexOf('vue-component')===0||vnode.tag===nodeOps.tagName(node).toLowerCase();}else{return _toString(vnode.text)===node.data;}}return function patch(oldVnode,vnode,hydrating,removeOnly){if(!vnode){if(oldVnode){invokeDestroyHook(oldVnode);}return;}var elm,parent;var isInitialPatch=false;var insertedVnodeQueue=[];if(!oldVnode){// empty mount, create new root element
	isInitialPatch=true;createElm(vnode,insertedVnodeQueue);}else{var isRealElement=isDef(oldVnode.nodeType);if(!isRealElement&&sameVnode(oldVnode,vnode)){patchVnode(oldVnode,vnode,insertedVnodeQueue,removeOnly);}else{if(isRealElement){// mounting to a real element
	// check if this is server-rendered content and if we can perform
	// a successful hydration.
	// if (oldVnode.nodeType === 1 && oldVnode.hasAttribute('server-rendered')) {
	// oldVnode.removeAttribute('server-rendered')
	// hydrating = true
	// }
	if(hydrating){if(hydrate(oldVnode,vnode,insertedVnodeQueue)){invokeInsertHook(vnode,insertedVnodeQueue,true);return oldVnode;}else{warn('The client-side rendered virtual DOM tree is not matching '+'server-rendered content. This is likely caused by incorrect '+'HTML markup, for example nesting block-level elements inside '+'<p>, or missing <tbody>. Bailing hydration and performing '+'full client-side render.');}}// either not server-rendered, or hydration failed.
	// create an empty node and replace it
	oldVnode=emptyNodeAt(oldVnode);}elm=oldVnode.elm;parent=nodeOps.parentNode(elm);createElm(vnode,insertedVnodeQueue);// component root element replaced.
	// update parent placeholder node element.
	if(vnode.parent){vnode.parent.elm=vnode.elm;if(isPatchable(vnode)){for(var i=0;i<cbs.create.length;++i){cbs.create[i](emptyNode,vnode.parent);}}}if(parent!==null){nodeOps.insertBefore(parent,vnode.elm,nodeOps.nextSibling(elm));removeVnodes(parent,[oldVnode],0,0);}else if(isDef(oldVnode.tag)){invokeDestroyHook(oldVnode);}}}invokeInsertHook(vnode,insertedVnodeQueue,isInitialPatch);return vnode.elm;};}/*  */var directives={create:updateDirectives,update:updateDirectives,destroy:function unbindDirectives(vnode){updateDirectives(vnode,emptyNode);}};function updateDirectives(oldVnode,vnode){if(!oldVnode.data.directives&&!vnode.data.directives){return;}var isCreate=oldVnode===emptyNode;var oldDirs=normalizeDirectives$1(oldVnode.data.directives,oldVnode.context);var newDirs=normalizeDirectives$1(vnode.data.directives,vnode.context);var dirsWithInsert=[];var dirsWithPostpatch=[];var key,oldDir,dir;for(key in newDirs){oldDir=oldDirs[key];dir=newDirs[key];if(!oldDir){// new directive, bind
	callHook$1(dir,'bind',vnode,oldVnode);if(dir.def&&dir.def.inserted){dirsWithInsert.push(dir);}}else{// existing directive, update
	dir.oldValue=oldDir.value;callHook$1(dir,'update',vnode,oldVnode);if(dir.def&&dir.def.componentUpdated){dirsWithPostpatch.push(dir);}}}if(dirsWithInsert.length){var callInsert=function callInsert(){dirsWithInsert.forEach(function(dir){callHook$1(dir,'inserted',vnode,oldVnode);});};if(isCreate){mergeVNodeHook(vnode.data.hook||(vnode.data.hook={}),'insert',callInsert,'dir-insert');}else{callInsert();}}if(dirsWithPostpatch.length){mergeVNodeHook(vnode.data.hook||(vnode.data.hook={}),'postpatch',function(){dirsWithPostpatch.forEach(function(dir){callHook$1(dir,'componentUpdated',vnode,oldVnode);});},'dir-postpatch');}if(!isCreate){for(key in oldDirs){if(!newDirs[key]){// no longer present, unbind
	callHook$1(oldDirs[key],'unbind',oldVnode);}}}}var emptyModifiers=Object.create(null);function normalizeDirectives$1(dirs,vm){var res=Object.create(null);if(!dirs){return res;}var i,dir;for(i=0;i<dirs.length;i++){dir=dirs[i];if(!dir.modifiers){dir.modifiers=emptyModifiers;}res[getRawDirName(dir)]=dir;dir.def=resolveAsset(vm.$options,'directives',dir.name,true);}return res;}function getRawDirName(dir){return dir.rawName||dir.name+"."+Object.keys(dir.modifiers||{}).join('.');}function callHook$1(dir,hook,vnode,oldVnode){var fn=dir.def&&dir.def[hook];if(fn){fn(vnode.elm,dir,vnode,oldVnode);}}var baseModules=[ref,directives];/**
	 * 处理attr额外信息
	 * @param  {element} elm
	 * @param  {string} key k
	 * @param  {string} cur v
	 * @param  {VNode} vnode new vnode
	 * @param  {VNode} vnode old vnode
	 * @return {bool} is continue set attr
	 */function attrExtra(elm,key,cur,vnode,oldVnode){switch(elm.tag){case'image':if(false){var attrs=vnode.data.attrs;if(attrs['fixture']){return true;}// web image lazyload
	var lazyImage=attrs&&attrs['placeholder']?attrs['placeholder']:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=';imageLazyer$$1(elm,cur,lazyImage);return false;}else{return true;}case'scrollview':elm.forceScrollAnimate=key==='force-scroll-animate'&&cur+''==='true';return false;default:return true;}}/*  */function updateAttrs(oldVnode,vnode){{window.diffCount();}if(!oldVnode.data.attrs&&!vnode.data.attrs){return;}var key,cur,old;var elm=vnode.elm;var oldAttrs=oldVnode.data.attrs||{};var attrs=vnode.data.attrs||{};var preAttrs={};for(key in attrs){cur=attrs[key];old=oldAttrs[key];if(old!==cur){if(attrExtra(elm,key,cur,vnode,oldVnode)){preAttrs[key]=cur;}}}setAttributes(elm,preAttrs);var preRmAttrs={};for(key in oldAttrs){if(attrs[key]==null){if(!isEnumeratedAttr(key)){preRmAttrs[key]=null;}}}removeAttributes(elm,preRmAttrs);}var attrs={create:function create(_,vnode){var attrs=vnode.data.staticAttrs;if(attrs){var preAttrs={};for(var key in attrs){if(attrExtra(vnode.elm,key,attrs[key],vnode)){preAttrs[key]=attrs[key];}}setAttributes(vnode.elm,preAttrs);}updateAttrs(_,vnode);},update:updateAttrs};// skip type checking this file because we need to attach private properties
	// to elements
	function updateDOMListeners(oldVnode,vnode){if(!oldVnode.data.on&&!vnode.data.on){return;}var on=vnode.data.on||{};var oldOn=oldVnode.data.on||{};var add=vnode.elm._v_add||(vnode.elm._v_add=function(event,handler,capture){if(false){window.addEventListener('scroll',function(e){var customEvent=objectAssign({},e,{target:document.body});handler.apply(this,[customEvent]);},capture);}else{vnode.elm.addEventListener(event,handler,capture);}});var remove$$1=vnode.elm._v_remove||(vnode.elm._v_remove=function(event,handler){vnode.elm.removeEventListener(event,handler);});updateListeners(on,oldOn,add,remove$$1);}var events={create:updateDOMListeners,update:updateDOMListeners};/*  */function updateProps(oldVnode,vnode){{window.diffCount();}if(!oldVnode.data.props&&!vnode.data.props){return;}var key,cur;var elm=vnode.elm;var oldProps=oldVnode.data.props||{};var props=vnode.data.props||{};for(key in oldProps){if(props[key]==null){elm[key]=undefined;}}for(key in props){cur=props[key];if(key==='value'){// store value as _value as well since
	// non-string values will be stringified
	elm._value=cur;// avoid resetting cursor position when value is the same
	if(elm.value!=cur){// eslint-disable-line
	elm.value=cur;}}else{elm[key]=cur;}}}var props={create:updateProps,update:updateProps};/*  */// let testEl
	var normalize=cached(function(prop){prop=camelize(prop);if(checkSupport(prop)){return prop;}});// prop value to css map
	var styleValueToCssMap=function styleValueToCssMap(styleValue){var cssMap={};try{var cssRules=styleValue.split(';');cssRules.forEach(function(rule){var ruleMeans=rule.split(':');if(ruleMeans.length===2){var k=ruleMeans[0].trim();var v=ruleMeans[1].trim();cssMap[camelize(k)]=isNaN(v)?v:+v;}});}catch(e){{warn('style invalid, '+'please check if it spell error.');}}return cssMap;};function setStaticStyles(oldVnode,vnode){var style,name;var elm=vnode.elm;var vm$$data=vnode.context.$data;var styleSheet=vm$$data.style;// extend static class styles
	if(vnode.data.staticClass){var classNames=vnode.data.staticClass.split(' ');if(false){elm.setAttribute('_sclass',vnode.data.staticClass);}classNames.forEach(function(cls){if(cls===''){return;}if(styleSheet[cls]){style=extend(style||{},styleSheet[cls]);}});}// extend static style styles
	if(vnode.data.staticStyle){var cssMap=styleValueToCssMap(vnode.data.staticStyle);style=extend(style||{},cssMap);}var preStyles={};for(name in style){var norName=normalize(name);if(norName){preStyles[norName]=style[name];}}setStyles(elm,preStyles);// clone the style for future updates,
	// in case the user mutates the style object in-place.
	if(style){vnode.data.baseStyle=extend({},style);}}function createStyle(oldVnode,vnode){setStaticStyles(oldVnode,vnode);// to data binding style
	updateStyle(oldVnode,vnode);}function updateStyle(oldVnode,vnode){{window.diffCount();}if(vnode.data.staticClass!==oldVnode.data.staticClass||vnode.data.staticStyle!==oldVnode.data.staticStyle){setStaticStyles(oldVnode,vnode);}var cur,name;var elm=vnode.elm;var oldStyle=oldVnode.data.style;var baseStyle=oldVnode.data.baseStyle||vnode.data.baseStyle;var vm$$data=vnode.context.$data;// get default tag styles
	var style;var styleData=vm$$data.style;// extend class styles
	if(vnode.data.jstyles&&vnode.data.jstyles.class){if(false){elm.setAttribute('_class',vnode.data.jstyles.class);}var classNames=vnode.data.jstyles.class.split(' ');if(styleData){classNames.forEach(function(cls){if(cls===''){return;}if(styleData[cls]){style=extend(style||{},styleData[cls]);}});}}// extend style prop styles
	if(vnode.data.jstyles&&vnode.data.jstyles.style){var cssMap=styleValueToCssMap(vnode.data.jstyles.style);style=extend(style||{},cssMap);}var preStyles={};if(oldStyle){for(name in oldStyle){cur=style?style[name]:undefined;// new style wait to del
	if(cur===undefined){// check if in base static style
	cur=baseStyle&&baseStyle[name]?baseStyle[name]:'';var norName=normalize(name);if(norName){preStyles[norName]=cur;}}}}if(style){for(name in style){cur=style[name];if(!oldStyle||cur!==oldStyle[name]){var norName$1=normalize(name);if(norName$1){preStyles[norName$1]=cur;}}}}setStyles(elm,preStyles);// clone the style for future updates,
	// in case the user mutates the style object in-place.
	if(style){vnode.data.style=extend({},style);}if(baseStyle){vnode.data.baseStyle=extend({},baseStyle);}}var style={create:createStyle,update:updateStyle};{window.diffCount=function(){if(false){if(window.___diffcount===undefined){window.___diffcount=1;}else{clearTimeout(window.___diffcounttimer);window.___diffcount++;}window.___diffcounttimer=setTimeout(function(){console.log('diff count: '+window.___diffcount);window.___diffcount=0;},1000);}};}var platformModules=[attrs,events,props,style];/*  */// the directive module should be applied last, after all
	// built-in modules have been applied.
	var modules=platformModules.concat(baseModules);var patch$1=createPatchFunction({nodeOps:nodeOps,modules:modules});/**
	 * Not type checking this file because flow doesn't like attaching
	 * properties to Elements.
	 */var modelableTagRE=/^input|select|textarea|vue-component-[0-9]+(-[0-9a-zA-Z_\-]*)?$/;var model={inserted:function inserted(el,binding,vnode){{if(!modelableTagRE.test(vnode.tag)){warn("v-model is not supported on element type: <"+vnode.tag+">. "+'If you are working with contenteditable, it\'s recommended to '+'wrap a library dedicated for that purpose inside a custom component.',vnode.context);}}if(vnode.tag==='select'){var cb=function cb(){setSelected(el,binding,vnode.context);};cb();}else if((vnode.tag==='textarea'||el.type==='text')&&!binding.modifiers.lazy){if(!isAndroid){el.addEventListener('compositionstart',onCompositionStart);el.addEventListener('compositionend',onCompositionEnd);}}},componentUpdated:function componentUpdated(el,binding,vnode){if(vnode.tag==='select'){setSelected(el,binding,vnode.context);// in case the options rendered by v-for have changed,
	// it's possible that the value is out-of-sync with the rendered options.
	// detect such cases and filter out values that no longer has a matchig
	// option in the DOM.
	var needReset=el.multiple?binding.value.some(function(v){return hasNoMatchingOption(v,el.options);}):binding.value!==binding.oldValue&&hasNoMatchingOption(binding.value,el.options);if(needReset){trigger(el,'change');}}}};function setSelected(el,binding,vm){var value=binding.value;var isMultiple=el.multiple;if(isMultiple&&!Array.isArray(value)){"developement"!=='production'&&warn("<select multiple v-model=\""+binding.expression+"\"> "+"expects an Array value for its binding, but got "+Object.prototype.toString.call(value).slice(8,-1),vm);return;}var selected,option;for(var i=0,l=el.options.length;i<l;i++){option=el.options[i];if(isMultiple){selected=looseIndexOf(value,getValue(option))>-1;if(option.selected!==selected){option.selected=selected;}}else{if(looseEqual(getValue(option),value)){if(el.selectedIndex!==i){el.selectedIndex=i;}return;}}}if(!isMultiple){el.selectedIndex=-1;}}function hasNoMatchingOption(value,options){for(var i=0,l=options.length;i<l;i++){if(looseEqual(getValue(options[i]),value)){return false;}}return true;}function getValue(option){return'_value'in option?option._value:option.value;}function onCompositionStart(e){e.target.composing=true;}function onCompositionEnd(e){e.target.composing=false;trigger(e.target,'input');}function trigger(el,type){var e=document.createEvent('HTMLEvents');e.initEvent(type,true,true);el.dispatchEvent(e);}/*  */var show={bind:function bind(el,ref){var value=ref.value;setStyle(el,'display',value?'':'none');},update:function update(el,ref){var value=ref.value;setStyle(el,'display',value?'':'none');}};var platformDirectives={model:model,show:show};/*  */// install platform specific utils
	Vue$2.config.isUnknownElement=isUnknownElement;Vue$2.config.isReservedTag=isReservedTag;Vue$2.config.mustUseProp=mustUseProp;// install platform runtime directives
	extend(Vue$2.options.directives,platformDirectives);// install platform patch function
	Vue$2.prototype.__patch__=patch$1;// wrap mount
	Vue$2.prototype.$mount=function(el,hydrating){// start dom
	if(el==='#app'){el=document.createElement( true?'view':'div');}return this._mount(el&&query(el),hydrating);};// devtools global hook
	/* istanbul ignore next */setTimeout(function(){if(config.devtools){if(devtools){devtools.emit('init',Vue$2);}else if("developement"!=='production'&&inBrowser&&/Chrome\/\d+/.test(window.navigator.userAgent)){console.log('Download the Vue Devtools for a better development experience:\n'+'https://github.com/vuejs/vue-devtools');}}},0);module.exports=Vue$2;

/***/ },
/* 2 */
/*!************************************!*\
  !*** ./source/pages/hello/app.vue ***!
  \************************************/
/***/ function(module, exports, __webpack_require__) {

	var __vue_script__, __vue_template__, __module_exports__, __mod__
	__vue_script__ = __webpack_require__(/*! !babel-loader?presets[]=es2015&plugins[]=transform-runtime&comments=false!./../../../~/@mogu/xcore-loader/lib/selector.js?type=script&index=0!./app.vue */ 3)
	if (__vue_script__ &&
	    __vue_script__.__esModule &&
	    Object.keys(__vue_script__).length > 1) {
	  console.warn("[vue-loader] source/pages/hello/app.vue: named exports in *.vue files are ignored.")}
	__vue_template__ = __webpack_require__(/*! !@mogu/xcore-html-loader!./../../../~/@mogu/xcore-loader/lib/selector.js?type=template&index=0!./app.vue */ 7)
	module.exports = __vue_script__ || {}
	if (module.exports.__esModule) module.exports = module.exports.default
	if (__vue_template__) {
	  __module_exports__ = (typeof module.exports === "function"     ? (module.exports.options || (module.exports.options = {}))     : module.exports)
	  __module_exports__.render = __vue_template__.render
	  __module_exports__.staticRenderFns = __vue_template__.staticRenderFns
	}
	if (false) {(function () {  module.hot.accept()
	  var hotAPI = require("vue-hot-reload-api")
	  hotAPI.install(require("vue"), false)
	  if (!hotAPI.compatible) return
	  var id = "./app.vue"
	  if (!module.hot.data) {
	    hotAPI.createRecord(id, module.exports)
	  } else {
	    hotAPI.update(id, module.exports, __vue_template__)
	  }
	})()}

/***/ },
/* 3 */
/*!********************************************************************************************************************************************************************************!*\
  !*** ./~/babel-loader/lib?presets[]=es2015&plugins[]=transform-runtime&comments=false!./~/@mogu/xcore-loader/lib/selector.js?type=script&index=0!./source/pages/hello/app.vue ***!
  \********************************************************************************************************************************************************************************/
/***/ function(module, exports, __webpack_require__) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _index = __webpack_require__(/*! @mogu/share/index.xcore */ 4);

	var _index2 = _interopRequireDefault(_index);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = {
	  data: function data() {
	    return {
	      style: { "scroll": { "width": 250, "height": 100, "backgroundColor": "#555555", "flexWrap": "nowrap" }, "hi": { "flex": 1, "flexDirection": "column", "backgroundColor": "#ffff00", "width": 300 }, "label": { "width": 100, "color": "#ff0000", "alignSelf": "flex-start", "textOverflow": "ellipsis" } }
	    };
	  },
	  mounted: function mounted() {
	    _index2.default.init({
	      share: {
	        title: '【蘑菇街616】每日6场1元疯抢，每晚9点派百万张现金券！',
	        url: 'http://616.mogujie.com/branch/selection/h5?ismobile=1',
	        imageUrl: 'http://s16.mogucdn.com/p1/160603/upload_ifqtkmjqgiytey3fhazdambqgyyde_200x200.jpg',
	        content: '【蘑菇街616反，正是我】百款好货尽在良品，超值性价比，嗨购不息！'
	      },
	      showRightBtn: true
	    });
	  }
	};

/***/ },
/* 4 */
/*!**************************************!*\
  !*** ./~/@mogu/share/index.xcore.js ***!
  \**************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	var _hdp = __webpack_require__(/*! @mogu/hdp */ 5);

	var _hdp2 = _interopRequireDefault(_hdp);

	var _logger = __webpack_require__(/*! @mogu/logger/dist/logger.xcore */ 6);

	var _logger2 = _interopRequireDefault(_logger);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	// wraper xcore by buji
	if (false) {
	  var share;
	  var WX_CONFIG;
	  var WX_SDK;
	  var CHANNEL_MAP;
	  var EVENTID;
	  var isWxReady;
	  var wxSDK;
	  var configData;

	  (function () {

	    /**
	     * 初始化微信，微信接口验证
	     *
	     * @private
	     */
	    var wxInit = function wxInit() {
	      var config = {
	        debug: false,
	        appId: '',
	        timestamp: '',
	        nonceStr: '',
	        signature: '',
	        jsApiList: ['checkJsApi', 'onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareQZone', 'onMenuShareWeibo', 'hideMenuItems', 'showMenuItems', 'hideAllNonBaseMenuItem', 'showAllNonBaseMenuItem', 'chooseImage', 'previewImage', 'uploadImage', 'downloadImage', 'getNetworkType', 'hideOptionMenu', 'showOptionMenu', 'closeWindow', 'scanQRCode', 'chooseWXPay']
	      };

	      // 验证config信息
	      var url = WX_CONFIG + '?url=' + encodeURIComponent(location.href) + '&callback=_getWxConfig';

	      var script = document.createElement('script');
	      script.src = url;

	      var target = document.getElementsByTagName('script')[0] || document.head;
	      target.parentNode.insertBefore(script, target);

	      window._getWxConfig = function (data) {
	        if (data && data.status && data.status.code === 1001) {
	          data = data.result;
	          config.appId = data.appId;
	          config.nonceStr = data.nonceStr;
	          config.signature = data.signature;
	          config.timestamp = data.timestamp;
	          wxSDK.config(config);

	          if (script.parentNode) {
	            script.parentNode.removeChild(script);
	          }
	        }
	        window._getWxConfig = blank;
	      };

	      // config 信息验证后会执行ready代码
	      wxSDK.ready(function () {
	        isWxReady = true;
	        wxConfig();
	      });
	    };

	    /**
	     * 配置微信分享回调
	     *
	     * @private
	     */


	    var wxConfig = function wxConfig() {
	      if (!isWxReady) {
	        return;
	      }

	      var opts = {
	        title: configData.title,
	        desc: configData.content,
	        imgUrl: configData.imageUrl,
	        type: configData.type,
	        dataUrl: configData.dataUrl,
	        trigger: function trigger(res) {
	          // 用户点击分享时执行的回调函数
	          triggerHook(share.hook.weixin.click, res);
	        },
	        success: function success(res) {
	          // 用户确认分享后执行的回调函数
	          triggerHook(share.hook.weixin.success, res);
	          // 打点
	          console.log(res);

	          var shareType = res && res.errMsg && res.errMsg.split(":")[0];
	          var logObj = {
	            title: configData.title && configData.title.substring(0, 100),
	            content: configData.content && configData.content.substring(0, 100),
	            url: getWxShareUrl(shareType),
	            imageUrl: configData.imageUrl,
	            ua: navigator.userAgent
	          };
	          _logger2.default.log(EVENTID, logObj);
	        },
	        fail: function fail(res) {
	          // 分享失败时执行的回调函数
	          triggerHook(share.hook.weixin.fail, res);
	        },
	        cancel: function cancel(res) {
	          // 用户取消分享后执行的回调函数
	          triggerHook(share.hook.weixin.cancel, res);
	        },
	        complete: function complete(res) {
	          // 分享完成时执行的回调函数，无论成功或失败都会执行
	          triggerHook(share.hook.weixin.complete, res);
	        }
	      };

	      // 分享给朋友
	      wxSDK.onMenuShareAppMessage(extend({
	        link: getWxShareUrl('sendAppMessage')
	      }, opts));

	      // 分享到朋友圈
	      var timelineInfo = extend({
	        link: getWxShareUrl('shareTimeline')
	      }, opts);
	      wxSDK.onMenuShareTimeline(extend(timelineInfo, {
	        title: configData.content
	      }));

	      // 分享到QQ
	      wxSDK.onMenuShareQQ(extend({
	        link: getWxShareUrl('shareQQ')
	      }, opts));

	      // 分享到QQ空间
	      wxSDK.onMenuShareQZone(extend({
	        link: getWxShareUrl('shareQZone')
	      }, opts));
	    };

	    /**
	     * 当前容器是否是mogujie
	     *
	     * @private
	     */


	    var isMgj = function isMgj() {
	      var ua = navigator.userAgent.toLowerCase();
	      return ua.indexOf('mogujie') >= 0;
	    };

	    /**
	     * 当前容器是否是微信
	     *
	     * @private
	     */


	    var isWx = function isWx() {
	      var ua = navigator.userAgent.toLowerCase();
	      return ua.indexOf('micromessenger') >= 0;
	    };

	    /**
	     * 获取微信分享SDK
	     *
	     * @private
	     */


	    var getWxSDK = function getWxSDK(callback) {
	      loadScript(WX_SDK, function () {
	        wxSDK = window.wx;
	        callback && callback();
	      });
	    };

	    /**
	     * 生成微信分享url
	     *
	     * @private
	     */


	    var getWxShareUrl = function getWxShareUrl(channel) {
	      var query = getQuery(configData.url);

	      if (!query.f) {
	        query.f = CHANNEL_MAP[channel];
	        delete query.f2;
	      } else {
	        query.f2 = CHANNEL_MAP[channel];
	      }

	      var urlPrefix;

	      if (configData.url.indexOf('?') >= 0) {
	        urlPrefix = configData.url.slice(0, configData.url.indexOf('?'));
	      } else {
	        urlPrefix = configData.url;
	      }

	      return urlPrefix + '?' + stringifyQuery(query);
	    };

	    /**
	     * parse url字符串，返回参数对象
	     *
	     * @private
	     */


	    var getQuery = function getQuery(url, key) {
	      var qs = (location.search || '').slice(1);

	      var map = {};

	      qs.split('&').forEach(function (item) {
	        item = (item || '=').split('=');

	        map[item[0]] = item[1];
	      });

	      if (key) {
	        return map[key];
	      }

	      return map;
	    };

	    /**
	     * 将query对象序列化成queryString
	     *
	     * @private
	     */


	    var stringifyQuery = function stringifyQuery(data) {
	      data = data || {};

	      var str = '';

	      Object.keys(data).forEach(function (item) {
	        if (str) {
	          str += '&';
	        }

	        str += item + '=' + data[item];
	      });

	      return str;
	    };

	    /**
	     * 对象属性复制
	     *
	     * @private
	     */


	    var extend = function extend(target, source) {
	      target = target || {};
	      source = source || {};

	      Object.keys(source).forEach(function (item) {
	        target[item] = source[item];
	      });

	      return target;
	    };

	    /**
	     * 异步加载script文件
	     *
	     * @private
	     */


	    var loadScript = function loadScript(url, callback) {
	      var script = document.createElement('script');
	      script.src = url;

	      script.onload = function () {
	        callback && callback();
	      };

	      var target = document.getElementsByTagName('script')[0] || document.head;

	      target.parentNode.insertBefore(script, target);
	    };

	    /**
	     * 有jQuery活着zepto时触发回调
	     *
	     * @private
	     */


	    var triggerHook = function triggerHook(hook, param) {
	      if (window.$ && $(window).trigger) {
	        $(window).trigger(hook, param);
	      }
	    };

	    /**
	     * 空函数
	     *
	     * @private
	     */


	    var blank = function blank() {};

	    // web
	    share = {};

	    // 获取微信验证信息的接口

	    WX_CONFIG = 'http://www.mogujie.com/traffic/prom/auth/getjsonsign';

	    // 获取微信SDK的接口

	    WX_SDK = 'http://s10.mogucdn.com/__static/traffic_api/jweixin.js';

	    // 分享渠道代码映射

	    CHANNEL_MAP = {
	      'sendAppMessage': '1002',
	      'shareTimeline': '1004',
	      'shareQQ': '1001',
	      'shareQZone': '1003'
	    };

	    // 微信分享事件打点id

	    EVENTID = '700700';
	    isWxReady = false;
	    configData = {
	      // 分享标题
	      title: '',

	      // 分享文案（如果是分享到朋友圈则是标题）
	      content: '',

	      // 分享出去的访问链接
	      url: '',

	      // 分享出去的缩略图(160px * 160px)
	      imageUrl: '',

	      // 分享类型,music、video或link，不填默认为link
	      type: '',

	      // 如果type是music或video，则要提供数据链接，默认为空
	      dataUrl: ''
	    };

	    /**
	     * 初始化分享模块
	     *
	     * @public
	     */

	    share.init = function (data) {
	      configData = extend(configData, data.share);

	      if (!configData.title) {
	        configData.title = document.title;
	      }

	      if (!configData.url) {
	        configData.url = location.href;
	      }

	      if (!configData.imageUrl) {
	        if (document.getElementsByTagName('img')[0]) {
	          configData.imageUrl = document.getElementsByTagName('img')[0].src;
	        }
	      }

	      if (isWx()) {
	        if (window.wx) {
	          wxSDK = window.wx;
	          wxInit();
	        } else {
	          getWxSDK(function () {
	            wxInit();
	          });
	        }
	      }

	      if (data.showRightBtn) {
	        share.addRightBtn();
	      }
	    };

	    /**
	     * 修改分享数据
	     *
	     * @public
	     */
	    share.setData = function (data) {
	      configData = extend(configData, data);

	      wxConfig();
	    };

	    /**
	     * 调用蘑菇街的分享组件
	     *
	     * @public
	     */
	    share.moguShare = function (data) {
	      if (!isMgj()) {
	        return;
	      }

	      configData = extend(configData, data);

	      var data = {
	        title: configData.title,
	        content: configData.content,
	        url: configData.url,
	        imageUrl: configData.imageUrl
	      };

	      if (_hdp2.default.isApp('mogujie')) {
	        _hdp2.default.do('mgj.share.shareItem', data).then(function (res) {
	          triggerHook(share.hook.mogujie.click, res);
	        }).catch(function (res) {
	          triggerHook(share.hook.mogujie.fail, res);
	        });
	      }
	    };

	    /**
	     * 在蘑菇街容器右上角注册分享按钮
	     *
	     * @public
	     */
	    share.addRightBtn = function () {
	      if (_hdp2.default.isApp('mogujie')) {
	        _hdp2.default.do('mgj.navigation.rightitem.setTitle', '分享');
	        document.addEventListener('rightButton', share.moguShare);
	      }
	    };

	    /**
	     * 删除蘑菇街容器右上角的按钮
	     *
	     * @public
	     */
	    share.removeRightBtn = function () {
	      if (_hdp2.default.isApp('mogujie')) {
	        _hdp2.default.do('mgj.navigation.rightitem.setTitle', '');
	        document.removeEventListener('rightButton', share.moguShare);
	      }
	    };

	    /**
	     * 对外暴露的回调钩子
	     * 外部只需要监听以下对应方法（通过window.share.hook查看有哪些钩子）
	     * $(window).on(window._share.hook.weixin.click, function(res){
	     *     console.log(res);
	     * })
	     *
	     * @public
	     */
	    share.hook = {
	      // 微信
	      weixin: {
	        click: '__share_hook_weixin_click__',
	        success: '__share_hook_weixin_success__',
	        fail: '__share_hook_weixin_fail__',
	        cancel: '__share_hook_weixin_cancel__',
	        complete: '__share_hook_weixin_complete__'
	      },
	      // 蘑菇街app
	      mogujie: {
	        click: '__share_hook_mogujie_click__',
	        fail: '__share_hook_mogujie_fail__'
	      }
	    };

	    module.exports = share;
	  })();
	} else {
	  // xcore
	  module.exports = {
	    init: function init(shareInfo) {
	      if (shareInfo.showRightBtn) {
	        // 设置分享按钮
	        if (_hdp2.default.isApp('mogujie')) {
	          _hdp2.default.do('mgj.navigation.rightitem.setTitle', '分享');

	          document.addEventListener('rightButton', function () {
	            _hdp2.default.do('mgj.share.shareItem', shareInfo.share);
	          });
	        }
	      }
	    }
	  };
	}

/***/ },
/* 5 */
/*!******************************************!*\
  !*** ./~/@mogu/share/~/@mogu/hdp/hdp.js ***!
  \******************************************/
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;'use strict';

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	(function (global) {
		'use strict';

		if (!global.hdp) {
			global.hdp = {};
		}
		var hdp = global.hdp;
		hdp.version = '0.0.7';
		/**
	  * 部分接口向后兼容的逻辑，按cordovajs是否传入secret作为依据
	  * 此部分代码会随便容器接口升级而废弃
	  */
		//旧版本cordovajs无需传入回调的几个接口
		var whiteList = ['', 'setTitle', 'setIcon', 'pushWindow', 'popWindow', 'popToRoot', 'sendNotification', 'registerNotification', 'sendEvent', 'tips', 'setNavgationBackground', 'setStatusBarLight', 'postResult', ''].join('-');
		//兼容旧的参数构建方法
		var generateFallbackParams = function generateFallbackParams(pluginName, args, resolve, reject) {
			var name = pluginName.split('.');
			name = name[name.length - 1];
			if (whiteList.indexOf('-' + name + '-') > -1) {
				//白名单下,无需回调
				return args;
			}
			//个别兼容
			switch (pluginName) {
				//回调参数在后面的
				case 'mgj.sms.send':
				case 'mgj.device.signParams':
					args.push(function (data) {
						data = toBeJson(data);
						resolve(data);
					}, function (error) {
						reject(error);
					});
					break;
				//第一个参数是suc回调
				case 'mgj.location.pickLocationInfo':
				case 'mgj.app.isInstalled':
					args.unshift(function (data) {
						data = toBeJson(data);
						resolve(data);
					});
					break;
				//第二个参数是suc回调
				case 'navigator.notification.alert':
				case 'navigator.notification.confirm':
					args.splice(1, 0, function (data) {
						resolve(data);
					});
					break;
				//ajax兼容promise方式
				case 'mgj.ajax.ajax':
				case 'mgj.ajax.ajaxOrigin':
					var options = args[0];
					//补全callback,绑定promise
					if (!options.success) {
						options.success = function (data) {
							resolve(data);
						};
					} else {
						var suc = options.success;
						options.success = function (data) {
							suc.apply(null, arguments);
							resolve(data);
						};
					}
					if (!options.error) {
						options.error = function (error) {
							reject(error);
						};
					}
					break;
				default:
					//默认两个回调放前面
					args.unshift(function (data) {
						data = toBeJson(data);
						if (pluginName == 'mgj.user.getUserInfo' && data.result) {
							//android下user.getInfo接口多了一层
							resolve(data.result);
						} else if (pluginName == 'mgj.device.getInfo' && data.deviceId) {
							//ios下deviceInfo的ID不对
							data.deviceID = data.deviceId;
							resolve(data);
						} else {
							resolve(data);
						}
					}, function (error) {
						reject(error);
					});
			}
			return args;
		};
		//Promise构造器
		var MyPromise = global.Promise;
		var _Promise = function _Promise(fn) {
			//Promise状态
			this.state = 'pending';
			//resolve时的返回值，传给then中的success函数
			this.value = null;
			//reject时的返回值，传给then中的error函数
			this.reason = null;
			//当前Promise对应的一个classbacks,这里记录then中的success,error回调和连接下一个
			this.callback = {
				isDispatch: false
			};
			//调用业务函数，传入resolve和reject方法实现异步变更Promise状态
			if (typeof fn == 'function') {
				fn.call(null, this.resolve.bind(this), this.reject.bind(this));
			}
		};
		_Promise.prototype.resolve = function (value) {
			if (this.state != 'pending') {
				return;
			}
			this.state = 'fulfilled';
			this.value = value;
			//事件分发
			this._dispatch();
			return;
		};
		//将Promise状态变为rejected，传入原因（错误信息），并触发对应的回调函数
		_Promise.prototype.reject = function (reason) {
			if (this.state != 'pending') {
				return;
			}
			this.state = 'rejected';
			this.reason = reason;
			//事件分发
			this._dispatch();
			return;
		};
		//Promise主要接口，用于注册Promise状态改动后的回调函数
		//@params onFulfilled(value) 成功回调
		//@params onRejected(reson) 失败回调
		//@return Promise then操作后立即返回一个新的promise对象,实现Promise的链式操作
		_Promise.prototype.then = function (onFulfilled, onRejectd) {
			if (typeof onFulfilled == 'function') {
				this.callback.fulfill = onFulfilled;
			}
			if (typeof onRejectd == 'function') {
				this.callback.reject = onRejectd;
			}
			//如果当前Promsie处于结束状态，then操作后立即执行一次事件分开，让回调执行
			if (this.state != 'pending') {
				setTimeout(function () {
					this._dispatch();
				}.bind(this), 10);
			}
			//创建一个新的Promise，通过callback对象记录的下一个Promise引用
			this.callback.promise = new _Promise();
			//返回新的Promise
			return this.callback.promise;
		};
		//Promise主要接口，用于注册Promise失败后的回调函数
		_Promise.prototype.catch = function (onRejectd) {
			//@notice 这里同样要返回一个新的Promise对象
			return this.then(null, onRejectd);
		};

		//Promise内部事件分析，按照Promise状态调用callback
		//根据callback返回值，触发下一个Promise
		_Promise.prototype._dispatch = function () {
			if (this.state == 'pending') {
				return;
			}
			if (!this.callback.isDispatch) {
				//回调未触发
				var callback = this.callback;
				var nextPromise = callback.promise;
				var returnVal = null;
				try {
					switch (this.state) {
						case 'fulfilled':
							if (callback.fulfill) {
								//当前Promise有成功回调
								returnVal = callback.fulfill(this.value);
								callback.isDispatch = true;
							} else {
								//当前Promise无成功回调，触发Promise链中的下一个
								return nextPromise && nextPromise.resolve(this.value);
							}
							break;
						case 'rejected':
							if (callback.reject) {
								//当前Promise有失败回调
								returnVal = callback.reject(this.reason);
								callback.isDispatch = true;
							} else {
								//当前Promise无失败回调，触发Promise链中的下一个
								return nextPromise && nextPromise.reject(this.reason);
							}
							break;
					}
					//当前Promise的回调调用后，根据其返回值触发Promise链中的下一个
					if (returnVal == null) {
						//回调无返回，直接触发下一个Promise的fulfilled状态
						nextPromise.resolve(returnVal);
					} else if (returnVal instanceof _Promise || typeof returnVal.then === 'function') {
						returnVal.then(nextPromise.resolve.bind(nextPromise), nextPromise.reject.bind(nextPromise));
					} else {
						//回调返回的是其他数据，直接传给下一个Promise
						nextPromise.resolve(returnVal);
					}
				} catch (e) {
					//执行过程中如果出错，直接抛给下一个Promise
					nextPromise.reject(e);
				}
			}
		};

		MyPromise = _Promise;
		//修正接口问题,目前主要用于修复732\733下mwp无法使用的问题
		var _version = '';
		var _bugfix = function _bugfix(pluginName, args) {
			if (pluginName == 'mgj.ajax.mwp') {
				return new MyPromise(function (resolve, reject) {
					if (!_version) {
						hdp.do('mgj.device.getInfo').then(function (info) {
							_version = info.appVersion;
							_mwp(args, resolve, reject);
						});
					} else {
						_mwp(args, resolve, reject);
					}
				});
			}
		},
		    _mwp = function _mwp(args, resolve, reject) {
			if (_version == '732' || _version == '733') {
				reject(_rejectNotFount);
				return;
			}
			args.unshift(function (data) {
				resolve(data);
			}, function (error) {
				reject(error);
			});
			if (_secret) {
				//需要接入secret
				args.unshift(_secret);
			}
			if (mgj.ajax && mgj.ajax.mwp) {
				mgj.ajax.mwp.apply(null, args);
			} else {
				reject(_rejectNotFount);
			}
		};
		/**
	  * 核心接口封装逻辑
	  */
		var _ua = navigator.userAgent.toLowerCase();
		var _rejectMsg = '**hdp:环境不是容器';
		var _rejectNotFount = '**hdp:没有对应的接口:';
		var _secret = '';
		var _isReady = false;

		//获取Cordova注入的对象
		var getObj = function getObj(rootName) {
			return new MyPromise(function (resolve, reject) {
				if (_isReady) {
					if (window[rootName]) {
						resolve(window[rootName]);
					} else {
						//页面已经ready,但没有这个对象
						reject(_rejectNotFount);
					}
				} else {
					if (isApp()) {
						document.addEventListener('deviceready', function () {
							//页面没有deviceReady;
							_isReady = true;
							if (window[rootName]) {
								resolve(window[rootName]);
							} else {
								reject(_rejectNotFount);
							}
						}, false);
					} else {
						reject(_rejectMsg);
					}
				}
			});
		},
		    isApp = function isApp(_key) {
			if (!_key) {
				//mogujie主客，tt，uni, 番茄炒蛋，小店，淘世界, 美丽说
				var allUAKey = ['mogujie', 'tt', 'uni', 'go', 'xiaodian', 'ambuyer', 'amcustomer', 'meilishuo'];
				for (var i = 0, len = allUAKey.length; i < len; i++) {
					if (_ua.indexOf(allUAKey[i]) > -1) {
						return true;
					}
				}
				return false;
			} else {
				return _ua.indexOf(_key) > -1;
			}
		},


		//获取命名空间下指定的fn
		getFn = function getFn(obj, nameSpaceAry) {
			if (nameSpaceAry.length == 3) {
				//命中大部分接口，省去一个循环
				if (obj[nameSpaceAry[1]]) {
					return obj[nameSpaceAry[1]][nameSpaceAry[2]];
				}
				return;
			}
			var tempObj = obj;
			for (var i = 1, l = nameSpaceAry.length; i < l; i++) {
				tempObj = tempObj[nameSpaceAry[i]];
				if (!tempObj) {
					break;
				}
				if (i == l - 1) {
					//最后一个了
					return tempObj;
				}
			}
		},

		//兼容Android某些接口native返回string结构
		toBeJson = function toBeJson(data) {
			try {
				return data && typeof data == 'string' ? JSON.parse(data) : data;
			} catch (error) {
				return data;
			}
		},

		//插入校验secret和两个回调函数, fallback.js下有一个兼容版本，用于适配旧接口
		generateParams = function generateParams(pluginName, args, resolve, reject, isWrap) {
			var params = args.concat();
			var suc = function suc(data) {
				data = toBeJson(data);
				if (pluginName == 'mgj.user.getUserInfo' && data.result) {
					//android下user.getInfo接口多了一层
					resolve(data.result);
				} else if (pluginName == 'mgj.device.getInfo' && data.deviceId) {
					//ios下deviceInfo的ID不对
					data.deviceID = data.deviceId;
					resolve(data);
				} else {
					resolve(data);
				}
			},
			    err = function err(error) {
				reject(error);
			};
			if (pluginName == 'mgj.pevent' && !isWrap) {
				//733Android下兼容mgj.pevent未被封装的问题
				params.unshift(suc, err);
			} else if (pluginName == 'uni.resultnotification.postResult') {
				//uni下该插件接入时没有兼容，没有回调
				params.unshift(_secret);
			} else {
				params.unshift(_secret, suc, err);
			}
			return params;
		};

		//判定环境,是否处于蘑菇的apps中
		hdp.isApp = isApp;

		//暴露getObj接口给用户
		hdp.getObj = getObj;
		//设置 Bridge Secert, 用于接口校验
		hdp.setSecret = function (secret) {
			_secret = secret;
		};
		//ios下如果是wkWebview, cordova已经初始化
		if ((typeof cordova === 'undefined' ? 'undefined' : _typeof(cordova)) == 'object') {
			if (cordova.hdp_secret) {
				_secret = cordova.hdp_secret;
			}
		}
		//对外接口
		hdp.exec = function (pluginName) {
			if (!pluginName) {
				return;
			}
			//后面跟着的arguments
			var args = Array.prototype.slice.call(arguments, 1);
			var nameSpaceAry = pluginName.split('.');
			if (pluginName == 'mgj.ajax.mwp') {
				//修复接口
				return _bugfix(pluginName, args);
			}
			var func = null;
			return new MyPromise(function (resolve, reject) {
				getObj(nameSpaceAry[0]).then(function (obj) {
					func = getFn(obj, nameSpaceAry);
					if (!func) {
						//没有接口
						reject(_rejectNotFount + pluginName);
					}
					//734下cordovajs添加了封装函数的标识
					var isWrap = func.hdp_wrap_fn;
					if (!_secret) {
						//没有设置secret,旧的cordova.js版本，需要做参数兼容
						console.log('**hdp:未注入birdgeSecret');
						args = generateFallbackParams(pluginName, args, resolve, reject);
					} else {
						//构建参数
						args = generateParams(pluginName, args, resolve, reject, isWrap);
					}
					if (func) {
						//调用function
						func.apply(null, args);
					}
				}).catch(function (errmsg) {
					reject(errmsg);
				});
			});
		};

		hdp.do = hdp.exec;
		//兼容amd|cmd代码
		if (typeof module !== 'undefined' && ( false ? 'undefined' : _typeof(exports)) === 'object') {
			module.exports = hdp;
		} else if (true) {
			!(__WEBPACK_AMD_DEFINE_RESULT__ = function () {
				return hdp;
			}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		}
	})(window);

/***/ },
/* 6 */
/*!*********************************************!*\
  !*** ./~/@mogu/logger/dist/logger.xcore.js ***!
  \*********************************************/
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;'use strict';

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	(function (global) {
		'use strict';

		var logger = global.logger = {};

		logger.version = '0.1.9';

		//兼容ie不报错
		if (typeof console === 'undefined') {
			window.console = {
				log: function log() {}
			};
		}
		var ERRMSG = '**logger.js---打点出错:';
		(function () {
			var hasjQuery = window.jQuery || window.Zepto;
			var nodeIndex = function nodeIndex(nodes, node) {
				for (var i = 0, l = nodes.length; i < l; i++) {
					if (nodes[i] == node) {
						return i + 1;
					}
				}
				return -1;
			};
			var jq = {
				getA: function getA(node) {
					var _node = node;
					if (_node.tagName != 'A') {
						while (_node.parentNode) {
							_node = _node.parentNode;
							if (_node.tagName == 'A') {
								return _node;
							}
						}
					} else {
						return node;
					}
				},
				getParentByClass: function getParentByClass(node, cls) {
					if (!node) return;
					if (hasjQuery) {
						return $(node).parents('.' + cls);
					} else {
						var _node = node,
						    _hasClass;
						while (_node.parentNode) {
							_node = _node.parentNode;
							_hasClass = _node.className && _node.className.indexOf(cls) != -1;
							if (_hasClass) return _node;
						}
					}
				},
				getParents: function getParents(node, attr) {
					if (!node) return;
					attr = attr || '';
					if (hasjQuery) {
						attr = '[' + attr + ']';
						return $(node).parents(attr)[0];
					} else {
						var _node = node,
						    _attr;
						while (_node.parentNode) {
							_node = _node.parentNode;
							_attr = _node.getAttribute && _node.getAttribute(attr);
							if (_attr) return _node;
						}
						return;
					}
				},
				getIndex: function getIndex(selector, attr, node) {
					if (!selector || !attr || !node) return 0;
					if (hasjQuery) {
						return $('[' + selector + '="' + attr + '"]').index($(node)) + 1;
					} else {
						if (document.querySelectorAll) {
							var nodes = document.querySelectorAll('[' + selector + '="' + attr + '"]');
							return nodeIndex(nodes, node);
						} else {
							return 1;
						}
					}
				},
				getElemIndex: function getElemIndex(elem, selector, node) {
					if (!elem || !selector || !node) return 0;
					if (hasjQuery) {
						return $(elem).find(selector).index($(node)) + 1;
					} else {
						if (elem.querySelectorAll) {
							var nodes = elem.querySelectorAll(selector);
							return nodeIndex(nodes, node);
						} else {
							return 1;
						}
					}
				},
				is: function is(node, tagName) {
					if (!node || !tagName) return false;
					if (node.length) {
						node = node[0];
					}
					if (node.nodeName.toLowerCase() === tagName.toLowerCase()) {
						return true;
					}
				}
			};
			logger.jq = jq;
		})();
		//工具类
		//暴露对象：logger.util
		var CBID = 1001;
		var events = {};
		var util = {
			/**
	   * 对于非IE浏览器返回-1，对于IE浏览器返回版本号
	   */
			getIEVersion: function getIEVersion() {
				var rv = -1,
				    re;
				var ua = navigator.userAgent;
				if (navigator.appName == 'Microsoft Internet Explorer') {
					re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
					if (re.exec(ua) !== null) rv = parseFloat(RegExp.$1);
				} else if (navigator.appName == 'Netscape') {
					re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
					if (re.exec(ua) !== null) rv = parseFloat(RegExp.$1);
				}
				return rv;
			},
			stringify: function stringify(obj) {
				if (typeof JSON != 'undefined') {
					return JSON.stringify(obj);
				}
				var t = typeof obj === 'undefined' ? 'undefined' : _typeof(obj);
				if (t != "object" || obj === null) {
					// simple data type
					if (t == "string") obj = '"' + obj + '"';
					return String(obj);
				} else {
					// recurse array or object
					var n,
					    v,
					    json = [],
					    arr = obj && obj.constructor == Array;

					for (n in obj) {
						v = obj[n];
						t = typeof v === 'undefined' ? 'undefined' : _typeof(v);
						if (obj.hasOwnProperty(n)) {
							if (t == "string") v = '"' + v + '"';else if (t == "object" && v !== null) v = util.stringify(v);
							json.push((arr ? "" : '"' + n + '":') + String(v));
						}
					}
					return (arr ? "[" : "{") + String(json) + (arr ? "]" : "}");
				}
			},
			isArray: function isArray(value) {
				return Object.prototype.toString.call(value) == '[object Array]';
			},
			getCookieInArray: function getCookieInArray(array) {
				for (var i = 0, l = array.length; i < l; i++) {
					var value = util.getCookie(array[i]);
					if (value) {
						return value;
					}
				}
				return '';
			},
			getCookieOrFunc: function getCookieOrFunc(keyOrFunc) {
				if (typeof keyOrFunc == 'function') {
					return util.getValue(keyOrFunc);
				} else {
					return util.getCookie(keyOrFunc);
				}
			},
			getCookie: function getCookie(c_name) {
				if (util.isArray(c_name)) {
					return util.getCookieInArray(c_name);
				}
				var arr = document.cookie.match(new RegExp("(^| )" + c_name + "=([^;]*)(;|$)"));
				if (arr !== null) return decodeURIComponent(arr[2]);
				return '';
			},
			getQuery: function getQuery(name, url) {
				if (url === undefined) {
					url = location.search;
				}
				url = url.split('#')[0];
				var str = "(^|&|" + "\\?" + ")" + name + "=([^&]*)(&|$)";
				var reg = new RegExp(str, 'i');
				var r = url.substr(1).match(reg);
				if (r !== null) {
					return decodeURIComponent(r[2]);
				}
				return '';
			},
			setQuery: function setQuery(uri, key, value) {
				var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
				var separator = uri.indexOf('?') !== -1 ? "&" : "?";
				if (uri.match(re)) {
					return uri.replace(re, '$1' + key + "=" + value + '$2');
				} else {
					return uri + separator + key + "=" + value;
				}
			},
			getTime: function getTime() {
				return parseInt(new Date().getTime() / 1000);
			},
			registerEvent: function registerEvent(elem, event, func) {
				if (window.attachEvent) {
					elem.attachEvent('on' + event, func);
				} else {
					elem.addEventListener(event, func, false);
				}
			},
			extend: function extend() {
				var args = arguments;
				var target = arguments[0];

				for (var i = 1; i < args.length; i++) {
					var source = args[i];
					for (var p in source) {
						if (source.hasOwnProperty(p)) {
							target[p] = source[p];
						}
					}
				}
				return target;
			},
			getValue: function getValue(valueOrFunc) {
				if (!valueOrFunc) return;
				if (typeof valueOrFunc == 'function') {
					try {
						//后面跟着的arguments
						var args = Array.prototype.slice.call(arguments, 1);
						return valueOrFunc.apply(null, args);
					} catch (err) {
						//调用配置文件的函数时作一个保护
						console.log(ERRMSG + err);
						return '';
					}
				}
				return valueOrFunc;
			},
			/**
	   * 异步加载script文件
	   *
	   * @private
	   */
			loadScript: function loadScript(url, callback) {
				window['callback_' + CBID] = function (result) {
					if (callback) {
						callback(result);
					}
				};
				url += '?callback=callback_' + CBID;
				CBID += 1;

				if (navigator.userAgent.toLowerCase().indexOf('xcore') > -1) {
					if (window.loader) {
						window.loader.script(url);
					}
				} else {
					var script = document.createElement('script');
					script.src = url;

					var target = document.getElementsByTagName('head')[0];
					target.appendChild(script);
				}
			},
			listenTo: function listenTo(name, func) {
				if (!events[name]) {
					events[name] = [];
				}
				events[name].push(func);
			},
			fire: function fire(name) {
				var aryFns = events[name];
				if (!aryFns) return;
				if (aryFns.length) {
					for (var i = 0, l = aryFns.length; i < l; i++) {
						aryFns[i].call();
					}
					events[name] = [];
				}
			}
		};
		logger.util = util;
		// 配置文件
		// 暴露对象：logger.config
		var protocol = location.protocol === 'https:' ? 'https:' : 'http:';
		var cookieHost = 'mogujie';
		var host = location.host || location.domain || document.domain;
		if (host.indexOf('meilishuo') != -1) {
			cookieHost = 'meilishuo';
		}
		logger.config = {
			//开启mogu.js打点, 正常情况下只向log.php打点，但要兼容之前的数据，所以暂时要打点到mogu.js
			EnableLogMoGuJs: true,

			//打点地址
			LogUrl: protocol + '//log.juangua.com/log.php',
			LogMoGuJsUrl: protocol + '//log.juangua.com/mogu.js',

			//cookie请求地址，暂时只支持mogujie\meilishuo的
			CookieUrl: protocol + '//portal.' + cookieHost + '.com/api/util/getUuid',

			//是否需要请求cookie
			shouldRequestCookie: function shouldRequestCookie() {
				if (location.protocol.indexOf('file:') != -1) {
					//离线化后不种cookie
					return false;
				}
				var uuid = logger.util.getCookieOrFunc(logger.config.uuid);
				if (!uuid) {
					//没有uuid
					return true;
				}
				return false;
			},

			/*
	   * cookie中获取uuid、uid、sfrom的key，由业务方配置
	   * 当值为数组时，按顺序尝试获取，返回第一个成功获取的值
	   */
			uuid: ['__mgjuuid', '__xduuid'],
			uid: '__ud_',
			sfrom: 'from_site',
			cpsinfo: '__cpsinfo',

			//指定ptp_cnt的a字段的生成逻辑(value/function)
			ptp_cnt_a: '',

			//指定ptp_cnt的b字段的生成逻辑(value/function)
			ptp_cnt_b: '',

			//指定ptp_cnt某个元素的c、d字段生成逻辑(value/function)
			ptp_cnt_c_d: '',

			//指定页面的平台字段，区分PC和H5，可由业务方继续细分
			platform: function platform() {
				var _ua = navigator.userAgent.toLowerCase();
				if (/qq\/([\d\.]+)/.test(_ua)) {
					//蘑菇街页面在手Q下平台字段为48
					return 48;
				}
			},

			//指定p事件的eventId， 注意在native插件打点下，由插件决定eventId
			pEventId: '1001',

			//判断是否为移动端的正则主要做ios以及安卓判断
			isMobileRe: /iphone|android|ipad/i,

			//ptp验证
			ptpRe: /[a-z0-9]+\.[a-z0-9]+\.[a-z0-9]+\.[a-z0-9]+\.[a-z0-9]+/i,

			/**
	   * url匹配,匹配成功的url跳转才会添加ptp信息, 由业务方配置
	   * 如果hrefRe、mgjRe都匹配不了,则不添加ptp信息
	   */
			hrefRe: /http[s]?:\/\/\w+\.(mogujie|xiaodian|uniny)\.com([\/]|\/.*|)$/,
			mgjRe: /mgj:\/\//,

			//判断是否存在mt参数
			mtRe: /\?.*[&]?mt=([^\.]+)\.([^\.]+)\.([^\.&#]+)/,

			//追踪url指定参数，在a标签跳转前添加参数，通过接口生成带ptp信息的url时，也会带上
			//支持数组，追踪多个参数
			chasing: ['f', 'f2', 'mlf'],

			//跳转链接时附带扩展参数，可由业务方配置，支持数组，扩展多个参数
			//当指定了'acm'时，A标签元素拼接PTP参数的同时，会找到当前元素的data-ext-acm属性的值，并以"&acm=value"的形式拼接到url里
			//如果当前元素没有data-ext-acm，则不会拼接相关参数
			//@note: 属性名“data-ext-”头是为了防止与其他业务命名冲突而添加的
			//@note: 请注意IE低版本号url长度的限制
			urlExtend: ['acm'],

			/**
	   * 页面的P事件可以指定更多的自定义信息
	   * 以key-value的形式，由业务方自定义
	   * 注意：不能与正常的ptp打点信息冲突，否则会覆盖掉
	   */
			extra: {
				// key1: function(){
				//     return 'value1';
				// },
				// key2: function(){
				//     return 'value2';
				// }
			},

			//判断是否为native, 如果在native下，会调用native.logE、native.logP来打E\P事件
			isNativeRe: /(mogujie|xcore)/i,
			/**
	   * 调用native插件打点，由于不同的客户端的打点插件不一样，所以提供接口扩展，由业务方指定native打点代码
	   * 需要与上面的‘isNativeRe’参数配合使用
	   * 如果没有指定，会默认调用native.mgj.tracer.sendEvent和mgj.pevnet来进来打点（mogujie主客)
	   */
			nativeLog: {
				//调用native插件发送E事件请求
				// logE: function(eventid, json){

				// },
				//调用native插件发送P事件请求
				// logP: function(ptp_cnt){

				// }
			}
		};

		//从PTP_PARAMS获取自定义逻辑
		if (window.PTP_PARAMS) {
			util.extend(logger.config, PTP_PARAMS);
		}
		//此文件提供日志项目hash工作

		function Hash() {
			this.arr = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
			this.arrLen = this.arr.length;
		}

		Hash.prototype = {
			rand: function rand(a) {
				var c,
				    b = "";
				for (c = 0; a > c; c++) {
					b += this.arr.charAt(Math.random() * this.arrLen);
				}return b;
			},
			pageHash: function pageHash(input) {
				var hash = 5381;
				var i = input.length - 1;

				if (typeof input == 'string') {
					for (; i > -1; i--) {
						hash += (hash << 5) + input.charCodeAt(i);
					}
				} else {
					for (; i > -1; i--) {
						hash += (hash << 5) + input[i];
					}
				}
				var value = hash & 0x7FFFFFFF;

				var retValue = '';
				do {
					retValue += this.arr.charAt(value & 0x3D);
				} while (value >>= 6);

				return retValue;
			}
		};
		// deviceInfo.js获取设备相关信息
		// 暴露对象：logger.info，
		;(function () {
			var config = logger.config,
			    ua = navigator.userAgent.toLocaleLowerCase();

			//暴露对象
			logger.info = {
				isApp: config.isNativeRe.test(ua),
				isNative: config.isNativeRe.test(ua),
				isMobile: config.isMobileRe.test(ua),
				isIos: ua.indexOf('iphone') > -1,
				isAndroid: ua.indexOf('android') > -1,
				isXd: location.href.indexOf('.xiaodian.') > -1
			};
		})()
		/**
	  * 修正android客户端refer错误的问题, 兼容蘑菇街、美丽说
	  */
		;(function () {
			logger.needReferFix = false;
			var ua = navigator.userAgent.toLocaleLowerCase();
			var isAndroidApp = logger.info.isApp && logger.info.isAndroid;
			var isMelishuo = ua.indexOf('meilishuo') != -1;
			var isMogujie = ua.indexOf('mogujie') != -1;
			var hasNotfix = ua.indexOf('referfix=1') != -1;

			var mgjLink = ['^http://(m|www).mogujie.com/x6/wall/book/([a-z]+)/?(\\S*)$', '^http://(m|www).mogujie.com/x6/marketchannel\\?(\\S*)$', '^http://(m|www).mogujie.com/x6/detail/(\\w*)[\\?]?(\\S*)$', '^http://(m|www).mogujie.com/x6/shop/(.*?)/goodsall[\\?]?(\\S*)$', '^http://(m|www).mogujie.com/x6/account/getprofile[\\?].*?uid=(\\w*).*?$', '^http://(m|www).mogujie.com/x6/attention/lifestyle[\\?].*?id=(\\w*).*?((ptp|url_ptp)=([\\w.]+))?$', '^http://(m|www).mogujie.com/x6/shop/(\\w+)/?(\\?(.*))?$', '^http://(m|www).mogujie.com/x6/book/([a-z]+)/?(\\S*)$', '^http://(m|www).mogujie.com/x6/search/?\\?keywords=([^&]+)(\\S*)$'];

			var mlsLink = ["^https?:\/\/sgitem.meilishuo.com\/sgdetail\/(\\w+)\/?\\??(.*?)$", "^https?:\/\/item.meilishuo.com\/h5\/detail\/(\\w+)\/?\\??(.*?)$", "^https?:\/\/www.mogujie.com\/trade\/order\/detail4buyer\\?.*?orderId=(\\w+).*?$", "^https?:\/\/www.mogujie.com\/trade\/refund\/detail\\?.*?itemOrderId=(\\w+).*?$", "^(http|https):\/\/sgitemapp.meilishuo.com\/sgdetail\/(\\w+).*?$", "^https?:\/\/act.meilishuo.com\/keyword\/?\\??(.*?)?$", "^https?:\/\/weixin.meilishuo.com\/wx\/shop\/(\\w+)\/?\\??(.*?)$"];
			function matchNativeLink(ary, url) {
				var re;
				for (var i = 0; i < ary.length; i++) {
					re = new RegExp(ary[i]);
					if (re.test(url)) {
						return true;
					}
				}
				return false;
			}
			logger.matchNativeLink = matchNativeLink;
			var isMlsNativeLink = function isMlsNativeLink(url) {
				if (url.indexOf('mls://') != -1) {
					return true;
				}
				return matchNativeLink(mlsLink, url);
			};

			var isMgjNativeLink = function isMgjNativeLink(url) {
				if (url.indexOf('mgj://') != -1) {
					return true;
				}
				//过滤一大部分url
				if (url.indexOf('/x6/') == -1) {
					return false;
				}
				return matchNativeLink(mgjLink, url);
			};
			logger.isMgjNativeLink = isMgjNativeLink;
			var checkReferFix = function checkReferFix() {
				var _ver = '';
				if (isAndroidApp) {
					if (hasNotfix) return true;
					var re = ua.match(/\/(\d{3})\//);
					if (re && re[1]) {
						_ver = parseInt(re[1]);
						if (isMelishuo && _ver <= 832) {
							return true;
						} else if (isMogujie && _ver <= 806) {
							return true;
						}
					}
				}
				return false;
			};

			var addPtpFilter = function addPtpFilter(url) {
				return logger.util.setQuery(url, '_isfilter', '1');
			};
			// var addPtpRefer= function(url){
			// 	return logger.util.setQuery(url, '_realrefer', encodeURIComponent(location.href));
			// };

			//是否需要修复refer
			logger.needReferFix = checkReferFix();

			//h5->h5， h5->native需要修复url，分别添加_isfilter、_realrefer
			logger.fixReferUrl = function (url) {
				if (isMelishuo && isMlsNativeLink(url)) {
					//美丽说的短链
					return url;
				} else if (isMogujie && isMgjNativeLink(url)) {
					//蘑菇街的短链
					return url;
				} else {
					//不是native页面
					return addPtpFilter(url);
				}
			};
		})()
		//ptp相关信息的收集
		//暴露logger.ptp

		;
		(function () {
			var config = logger.config;
			var info = logger.info;
			var jq = logger.jq;
			var hash = new Hash();
			var ptp;
			/**
	   * 获取平台字段
	   * @returns {string}
	   */
			function getCntA() {
				// 不再提供a字段的覆盖
				// var custome = util.getValue(config.ptp_cnt_a);
				// if (custome) {
				// 	return custome;
				// }
				var _ptp_cnt_a = '1';

				// if (info.isXd) {
				// 	_ptp_cnt_a = 'xd1';
				// }
				if (info.isMobile) {
					_ptp_cnt_a = 'm1';
				}
				if (info.isIos && info.isNative) {
					_ptp_cnt_a = 'am0';
				} else if (info.isAndroid && info.isNative) {
					_ptp_cnt_a = 'am1';
				}
				return _ptp_cnt_a;
			}

			/**
	   * url hash B  字段的方式
	   * @returns {string}
	   */
			function getCntB() {
				var custome = util.getValue(config.ptp_cnt_b);
				if (custome) {
					return custome;
				}
				var _ptp_cnt_b = '';
				var _url = location.href.split('?')[0];
				// _url = _url.replace(/[\/\.]/, '_');
				_ptp_cnt_b = hash.pageHash(_url);
				return _ptp_cnt_b;
			}

			function getCpsInfo() {
				var _cpsinfo = util.getCookieOrFunc(config.cpsinfo);
				if (!_cpsinfo) return '';
				_cpsinfo = _cpsinfo.replace('-', ',');
				return _cpsinfo;
			}

			//获取平台字段
			function getPlatform() {
				var custome = util.getValue(config.platform);
				if (custome) {
					return custome;
				}
				if (info.isMobile) {
					return 32;
				} else {
					return 31;
				}
			}
			/**
	   * 用于业务方指定元素的C字段
	   */
			function getCustomC(node) {
				if (!node) return;
				var custome = util.getValue(config.ptp_cnt_c_d, node);
				if (custome) {
					return custome;
				}
				var _attr = node.getAttribute('data-ptp-customc');
				if (_attr) {
					return {
						c: _attr,
						d: jq.getIndex('data-ptp-customc', _attr, node)
						// d: $('[data-ptp-customc="' + _attr + '"]').index($(node)) + 1
					};
				}
				node = jq.getParents(node, 'data-ptp-customc');
				// node = $(node).parents('[data-ptp-customc]')[0];
				if (!node) return;
				_attr = node.getAttribute('data-ptp-customc');
				if (_attr) {
					return {
						c: _attr,
						d: jq.getIndex('data-ptp-customc', _attr, node)
						// d: $('[data-ptp-customc="' + _attr + '"]').index($(node)) + 1
					};
				}
			}
			// 获取容器离线化下的url
			function getOfflineUrl() {
				if (location.protocol.indexOf('file:') != -1) {
					//离线化下url需要通过插件获取
					document.addEventListener("deviceready", function () {
						if (window.hybrid && hybrid.bundle && hybrid.bundle.getUrl) {
							hybrid.bundle.getUrl(function (url) {
								if (ptpInfo) {
									ptpInfo.refer = url;
								}
							});
						}
					}, false);
				}
			}
			function refreshPtpInfo() {
				getOfflineUrl();
				return {
					time: util.getTime(),
					sfrom: util.getCookieOrFunc(config.sfrom),
					uuid: util.getCookieOrFunc(config.uuid),
					uid: util.getCookieOrFunc(config.uid),
					cpsinfo: getCpsInfo(),
					refer: location.href,
					rerefer: document.referrer,
					ptp_url: util.getQuery('ptp', location.href),
					ptp_ref: document.referrer ? util.getQuery('ptp', document.referrer) : ''
				};
			}
			function refreshAbcde() {
				return {
					a: getCntA(),
					b: getCntB(),
					c: 0,
					d: 0,
					e: hash.rand(5)
				};
			}
			var ptpInfo = refreshPtpInfo(),
			    abcde = refreshAbcde();

			logger.ptp = ptp = {
				//获取每个打点日志的头部格式
				getPtpByType: function getPtpByType(type, eventId) {
					var platform = getPlatform();
					var result = [ptpInfo.time, 0, 'p/e', platform, logger.version, '1001', ptpInfo.uuid, ptpInfo.uid, ptpInfo.refer, ptpInfo.rerefer];
					if (type == 'p') {
						eventId = eventId || '1001';
						result[2] = 'p';
						result[5] = eventId;
						return result;
					} else if (type == 'e') {
						eventId = eventId || '50001';
						result[2] = 'e';
						result[5] = eventId;
						return result;
					}
				},
				//获取abcde字段
				getPtpCnt: function getPtpCnt(c, d) {
					if (!c) c = abcde.c;
					if (!d) d = abcde.d;
					return [abcde.a, abcde.b, c, d, abcde.e].join('.');
				},
				//获取打点ptpinfo
				getPtpInfo: function getPtpInfo() {
					var result = {};
					return util.extend(result, ptpInfo, {
						ptp_cnt: ptp.getPtpCnt()
					});
				},
				//获取打点ptpinfo和用户自定义的数据
				getPtpInfoAndExtra: function getPtpInfoAndExtra() {
					var result = ptp.getPtpInfo();
					var extra = {};
					if (config.extra) {
						for (var key in config.extra) {
							if (config.extra.hasOwnProperty(key)) {
								extra[key] = util.getValue(config.extra[key]);
							}
						}
					}
					return util.extend(result, extra);
				},
				//通过结点，创建一个ptpCnt信息
				//获取C字段逻辑:
				//1.如果指定了data-ptp-customc,则为data-ptp-customc
				//2.如果url有mt参数，则mt参数中提取C字段
				//3.从data-ptp中获取指定C字段，通过data-ptp-item获取当前元素的位置为D字段
				//4.C、D字段为0
				createPtpCnt: function createPtpCnt(node) {
					var customC = getCustomC(node);
					var keyC = 0,
					    //C字段
					keyD = 0; //D字段
					if (customC) {
						return ptp.getPtpCnt(customC.c, customC.d);
					}

					// var $parent = $(node).parents('[data-ptp]');
					var parent = jq.getParents(node, 'data-ptp');
					var item = jq.getParentByClass(node, 'data-ptp-item');
					if (parent) {
						keyC = parent.getAttribute('data-ptp');
						//获取当前元素在父级元素中的index
						if (item) {
							keyD = jq.getElemIndex(parent, '.data-ptp-item', item);
						} else {
							keyD = jq.getElemIndex(parent, 'a', node);
						}
						// var $borders = $parent.find('.data-ptp-item');
						// if ($borders.length) {
						// 	//通过data-ptp-item来划分index
						// 	keyD = $borders.index($(node).parents('.data-ptp-item')) + 1;
						// } else {
						// 	//通过a标签的顺序获取
						// 	keyD = $parent.find('a').index($(node)) + 1;
						// }
					}
					if (!keyD) keyD = 0;
					return ptp.getPtpCnt(keyC, keyD);
				},
				/**
	    * 将传入href拼接生成新的href
	    */
				makeUrl: function makeUrl(href, ptpCnt, node) {
					var anchor = href.match(/(#.+)$/);
					href = href.replace(/(#.+)$/, '');
					href = util.setQuery(href, 'ptp', ptpCnt);
					//添加追踪参数
					href = ptp.getChasingParams(href);
					//添加data-ext-acm参数
					href = ptp.getExtendParams(node, href);
					//android807以前修正refer问题
					if (logger.needReferFix) {
						//需要修正
						href = logger.fixReferUrl(href);
					}
					if (anchor) href += anchor[1];
					return href;
				},
				/*
	    * 从url中获取需要跟踪的参数
	    */
				getChasingParams: function getChasingParams(url) {
					if (url === undefined) url = '';
					var result = url;
					if (!config.chasing) return result;
					//变成数组
					if (!config.chasing.length) {
						config.chasing = [config.chasing];
					}
					var key, value;
					for (var i = 0, l = config.chasing.length; i < l; i++) {
						key = config.chasing[i];
						// hasVal = util.getQuery(key, url);	//url里面有没有这个值
						value = util.getQuery(key);
						if (value) {
							// result.push(key + '=' + value);
							result = util.setQuery(result, key, value);
						}
					}
					return result;
				},
				getExtendParams: function getExtendParams(node, href) {
					var result = href;
					if (!node || !jq.is(node, 'a')) {
						return result;
					}
					if (node.length) node = node[0];
					var extend = config.urlExtend || [];
					for (var i = 0, l = extend.length; i < l; i++) {
						var key = extend[i];
						var value = node.getAttribute('data-ext-' + key);
						if (value) {
							//没有这个值才插进来
							// result.push(key + '=' + encodeURIComponent(value));
							result = util.setQuery(result, key, value);
						}
					}
					return result;
				},
				/*
	    * 刷新Ptp信息，当单页面url变化但页面无刷新时(pushState)，可以刷新ptp信息，以便重新打一个P事件
	    */
				refreshPtp: function refreshPtp() {
					ptpInfo = refreshPtpInfo();
					abcde = refreshAbcde();
				},
				/**
	    * 重新从cookie里面获取值，在前端种完cookie后调用
	    */
				refreshCookie: function refreshCookie() {
					if (ptpInfo) {
						ptpInfo.sfrom = util.getCookieOrFunc(config.sfrom);
						ptpInfo.uuid = util.getCookieOrFunc(config.uuid);
						ptpInfo.uid = util.getCookieOrFunc(config.uid);
						ptpInfo.cpsinfo = getCpsInfo();
					}
				}
			};
		})()
		//所有日志发送逻辑
		//暴露对象：logger.send
		;(function () {
			var info = logger.info;
			var ptp = logger.ptp;
			var config = logger.config;
			var count = 0;
			//image提交打点数据 for:!ie
			var sendLogByImage = function sendLogByImage(url, data) {
				data = data || {};
				var params = [];
				for (var key in data) {
					var value = data[key];
					if (!value) {
						value = '';
					}
					value = encodeURIComponent(value);
					params.push(key + '=' + value);
				}
				params = params.join('&');
				if (url.indexOf('?') > -1) {
					url = url + '&' + params;
				} else {
					url = url + '?' + params;
				}
				var _imgObject = new Image();
				_imgObject.src = url;
			},

			//表彰post提交打点数据 for:ie
			sendLogByIframe = function sendLogByIframe(url, data) {
				data = data || {};
				var id = count++;
				var iframe;
				try {
					iframe = document.createElement('<iframe name="' + id + '">');
				} catch (ex) {
					iframe = document.createElement('iframe');
					iframe.setAttribute('name', id);
				}
				try {
					iframe.style.display = 'none';
					document.body.appendChild(iframe);
					iframe.contentWindow.name = id;

					var form = document.createElement('form');
					form.setAttribute('method', 'POST');
					form.setAttribute('action', url);
					form.setAttribute('target', id);

					for (var key in data) {
						if (data.hasOwnProperty(key)) {
							var input = document.createElement('input');
							input.setAttribute('type', 'hidden');
							input.setAttribute('name', key);
							input.setAttribute('value', data[key]);

							form.appendChild(input);
						}
					}

					document.body.appendChild(form);
					form.submit();
					util.registerEvent(iframe, 'load', function () {
						try {
							document.body.removeChild(form);
							document.body.removeChild(iframe);
						} catch (ex) {}
					});
				} catch (ex) {
					console.log(ERRMSG + ex);
				}
			};

			var send = {
				//前端发送打点数据接口, ie下表单post，其他img请求
				sendLog: function sendLog(url, data, useImg) {
					var version = util.getIEVersion();
					var isLowIE = version != -1 && version <= 8;
					if (isLowIE && !useImg) {
						sendLogByIframe(url, data);
					} else {
						sendLogByImage(url, data);
					}
				},
				//在app里用tracer事件打点
				sendAppLog: function sendAppLog(eventId, params) {
					eventId = eventId + '';
					if (config.nativeLog && config.nativeLog.logE) {
						return config.nativeLog.logE(eventId, params);
					}
					if (window.hdp && window.hdp['do']) {
						hdp['do']('mgj.tracker.sendEvent', eventId, params);
					} else {
						document.addEventListener("deviceready", function () {
							if (window.mgj && mgj.tracker && mgj.tracker.sendEvent) {
								mgj.tracker.sendEvent(eventId, params);
							}
						}, false);
					}
				},
				//app的pevent插件打页面的p事件
				logAppPevent: function logAppPevent(ptp_cnt) {
					if (config.nativeLog && config.nativeLog.logP) {
						return config.nativeLog.logP(ptp_cnt);
					}
					if (window.hdp && window.hdp['do']) {
						hdp['do']('mgj.pevent', ptp_cnt).then(function () {}, function (err) {
							//pevent插件800前都有一个bug，成功调用也会报错!
							console.log('pevent:' + err);
						});
					} else {
						document.addEventListener("deviceready", function () {
							if (window.mgj && mgj.pevent) {
								mgj.pevent(function () {}, null, ptp_cnt);
							}
						}, false);
					}
				},
				logData: function logData(type, eventId, json) {
					var _params = ptp.getPtpByType(type, eventId);
					_params.push(util.stringify(json));
					if (!info.isNative) {
						//mogujie主客里
						send.sendLog(config.LogUrl, {
							v: 1,
							data: _params.join('\t')
						});
					} else {
						send.sendAppLog(eventId, json);
					}
				}

			};
			logger.send = send;
		})()
		//打点核心逻辑：
		//1.绑定a标签点击事件
		//2.点击事件处理，添加ptp参数到url
		//3.跳转url
		;(function () {
			var config = logger.config;
			var ptp = logger.ptp;
			var jq = logger.jq;

			//给标签url跳转前插入ptp信息
			function insertPtpInfo(node) {
				var href = node.href;
				//mtalk/下不打点
				if (href.indexOf('mogujie.com/mtalk/') > -1) return;
				//不在打点域名下
				if (!config.hrefRe.test(href) && !config.mgjRe.test(href)) return;

				var id = node.getAttribute('data-ptp-cache-id');
				href = node.getAttribute('href');

				if (!id || !config.ptpRe.test(id)) {
					id = ptp.createPtpCnt(node);
					node.setAttribute('data-ptp-cache-id', id);
				}
				node.href = ptp.makeUrl(href, id, node);
			}

			//点击事件处理
			function handleClickEvent(event) {
				/*jshint scripturl:true*/
				var _event = event || window.event,
				    target = _event.target || _event.srcElement,
				    aLink = jq.getA(target),
				    areaLink = target.nodeName === 'AREA' ? target : null;
				if (areaLink) {
					aLink = areaLink;
				}
				//没有连接
				if (!aLink) return;
				if (aLink.href && aLink.href.indexOf('javascript:') > -1) return;
				insertPtpInfo(aLink);
			}

			//bind事件
			// var mouseDown = 'tap' in document.createElement('div') ? 'tap' : 'mousedown';
			// util.registerEvent(document, mouseDown, handleClickEvent);
			//@note:绑定touchstart，部分页面添加了fastclick，所以要绑定touchstart
			// util.registerEvent(document, 'touchstart', handleClickEvent);
		})();
		//打点初始化函数:
		//1.页面自动打点P事件
		//2.暴露接口函数
		var ptp = logger.ptp;
		var config = logger.config;
		var send = logger.send;
		var isLoggerReady = !config.shouldRequestCookie();

		//进来就发请求，如果需要
		if (!isLoggerReady) {
			//请求发cookie
			util.loadScript(config.CookieUrl, function () {
				//加载打点js
				isLoggerReady = true;
				//更新数据
				logger.ptp.refreshCookie();
				util.fire('LoggerReady');
			});
		}

		function _logP() {
			var loggerInfo = ptp.getPtpInfoAndExtra();
			var pEventId = util.getValue(config.pEventId);
			send.logData('p', pEventId, loggerInfo);
			if (config.EnableLogMoGuJs) {
				//打到mogu.js
				send.sendLog(config.LogMoGuJsUrl, loggerInfo, true);
			}
		}

		function logPEvent() {
			if (!logger.info.isNative) {
				//打到log.php
				if (isLoggerReady) {
					_logP();
				} else {
					util.listenTo('LoggerReady', function () {
						_logP();
					});
				}
			} else {
				//在主客下通过插件来打p事件
				var cnt = ptp.getPtpCnt();
				send.logAppPevent(cnt);
			}
		}

		//框架自动打一个P事件
		logPEvent();

		/*
	  * 刷新页面Ptp信息并打一个P事件
	  * 主要用于单页面应用通过pushState切换页面（浏览器无刷新）时进行P事件打点
	  * 其他情况下请不要主动调用这个方法
	  */
		logger.refreshPevent = function () {
			logger.ptp.refreshPtp();
			logPEvent();
		};
		/*
	  * 自定义打点 指定事件id和打点数据
	  * eventId: number 事件ID,每个事件id都需要先注册后使用，请与业务方、BI确认
	  * json: object 自定义打点数据
	  */
		logger.log = function (eventId, json) {
			if (eventId === undefined) {
				return;
			}
			json = json || {};
			var loggerInfo = ptp.getPtpInfoAndExtra();
			if (isLoggerReady) {
				logger.send.logData('e', eventId, util.extend({}, loggerInfo, json));
			} else {
				util.listenTo('LoggerReady', function () {
					var loggerInfo = ptp.getPtpInfoAndExtra();
					logger.send.logData('e', eventId, util.extend({}, loggerInfo, json));
				});
			}
			//如果业务接入了mta，往mta上报一个自定义事件
			if (window.MtaH5 && MtaH5.clickStat) {
				MtaH5.clickStat(eventId, json);
			}
		};

		/*
	  * 为指定url构造一个带ptp参数的url, 用于js代码跳转页面时，添加ptp信息
	  * url: string 需要构造的url地址，如果地址中包含ptp参数，则直接返回
	  * node: DOM元素，如果是页面上的A标签元素，会通过传入的node来获取自定义的C、D字段，否则C、D字段为0
	  */
		logger.generatePtpParams = function (url, node) {
			if (url === undefined) {
				return;
			}
			var ptpCnt = '';
			if (node) {
				//通过结点获取ptp信息
				ptpCnt = ptp.createPtpCnt(node);
			} else {
				//获取ptp信息C、D字段为0
				ptpCnt = ptp.getPtpCnt();
			}
			return ptp.makeUrl(url, ptpCnt, node);
		};

		//打一个e事件
		if (logger.needReferFix && document.referrer) {
			var _loggerInfo = ptp.getPtpInfoAndExtra();
			logger.log('016000616', {
				ptp_cnt2: _loggerInfo.ptp_cnt,
				ptp_url2: _loggerInfo.ptp_url,
				ptp_ref2: _loggerInfo.ptp_ref
			});
		}
		//兼容amd|cmd代码
		if (typeof module !== 'undefined' && ( false ? 'undefined' : _typeof(exports)) === 'object') {
			module.exports = logger;
		} else if (true) {
			!(__WEBPACK_AMD_DEFINE_RESULT__ = function () {
				return logger;
			}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		}
	})(window);

/***/ },
/* 7 */
/*!*****************************************************************************************************************************!*\
  !*** ./~/@mogu/xcore-html-loader!./~/@mogu/xcore-loader/lib/selector.js?type=template&index=0!./source/pages/hello/app.vue ***!
  \*****************************************************************************************************************************/
/***/ function(module, exports) {

	module.exports = {render: function() {with(this){return _m(0)}},staticRenderFns: [function() {with(this){return _h('body',[_h('scrollview',{staticClass:"scroll"},[_h('view',{staticClass:"hi"},[_h('label',{staticClass:"label"},["hello world"])])])])}}]};

/***/ }
/******/ ]);
//# sourceMappingURL=bundle.js.map