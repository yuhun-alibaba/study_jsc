package com.lynx.utils;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.util.Log;
import android.util.SparseArray;

import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by yxp on 16/12/26.
 *
 * 帮助裁剪成圆角视图，不显示子类超出圆角的部分，对子view和本身具有裁剪效果
 */

public class RoundCanvasClipper {
    private static int TOO_LARGE_VALUE = 5000;
    private static MaskKeeper sMaskKeeper;
    private static RoundCanvasClipper sClipper;

    private PorterDuffXfermode mMode = new PorterDuffXfermode(PorterDuff.Mode.DST_IN);

    /**
     * 清除所有缓存的mask
     */
    public static synchronized void clearMasks() {
        if (sMaskKeeper != null) {
            sMaskKeeper.clearAll();
            sMaskKeeper = null;
            sClipper = null;
        }
    }

    public static synchronized RoundCanvasClipper instance() {
        if (sClipper == null) {
            sClipper = new RoundCanvasClipper();
        }
        return sClipper;
    }

    private RoundCanvasClipper() {
        if (sMaskKeeper == null) {
            sMaskKeeper = new MaskKeeper(5);
        }
    }

    static boolean isTooLarge(double a) {
        boolean result = a > TOO_LARGE_VALUE;
        if (result) {
            Log.w("xcore", "Image Mask maybe too large, it isn't suggested !");
        }
        return result;
    }

    /**
     * 裁剪roundRect区域，当使用在view的draw()方法中，需要配合saveLayer进行绘制，否则会有黑色背景
     * 此方法会创建单通道的mask减少内存上的消耗，同时使用cache方式减少creatBitmap的性能上的损耗
     * @param canvas
     * @param elementProxy
     */
    public void clipRoundRectUseXfermode(Canvas canvas, RenderObjectImpl elementProxy) {
        clipRoundRectUseXfermode(canvas, elementProxy, null);
    }

    /**
     * 带有config参数的mask将不会被保存到cache中，mask会在用完之后立即回收，提供给对于bitmap预处理使用。
     * @param canvas
     * @param elementProxy
     * @param config
     */
    public void clipRoundRectUseXfermode(Canvas canvas, RenderObjectImpl elementProxy, Bitmap.Config config) {
        if (elementProxy == null) {
            return;
        }
        int width = elementProxy.getPosition().getWidth();
        int height = elementProxy.getPosition().getHeight();
        clipRoundRectUseXfermode(canvas, width, height, (float) elementProxy.getStyle().mBorderRadius, (float) elementProxy.getStyle().mBorderRadius, config);
    }

    private void clipRoundRectUseXfermode(Canvas canvas, int width, int height, float rx, float ry, Bitmap.Config config) {
        if (width == 0 || height == 0 ||
                Double.isInfinite(width) || Double.isNaN(width) ||
                Double.isInfinite(height) || Double.isNaN(height) ||
                isTooLarge(width) || isTooLarge(height)) {
            return;
        }

        Bitmap mask = null;
        boolean needToRecycle = false;
        Paint maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        // 尝试获取cache中的bitmap
        int key = generateKey(width, height, rx, ry);
        if (config == null) {
            mask = sMaskKeeper.get(key);
        }
        if (mask == null) {
            // 创建新的bitmap
            if (config == null) {
                mask = Bitmap.createBitmap(width, height, Bitmap.Config.ALPHA_8);
                needToRecycle = false;
            } else {
                mask = Bitmap.createBitmap(width, height, config);
                needToRecycle = true;
            }
            Canvas maskCanvas = new Canvas();
            maskCanvas.setBitmap(mask);
            maskCanvas.drawRoundRect(new RectF(0, 0, width, height), rx, ry, maskPaint);
            // 存入cache
            if (!needToRecycle) {
                sMaskKeeper.set(key, mask);
            }
        }

        // 进行圆角裁剪
        if (mask != null && !mask.isRecycled()) {
            maskPaint.setXfermode(mMode);
            canvas.drawBitmap(mask, 0, 0, maskPaint);
            if (needToRecycle) {
                mask.recycle();
            }
        }
    }

    private int generateKey(int width, int height, float rx, float ry) {
        int hash = 17;
        hash = hash * 31 + width;
        hash = hash * 31 + height;
        hash = hash * 31 + Float.floatToIntBits(rx);
        hash = hash * 31 + Float.floatToIntBits(ry);
        return hash;
    }

    /* LRU Cache 的方式去存储mask */
    private class MaskKeeper {
        private int mCapacity;
        private int mCount;
        private SparseArray<Pair> mMaps;
        private Pair mHead, mTail;

        MaskKeeper(int capacity) {
            this.mCapacity = capacity;
            mMaps = new SparseArray<>();
            mHead = new Pair(0, null);
            mTail = new Pair(-1, null);
            mHead.last = null;
            mHead.next = mTail;
            mTail.last = mHead;
            mTail.next = null;
        }

        synchronized void clearAll() {
            for (int i = 0; i < mMaps.size(); ++i) {
                Pair pair = mMaps.valueAt(i);
                if (pair.mask != null && !pair.mask.isRecycled()) {
                    pair.mask.recycle();
                }
            }
            mMaps.clear();
        }

        public synchronized Bitmap get(int key) {
            Pair pair = mMaps.get(key);
            if (pair != null) {
                moveToFirst(pair);
                return pair.mask;
            }
            return null;
        }

        public synchronized void set(int key, Bitmap mask) {

            if (mMaps.get(key) == null) {
                Pair pair = new Pair(key, mask);
                mCount++;
                addPair(pair);
                mMaps.put(pair.key, pair);
                if (mCount > mCapacity) {
                    Pair removed = popTail();
                    mMaps.remove(removed.key);
                    mCount--;
                }
            } else {
                Pair pair = mMaps.get(key);
                pair.mask = mask;
                moveToFirst(pair);
            }
        }

        private void addPair(Pair pair) {
            pair.last = mHead;
            pair.next = mHead.next;

            mHead.next.last = pair;
            mHead.next = pair;
        }

        private void removePair(Pair pair) {
            Pair last = pair.last;
            Pair next = pair.next;

            last.next = next;
            next.last = last;
        }

        private void moveToFirst(Pair pair) {
            removePair(pair);
            addPair(pair);
        }

        private Pair popTail() {
            Pair pop = mTail.last;
            removePair(pop);
            return pop;
        }
    }

    private class Pair {
        int key;
        Bitmap mask;
        Pair next;
        Pair last;

        public Pair(int key, Bitmap mask) {
            this.key = key;
            this.mask = mask;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (obj instanceof Pair && ((Pair) obj).key == this.key) {
                return true;
            }
            return false;
        }
    }
}
