package com.lynx.utils;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by Monster on 2016/11/7.
 */

public class InputBackground extends Drawable {

    private Paint mPaint;
    private boolean needBorder = false;
    private float mRadius = 0;
    private Paint mBackgroundPaint;
    private RectF mBorderRectF;

    public InputBackground() {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBackgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBorderRectF = new RectF();
    }
    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        float x = b.width() ;
        float y = b.height() - mPaint.getStrokeWidth() / 2;

        mBorderRectF.set(0, 0, x, y);
        canvas.drawRoundRect(mBorderRectF, mRadius, mRadius, mBackgroundPaint);
        if (needBorder) {
            canvas.drawRoundRect(mBorderRectF, mRadius, mRadius, mPaint);
        }
    }

    @Override
    public void setAlpha(int alpha) {

    }

    @Override
    public void setColorFilter(ColorFilter cf) {

    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSPARENT;
    }

    public void setDrawAttr(RenderObjectImpl shadowNode) {
       // needRefresh = true;
        if ((float) shadowNode.getStyle().mBorderWidth > 0) {
            needBorder = true;
        } else {
            needBorder = false;
        }
        // 设置边框
        if (needBorder) {
            mPaint.setColor(shadowNode.getStyle().mBorderColor);
            mPaint.setAntiAlias(true);
            mPaint.setStrokeWidth((float) shadowNode.getStyle().mBorderWidth);
            mPaint.setStyle(Paint.Style.STROKE);
        }
        // 设置背景颜色
        mBackgroundPaint.setColor(shadowNode.getStyle().mBackgroundColor);
        // 设置圆角
        if ((float) shadowNode.getStyle().mBorderRadius > 0) {
            mRadius = (float) shadowNode.getStyle().mBorderRadius;
        } else {
            mRadius = 0;
        }
    }
}
