package com.lynx.core.impl;

import com.lynx.base.CalledByNative;
import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.LynxUIFactory;
import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.listview.LynxUIListView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by dli on 05/01/2017.
 */

public class RenderObjectImpl  {

    private native void nativeDispatchEvent(long nativePtr, String event, Object[] params);

    private native void nativeSyncBaseAttr(long nativePtr, int attr, Object param);

    private long mNativePtr;

    private Position mPosition;

    private Size mSize;

    private String mText;

    private int mRenderObjectType;

    private Style mStyle;

    private WeakReference<LynxRenderImplInterface> mRenderImpl;

    private List<RenderObjectImpl> mChildren;

    private RenderObjectImpl mParent;

    private Map<String, String> mAttributes;

    private List<String> mEvents;

    private RenderObjectImpl(int type, long ptr) {
        this.mRenderObjectType = type;
        this.mNativePtr = ptr;
        this.mAttributes = new HashMap<>();
        this.mPosition = new Position();
        this.mSize = new Size();
        this.mEvents = new ArrayList<>();
    }

    public boolean hasViewImpl() {
        return mRenderImpl != null && mRenderImpl.get() != null;
    }

    public LynxRenderImplInterface getViewImpl() {
        if(hasViewImpl()) {
            return mRenderImpl.get();
        }
        return null;
    }

    public void setViewImpl(LynxRenderImplInterface impl) {
        if(hasViewImpl()) {
            mRenderImpl.clear();
        }
        mRenderImpl = new WeakReference<>(impl);
    }

    @CalledByNative
    public void insertChild(RenderObjectImpl child, int index) {

        if(child == null) return;
        if(mChildren == null) {
            mChildren  = new ArrayList<>();
        }

        child.mParent = this;

        if(index < 0) {
            mChildren.add(child);
        }else{
            mChildren.add(index, child);
        }

        if (this.getRenderObjectType() == LynxUIFactory.UI_TYPE_LIST_SHADOW
                && mParent != null && mParent.hasViewImpl()) {
            ((LynxUIListView) mParent.getViewImpl()).notifyDataSetChanged();
        }

        if(hasViewImpl()) {
            mRenderImpl.get().insertChild(child, index);
        }
    }

    @CalledByNative
    public void removeChild(RenderObjectImpl child) {

        child.mParent = null;
        mChildren.remove(child);

        if(hasViewImpl()) {
            mRenderImpl.get().removeChild(child);
        }

        if (this.getRenderObjectType() == LynxUIFactory.UI_TYPE_LIST_SHADOW
                && mParent != null && mParent.hasViewImpl()) {
            ((LynxUIListView) mParent.getViewImpl()).notifyDataSetChanged();
        }
    }

    public RenderObjectImpl getChildAt(int index) {
        return mChildren.get(index);
    }

    public int getChildCount() {
        if (mChildren == null) {
            return 0;
        }
        return mChildren.size();
    }

    @CalledByNative
    public void requestLayout() {
        if(hasViewImpl()) {
            mRenderImpl.get().requestLayout();
        }
    }

    @CalledByNative
    public void setText(String text) {
        mText = text;
        if(hasViewImpl()) {
            mRenderImpl.get().setText(text);
        }
    }

    @CalledByNative
    public void setPosition(Position position) {
        mPosition = position;
        if(hasViewImpl()) {
            mRenderImpl.get().setPosition(position);
        }
    }

    @CalledByNative
    public void setSize(Size size) {
        mSize = size;
        if (hasViewImpl()) {
            mRenderImpl.get().setSize(size);
        }
    }
    
    @CalledByNative
    public void updateStyle(Style style) {
        mStyle = style;
        if(hasViewImpl()) {
            mRenderImpl.get().updateStyle(style);
        }
    }

    @CalledByNative
    public void setAttribute(String key, String value) {
        mAttributes.put(key, value);
        if(hasViewImpl()) {
            mRenderImpl.get().setAttribute(key, value);
        }
    }

    public int getRenderObjectType() {
        return mRenderObjectType;
    }

    public Position getPosition() { return mPosition; }

    public Size getSize() { return mSize; }

    public Style getStyle() { return  mStyle; }

    public String getText() { return  mText; }

    public String getValue(String key) { return  mAttributes.get(key); }

    @CalledByNative
    public void addEventListener(String event) {
        mEvents.add(event);
        if(hasViewImpl()) {
            mRenderImpl.get().addEventListener(event);
        }
    }

    @CalledByNative
    public void removeEventListener(String event) {
        mEvents.add(event);
        if(hasViewImpl()) {
            mRenderImpl.get().removeEventListener(event);
        }
    }

    public void dispatchEvent(String event, Object[] params) {
        nativeDispatchEvent(mNativePtr, event, params);
    }

    @CalledByNative
    public void setBaseAttr(int attr, Object param) {
        if (hasViewImpl()) {
            mRenderImpl.get().setBaseAttr(attr, param);
        }
    }

    public void syncBaseAttr(RenderObjectAttr attr, Object param) {
        nativeSyncBaseAttr(mNativePtr, attr.value(), param);
    }

    public List<String> getEvents() {
        return mEvents;
    }

    @CalledByNative
    public static RenderObjectImpl create(int type, long ptr) {
        return new RenderObjectImpl(type, ptr);
    }

}
