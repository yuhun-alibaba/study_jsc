package com.lynx.core.input;

import android.os.Handler;
import android.os.Message;
import android.view.View;

import static com.lynx.core.input.EventHandlerType.BLUR_EVENT_TYPE;
import static com.lynx.core.input.EventHandlerType.CHANGE_EVENT_TYPE;

/**
 * Created by Monster on 2016/11/10.
 * input组件的失焦，change事件
 * 失焦事件定义:光标已经不在此组件上。
 * change事件定义:当失焦之后，输入框文本内容发生改变。
 */

public class BlurAndChangeEventListener implements View.OnFocusChangeListener {
    //事件处理
    private Handler mHandler;

    //获取焦点时的字符串
    private String originText = null;

    public BlurAndChangeEventListener(Handler handler) {
        mHandler = handler;
    }

    public void setOriginText(String originText) {
        this.originText = originText;
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        //清除消息
        mHandler.removeMessages(BLUR_EVENT_TYPE.ordinal());
        mHandler.removeMessages(CHANGE_EVENT_TYPE.ordinal());

        //失去焦点
        if (!hasFocus) {
            mHandler.sendEmptyMessageDelayed(BLUR_EVENT_TYPE.ordinal(), 500);
            Message msg = Message.obtain();
            msg.what = CHANGE_EVENT_TYPE.ordinal();
            msg.obj = originText;
            mHandler.sendMessageDelayed(msg, 510);
        }
    }
}
