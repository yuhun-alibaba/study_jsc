package com.lynx.core.sliderimage;

import com.lynx.core.base.LynxEvent;

/**
 * Created by Monster on 2017/3/17.
 */

public class SliderImageEvent extends LynxEvent {
    private static final String INDEX = "index";
    public String type;
    public int index;

    public SliderImageEvent(String type, int index) {
        super(type);
        setProperty(INDEX, index);
        this.index = index;
        this.type = type;
    }

    public void setIndex(int index) {
        setProperty(INDEX, index);
        this.index = index;
    }

    public String getType() {
        return type;
    }

    public int getIndex() {
        return index;
    }
}
