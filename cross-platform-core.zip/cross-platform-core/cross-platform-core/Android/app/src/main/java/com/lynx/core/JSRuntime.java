package com.lynx.core;

import com.lynx.base.Style;
import com.lynx.core.tree.LynxRenderTreeHostImpl;

/**
 * Created by dli on 11/22/16.
 */
public class JSRuntime {

    private native int nativeCreateNativeJSRuntime();

    private native void nativeDestroyNativeJSRuntime(long runtime);

    private native void nativeRunScript(long runtime, String source);

    private native void nativeLoadHTML(long runtime, String source);

    private native void nativeLoadUrl(long runtime, String url);

    private native void nativeInitRuntime(long runtime);

    private native Object nativeActiveRuntime(long runtime, int width, int height, double density, boolean dataServerRendered);

    private long mNativeRuntime;

    public JSRuntime() {
        mNativeRuntime = nativeCreateNativeJSRuntime();
    }

    public void runScript(String source) {

        nativeRunScript(mNativeRuntime, source);
    }

    public void loadHTML(String source) {

        nativeLoadHTML(mNativeRuntime, source);
    }

    public void loadUrl(String url) {
        nativeLoadUrl(mNativeRuntime, url);
    }

    public void initialize() {
        nativeInitRuntime(mNativeRuntime);
    }

    public LynxRenderTreeHostImpl active(Object view, int width, int height, double density, boolean dataServerRendered) {
        Object host = nativeActiveRuntime(mNativeRuntime, width, height, density, dataServerRendered);
        Style.mDensity = density;
        return (LynxRenderTreeHostImpl) host;
    }

    public void destroy() {
        nativeDestroyNativeJSRuntime(mNativeRuntime);
        mNativeRuntime = 0;
    }

    public long ID() {
        return mNativeRuntime;
    }
}
