package com.lynx.core.sliderimage;

/**
 * Created by yanxing on 16/11/7.
 */

public class ImageData {
    public String img;

    public String getImg() {
        if (null == img) {
            img = "";
        }
        return img;
    }

    public void setImg(String img){
        this.img = img;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof ImageData) {
            return ((ImageData) o).img.equals(this.img);
        }
        return super.equals(o);
    }
}
