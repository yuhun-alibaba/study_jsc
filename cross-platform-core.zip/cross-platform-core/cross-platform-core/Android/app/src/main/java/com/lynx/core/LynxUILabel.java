package com.lynx.core;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;

import com.lynx.base.Constants;
import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.impl.RenderObjectImpl;
import com.lynx.utils.RoundBackgroundUtil;

import static com.lynx.base.Style.CSSTEXT_FONT_WEIGHT_BOLD;

/**
 * Created by dli on 11/24/16.
 */
public class LynxUILabel extends android.support.v7.widget.AppCompatTextView implements LynxRenderImplInterface {

    public final static float DEFAULT_FONT_SIZE = 14.0f;

    private RoundBackgroundUtil mRoundBackgroundUtil;

    private RenderObjectImpl mImpl;

    public LynxUILabel(Context context, RenderObjectImpl impl) {
        super(context);
        mRoundBackgroundUtil = new RoundBackgroundUtil();
        linkElement(impl);
    }

    @Override
    public void addEventListener(String event) {

    }

    @Override
    public void removeEventListener(String event) {

    }

    @Override
    public void setBaseAttr(int attr, Object param) {

    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mImpl.getPosition() == null) {
            setMeasuredDimension(0, 0);
        } else {
            super.onMeasure(mImpl.getPosition().getWidth(),
                    mImpl.getPosition().getHeight());
            setMeasuredDimension(
                    mImpl.getPosition().getWidth(),
                    mImpl.getPosition().getHeight()
            );
        }
    }

    @Override
    public void layoutView() {
        if (mImpl.getPosition() == null) {
            super.layout(0, 0, 0, 0);
        }else {
            super.layout(mImpl.getPosition().mLeft,
                    mImpl.getPosition().mTop,
                    mImpl.getPosition().mRight,
                    mImpl.getPosition().mBottom);
        }
    }

    @Override
    public void linkElement(RenderObjectImpl impl) {
        mImpl = impl;
        mImpl.setViewImpl(this);
        updateStyle(impl.getStyle());
        setText(impl.getText());
    }

    @Override
    public void separateElement() {
        mImpl.setViewImpl(null);
        mImpl = null;
    }

    @Override
    public RenderObjectImpl getImpl() {
        return mImpl;
    }

    @Override
    public void insertChild(RenderObjectImpl child, int index) {

    }

    @Override
    public void removeChild(RenderObjectImpl child) {
    }

    @Override
    public void updateStyle(Style style) {
        if(style == null) return;
        this.setTypeface(LabelMeasurer.getTypeface());
        if (style.mFontWeight == CSSTEXT_FONT_WEIGHT_BOLD) {
            this.getPaint().setFakeBoldText(true);
        } else {
            this.getPaint().setFakeBoldText(false);
        }
        this.setBackgroundColor(Color.TRANSPARENT);
        this.setTextColor(style.mFontColor);
        this.setTextSize(TypedValue.COMPLEX_UNIT_DIP, Constants.isUndefined(style.mFontSize) ?
                DEFAULT_FONT_SIZE: style.mFontSize);
        this.setTextAlign(style.mTextAlign);
        this.setOverflow(style.mTextOverflow);
        this.setWhiteSpace(style.mWhiteSpace);
        this.setTextDecoration(style.mTextDecoration);
        //this.setPadding((int) style.mPaddingLeft, (int) style.mPaddingTop,
        //        (int) style.mPaddingRight, (int) style.mPaddingBottom);
        mRoundBackgroundUtil.setDrawAttr(mImpl);
        this.requestLayout();
        this.postInvalidate();

    }

    private void setTextAlign(int align) {
        switch (align) {
            case Style.CSSTEXT_ALIGN_LEFT:
                this.setGravity(Gravity.LEFT);
                break;
            case Style.CSSTEXT_ALIGN_RIGHT:
                this.setGravity(Gravity.RIGHT);
                break;
            case Style.CSSTEXT_ALIGN_CENTER:
                this.setGravity(Gravity.CENTER);
                break;
            default:
                break;
        }
    }

    private void setOverflow(int overflow) {
        switch (overflow) {
            case Style.CSSTEXT_OVERFLOW_ELLIPSIS:
                this.setEllipsize(TextUtils.TruncateAt.END);
                break;
            default:
                break;
        }
    }

    private void setWhiteSpace(int whiteSpace) {
        switch (whiteSpace) {
            case Style.CSSTEXT_WHITESPACE_NOWRAP:
                this.setMaxLines(1);
                break;
            default:
                break;
        }
    }

    private void setTextDecoration(int textDecoration) {
        switch (textDecoration) {
            case Style.CSSTEXT_TEXTDECORATION_LINETHROUGH:
                this.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
                break;
            case Style.CSSTEXT_TEXTDECORATION_NONE:
                this.getPaint().setFlags(Paint.ANTI_ALIAS_FLAG);
                break;
            default:
                break;
        }
    }

    @Override
    public void setText(String text) {
        if(text != null) {
            super.setText(text);
        }
    }

    @Override
    public void requestLayout() {
        super.requestLayout();
    }

    @Override
    public void setPosition(Position position) {
        requestLayout();
    }

    @Override
    public void setSize(Size size) {

    }

    @Override
    public void setAttribute(String key, String value) {

    }
}
