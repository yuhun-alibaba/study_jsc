package com.lynx.core.input;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.EditText;

import com.lynx.base.Constants;
import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.LabelMeasurer;
import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.impl.RenderObjectImpl;
import com.lynx.utils.InputBackground;

import java.util.Iterator;
import java.util.List;

import static android.text.InputType.TYPE_CLASS_TEXT;
import static com.lynx.base.Style.CSSTEXT_FONT_WEIGHT_BOLD;
import static com.lynx.core.LynxUILabel.DEFAULT_FONT_SIZE;
import static com.lynx.core.input.EventHandlerType.BLUR_EVENT_TYPE;
import static com.lynx.core.input.EventHandlerType.CHANGE_EVENT_TYPE;
import static com.lynx.core.input.EventType.BLUR_EVENT;
import static com.lynx.core.input.EventType.CHANGE_EVENT;
import static com.lynx.core.input.EventType.FOCUS_EVENT;
import static com.lynx.core.input.EventType.INPUT_EVENT;

/**
 * Created by Monster on 2017/3/6.
 */

public class LynxUIInput extends EditText implements LynxRenderImplInterface {

    private RenderObjectImpl mImpl;
    /**
     * 处理事件
     */
    protected EventHandler mHandler;
    protected static int MAX_LENGTH_DEFAULT = 140;
    /**
     * 保存初始的文本内容以及焦点聚焦时的文本内容。
     */
    protected String mText;
    /**
     * 失去焦点和文本改变的监听
     */
    protected BlurAndChangeEventListener mBlurAndChangeEventListener;
    /**
     * input事件监听
     */
    protected InputEventListener mTextListener;
    /**
     * 获取焦点事件监听
     */
    protected FocusEventListener mFocusChangeListener;

    public LynxUIInput(Context context, RenderObjectImpl impl) {
        super(context);
        linkElement(impl);
    }

    @Override
    public void layoutView() {
        if (mImpl.getPosition() == null) {
            super.layout(0, 0, 0, 0);
        }else {
            super.layout(mImpl.getPosition().mLeft,
                    mImpl.getPosition().mTop,
                    mImpl.getPosition().mRight,
                    mImpl.getPosition().mBottom);
        }
    }

    @Override
    public void linkElement(RenderObjectImpl impl) {
        mImpl = impl;
        mImpl.setViewImpl(this);
        updateStyle(impl.getStyle());
        setText(impl.getText());
        addEvents(impl.getEvents());
    }

    private void addEvents(List<String> events) {
        if (events.isEmpty()){
            return;
        }
        //设置所有的监听，但是不使能
        mTextListener = new InputEventListener(mImpl);
        this.addTextChangedListener(mTextListener);
        mHandler = new EventHandler(mImpl);
        mBlurAndChangeEventListener = new BlurAndChangeEventListener(mHandler);
        this.setOnFocusChangeListener(mBlurAndChangeEventListener);
        mFocusChangeListener = new FocusEventListener(mImpl, mBlurAndChangeEventListener, mHandler);
        this.setOnTouchListener(mFocusChangeListener);

        //一个个设置
        Iterator it = events.iterator();
        while (it.hasNext()) {
            addEventListener((String) it.next());
        }
    }

    @Override
    public void separateElement() {
        mImpl.setViewImpl(null);
        mImpl = null;
    }

    @Override
    public RenderObjectImpl getImpl() {
        return mImpl;
    }

    @Override
    public void insertChild(RenderObjectImpl child, int index) {

    }

    @Override
    public void removeChild(RenderObjectImpl child) {

    }

    @Override
    public void setText(String text) {
        if(text != null) {
            super.setText(text);
        }
    }

    @Override
    public void setPosition(Position position) {
        requestLayout();
    }

    @Override
    public void setAttribute(String key, String value) {
        switch (key) {
            case "type":
                updateType(value);
                break;
            case "placeholder":
                //设置提示文字
                updatePlaceHolder(value);
                break;
            case "pcolor":
                updatePlaceHolderColor(value);
                break;
            case "maxlength":
                updateMaxLength(value);
                break;
            case "value":
                updateText(value);
                break;
            case "autofocus":
                updateAutoFocusStatus(value);
                break;
            default:
                break;
        }
    }

    /**
     * 自动聚焦
     */
    protected void updateAutoFocusStatus(String focus) {
        if (!TextUtils.isEmpty(focus)) {
            if (Boolean.valueOf(focus)) {
                this.requestFocus();
            }
        }
    }

    /**
     * 设置文字
     */
    protected void updateText(String text) {
        if (text != null) {
            this.setText(text);
        }
    }

    /**
     * 设置文本长度
     *
     * @param length
     */
    protected void updateMaxLength(String length) {
        if (!TextUtils.isEmpty(length)) {
            try {
                int l = Integer.parseInt(length);
                this.setFilters(new InputFilter[]{new InputFilter.LengthFilter(l)});
            } catch (NumberFormatException e) {
                this.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_LENGTH_DEFAULT)});
                e.printStackTrace();
            }
        }
    }

    /**
     * 设置提示文字
     */
    protected void updatePlaceHolderColor(String placeHolderColor) {
        if (!TextUtils.isEmpty(placeHolderColor) ){
            try {
                int color = Integer.parseInt(placeHolderColor);
                if (color != 0){
                    this.setHintTextColor(color);
                }
            } catch (NumberFormatException e){
                e.printStackTrace();
            }
        }

    }

    /**
     * 设置提示文字
     */
    protected void updatePlaceHolder(String placeHolder) {
        if (placeHolder != null) {
            this.setHint(placeHolder);
        }

    }

    /**
     * 设置输入文本类型
     *
     * @param type
     */
    protected void updateType(String type) {
        if (!TextUtils.isEmpty(type)) {
            switch (type) {
                case "text":
                    this.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    break;
                case "password":
                    this.setInputType(TYPE_CLASS_TEXT);
                    break;
                case "number":
                    this.setInputType(InputType.TYPE_CLASS_NUMBER);
                    break;
                default:
                    break;
            }

        }

    }

    @Override
    public void updateStyle(Style style) {
        if(style == null) return;
        this.setTypeface(LabelMeasurer.getTypeface());
        if (style.mFontWeight == CSSTEXT_FONT_WEIGHT_BOLD) {
            this.getPaint().setFakeBoldText(true);
        } else {
            this.getPaint().setFakeBoldText(false);
        }
        this.setBackgroundColor(Color.TRANSPARENT);
        this.setTextColor(style.mFontColor);
        this.setTextSize(TypedValue.COMPLEX_UNIT_DIP, Constants.isUndefined(style.mFontSize) ?
                DEFAULT_FONT_SIZE: style.mFontSize);
        this.setTextAlign(style.mTextAlign);
        this.setOverflow(style.mTextOverflow);

        setOverflow(style.mTextOverflow);
        this.setWhiteSpace(style.mWhiteSpace);
        this.setTextDecoration(style.mTextDecoration);
        InputBackground background = new InputBackground();
        background.setDrawAttr(mImpl);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            this.setBackground(background);
        } else {
            this.setBackgroundDrawable(background);
        }
        requestLayout();
        this.requestLayout();
    }

    private void setTextDecoration(int textDecoration) {
        switch (textDecoration) {
            case Style.CSSTEXT_TEXTDECORATION_LINETHROUGH:
                this.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
                break;
            case Style.CSSTEXT_TEXTDECORATION_NONE:
                this.getPaint().setFlags(Paint.ANTI_ALIAS_FLAG);
                break;
            default:
                break;
        }
    }

    private void setWhiteSpace(int whiteSpace) {
        switch (whiteSpace) {
            case Style.CSSTEXT_WHITESPACE_NOWRAP:
                this.setMaxLines(1);
                break;
            default:
                break;
        }
    }

    private void setTextAlign(int align) {
        switch (align) {
            case Style.CSSTEXT_ALIGN_LEFT:
                this.setGravity(Gravity.LEFT);
                break;
            case Style.CSSTEXT_ALIGN_RIGHT:
                this.setGravity(Gravity.RIGHT);
                break;
            case Style.CSSTEXT_ALIGN_CENTER:
                this.setGravity(Gravity.CENTER);
                break;
            default:
                break;
        }
    }

    private void setOverflow(int overflow) {
        switch (overflow) {
            case Style.CSSTEXT_OVERFLOW_ELLIPSIS:
                this.setEllipsize(TextUtils.TruncateAt.END);
                break;
            default:
                break;
        }
    }

    @Override
    public void setSize(Size size) {

    }

    @Override
    public void addEventListener(String event) {
        if (event.equalsIgnoreCase(INPUT_EVENT)) {
            mTextListener.setEnableInput(true);
        } else if (event.equalsIgnoreCase(FOCUS_EVENT)) {
            mHandler.setEnableFocus(true);
            mFocusChangeListener.setEnableFocus(true);
        } else if (event.equalsIgnoreCase(BLUR_EVENT)) {
            mHandler.setEnableBlur(true);
        } else if (event.equalsIgnoreCase(CHANGE_EVENT)) {
            mHandler.setEnableChange(true);
            mBlurAndChangeEventListener.setOriginText(mText);
        }
    }

    @Override
    public void removeEventListener(String event) {
        this.setOnTouchListener(null);
        this.setOnFocusChangeListener(null);
        this.removeTextChangedListener(mTextListener);
        mTextListener = null;
        mBlurAndChangeEventListener = null;
        mFocusChangeListener = null;
        mHandler.removeMessages(BLUR_EVENT_TYPE.ordinal());
        mHandler.removeMessages(CHANGE_EVENT_TYPE.ordinal());
        mHandler = null;
    }

    @Override
    public void setBaseAttr(int attr, Object param) {

    }
}
