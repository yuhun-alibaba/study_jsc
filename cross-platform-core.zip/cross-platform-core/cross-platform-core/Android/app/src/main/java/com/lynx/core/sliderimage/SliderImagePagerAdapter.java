package com.lynx.core.sliderimage;

import android.content.Context;

import com.lynx.core.sliderview.SliderViewPagerAdapter;

import java.util.List;

/**
 * Created by Monster on 2017/3/14.
 */

public class SliderImagePagerAdapter extends SliderViewPagerAdapter {
    public SliderImagePagerAdapter(Context context) {
        super(new SliderImageChildFactory(context));
    }

    public void setDataList(List<? extends ImageData> dataList) {
        ((SliderImageChildFactory)mChildViewFactory).setDataList(dataList);
        notifyDataSetChanged();
    }
}
