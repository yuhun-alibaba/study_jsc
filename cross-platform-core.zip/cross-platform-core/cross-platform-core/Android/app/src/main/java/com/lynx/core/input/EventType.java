package com.lynx.core.input;

/**
 * Created by Monster on 2016/11/23.
 */

public class EventType {
    /**
     * input 事件
     * 持续不断输入
     */
    public final static String INPUT_EVENT = "input";

    /**
     * 获取焦点事件
     */
    public final static String FOCUS_EVENT = "focus";

    /**
     * 失去焦点事件
     */
    public final static String BLUR_EVENT = "blur";

    /**
     * 失去焦点后文本改变事件
     */
    public final static String CHANGE_EVENT = "change";

}
