package com.lynx.core.tree;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by dli on 30/03/2017.
 */

public class LynxUIActionCollector {

    private Map<Object, Map<String, LynxUIAction>> mEventActions = new HashMap<>();

    public void collect(LynxUIAction action) {
        if(action.type() == LynxUIActionType.DO_EVENT_ACTION) {
            Map actions = mEventActions.get(action.target());
            if(actions == null) {
                actions = mEventActions.put(action.target(), new HashMap<String, LynxUIAction>());
            }
            LynxUIAction eventAction = (LynxUIAction)actions.get(((LynxUIEventAction)action).event());
            if(eventAction != null) {
                actions.remove(((LynxUIEventAction)action).event());
            }
            actions.put(((LynxUIEventAction)action).event(), action);
        }
    }

    public boolean needDoActions() {
        return !mEventActions.isEmpty();
    }

    public void doActions() {
        Iterator actionsIter = mEventActions.entrySet().iterator();
        while (actionsIter.hasNext()) {
            Map.Entry actionsEntry = (Map.Entry) actionsIter.next();
            HashMap actions = (HashMap<String, LynxUIAction>)actionsEntry.getValue();
            Iterator actionIter = mEventActions.entrySet().iterator();
            while (actionIter.hasNext()) {
                Map.Entry actionEntry = (Map.Entry) actionIter.next();
                LynxUIAction action = (LynxUIAction)actionEntry.getValue();
                action.doAction();
            }
        }
    }

}
