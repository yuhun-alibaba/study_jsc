package com.lynx.core.sliderimage;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.impl.RenderObjectImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Monster on 2017/3/17.
 */

public class LynxUISliderImage extends SliderImage implements LynxRenderImplInterface {

    private final static int DEFAULT_INTERVAL = 4000;

    final static String EVENT_TAG_CLICK = "click";
    final static String EVENT_TAG_CHANGE = "change";

    private RenderObjectImpl mImpl;
    private OnPageChangeListener mOnPageChangeListener;
    private SliderImageEvent mEventToJs = new SliderImageEvent(EVENT_TAG_CHANGE, 0);

    private List<ImageData> mImages = new ArrayList<>();
    private Object[] mParamsToJs;

    private boolean mIsAuto = true;
    private boolean mIsFirstInit = true;
    private int mInterval = DEFAULT_INTERVAL;

    public LynxUISliderImage(Context context, RenderObjectImpl impl) {
        super(context);
        linkElement(impl);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mImpl == null) {
            setMeasuredDimension(0,0);
            return;
        }
        setMeasuredDimension(
                mImpl.getPosition().mRight - mImpl.getPosition().mLeft,
                mImpl.getPosition().mBottom - mImpl.getPosition().mTop
        );
        int w = View.MeasureSpec.makeMeasureSpec(
                mImpl.getPosition().mRight - mImpl.getPosition().mLeft,
                MeasureSpec.EXACTLY);
        int h = View.MeasureSpec.makeMeasureSpec(
                mImpl.getPosition().mBottom - mImpl.getPosition().mTop,
                MeasureSpec.EXACTLY);
        super.onMeasure(w,h);
    }

    @Override
    public void insertChild(RenderObjectImpl child, int index) {

    }

    @Override
    public void removeChild(RenderObjectImpl child) {

    }

    @Override
    public void setText(String text) {

    }

    @Override
    public void setPosition(Position position) {

    }

    @Override
    public void setAttribute(String key, String value) {
        switch (key) {
            case "images":
                updateImages(value);
                break;
            case "auto":
                updateAuto(value);
                break;
            case "interval":
                updateInterval(value);
                break;
            default:
                Log.w("key:"+key,"value"+value);
                break;
        }
    }

    @Override
    public void updateStyle(Style style) {
        this.setupSliderView();
        setEvent();
    }

    @Override
    public void setSize(Size size) {

    }

    @Override
    public void addEventListener(String event) {
        switch (event) {
            case EVENT_TAG_CLICK:
                setOnItemClickListenerForThis();
                break;
            case EVENT_TAG_CHANGE:
                setOnPageChangeListenerForThis();
                break;
            default:
                break;
        }
    }


    private void setOnItemClickListenerForThis() {
    }

    private void removeItemClickListenerForThis() {
    }

    private void setOnPageChangeListenerForThis() {
        this.addOnPageChangeListener(createOnPageChangeListener());
    }
    private void removeOnPageChangeListenerForThis() {
        if (mOnPageChangeListener != null) {
            this.removeOnPageChangeListener(mOnPageChangeListener);
        }
    }

    private OnPageChangeListener createOnPageChangeListener() {
        if (mOnPageChangeListener == null) {
            mOnPageChangeListener = new ViewPager.SimpleOnPageChangeListener() {

                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                    // fix onPageSelected is not be called when viewpager first page init
                    if (mIsFirstInit && position == 0 && positionOffset == 0 && positionOffsetPixels == 0 && mAdapter.getActualChildCount() > 0){
                        onPageSelected(0);
                        mIsFirstInit = false;
                    }
                }

                @Override
                public void onPageSelected(int position) {
                    if (mImpl != null && mAdapter.getActualChildCount() != 0) {
                        int i = position % mAdapter.getActualChildCount();
                        mEventToJs.setIndex(i);
                        if (mParamsToJs == null) {
                            mParamsToJs = new Object[1];
                        }
                        mParamsToJs[0] = mEventToJs;
                        mImpl.dispatchEvent(EVENT_TAG_CHANGE, mParamsToJs);
                    }
                }
            };
        }
        return mOnPageChangeListener;
    }


    @Override
    public void removeEventListener(String event) {
        switch (event) {
            case EVENT_TAG_CLICK:
                removeItemClickListenerForThis();
                break;
            case EVENT_TAG_CHANGE:
                removeOnPageChangeListenerForThis();
                break;
            default:
                break;
        }
    }

    @Override
    public void setBaseAttr(int attr, Object param) {

    }



    @Override
    public void layoutView() {
        if (mImpl == null) {
            layout(0, 0, 0, 0);
        } else {
            layout(mImpl.getPosition().mLeft,
                    mImpl.getPosition().mTop,
                    mImpl.getPosition().mRight,
                    mImpl.getPosition().mBottom);
        }
    }

    @Override
    public void linkElement(RenderObjectImpl impl) {
        impl.setViewImpl(this);
        this.mImpl = impl;
        this.updateStyle(mImpl.getStyle());
        setEvent();
    }

    private void setEvent() {
        if (mImpl != null) {
            Iterator iterator = mImpl.getEvents().iterator();
            while (iterator.hasNext()) {
                addEventListener((String) iterator.next());
            }
        }
    }

    public void updateImages(@NonNull String images) {
        String[] imagesArray = images.split(",");
        setImages(imagesArray);

    }

    private void setImages(String[] array) {
        if (array == null || array.length == 0) {
            return;
        }
        try {
            mImages.clear();
            for(int i = 0,N=array.length; i < N; i++) {
                ImageData imageData = new ImageData();
                imageData.setImg(array[i]);
                mImages.add(imageData);
            }
            this.setData(mImages);
            //array.
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopSliderView() {
        mImages.clear();
        this.setData(mImages);
        this.stopPlay();
        this.disableAutoPlay();
    }

    private void updateAuto(String auto) {
        if(!TextUtils.isEmpty(auto)){
            mIsAuto = Boolean.valueOf(auto);
        }
        if (mIsAuto) {
            this.enableAutoPlay();
            this.startPlay();
        } else {
            this.disableAutoPlay();
            this.stopPlay();
        }
    }

    private void updateInterval(String value) {
        if (!TextUtils.isEmpty(value)) {
            mInterval = Integer.valueOf(value);
        }
        if (mInterval > 0) {
            this.setInterval(mInterval);
        }
    }

    private void setupSliderView() {
        String images = mImpl.getValue("images");
        if (!TextUtils.isEmpty(images)){
            updateImages(images);
        }
        String auto = mImpl.getValue("auto");
        String interval = mImpl.getValue("interval");
        updateInterval(interval);
        updateAuto(auto);

    }

    @Override
    public void separateElement() {
        this.mImpl.setViewImpl(null);
        this.mImpl = null;
        stopSliderView();

    }

    @Override
    public RenderObjectImpl getImpl() {
        return mImpl;
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopSliderView();
    }
}
