package com.lynx.core.tree;

import com.lynx.base.CalledByNative;
import com.lynx.base.FrameRateController;
import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by dli on 30/03/2017.
 */

public class LynxRenderTreeHostImpl implements FrameRateController.VSyncListener {

    private native void nativeUpdateViewport(long hostImpl, int width, int height);
    private native void nativeOnVSync(long hostImpl);
    private long mHostImpl;

    public RenderObjectImpl mRootRender;
    private LynxUIActionCollector mCollector = new LynxUIActionCollector();
    private LynxUIActionCollector mLastCollector = null;

    public LynxRenderTreeHostImpl(long hostImpl, RenderObjectImpl root) {
        mHostImpl = hostImpl;
        mRootRender = root;
    }

    @Override
    public void OnVSync() {
        nativeOnVSync(mHostImpl);
    }

    @CalledByNative
    public void beignFrame() {
        mLastCollector = mCollector;
        mCollector = new LynxUIActionCollector();
    }

    @CalledByNative
    public void prepareCommit() {
        if(mLastCollector != null && mLastCollector.needDoActions()) {
            mLastCollector.doActions();
        }
    }

    public void setRootView(LynxRenderImplInterface root) {
        mRootRender.setViewImpl(root);
    }

    public void updateViewport(int width, int height) {
        nativeUpdateViewport(mHostImpl, width, height);
    }

    @CalledByNative
    static LynxRenderTreeHostImpl create(long hostImpl, Object root) {
        return new LynxRenderTreeHostImpl(hostImpl, (RenderObjectImpl)(root));
    }
}
