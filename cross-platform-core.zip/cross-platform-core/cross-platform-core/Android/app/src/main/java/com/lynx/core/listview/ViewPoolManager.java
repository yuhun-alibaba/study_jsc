package com.lynx.core.listview;

import android.content.Context;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.LynxUIFactory;
import com.lynx.core.impl.RenderObjectImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by yxp on 17/01/31.
 * create and save views until the view pool has enough views for a whole screen to use
 */
public class ViewPoolManager {
    private static final int MAX_DELLOCATE_NUM = 3;
    private static final int MAX_CACHE_NUM = 1;

    private List<View> mCachedViews;
    // collect those View that on screen
    private SparseArray<View> mViewsOnScreen;
    // collect those View that outside screen and ready to be reused
    private Map<Integer, List<View>> mViewsOutsideScreenPool;

    private boolean mIsHiSpeed = false;
    private Context mContext;

    public ViewPoolManager(Context context) {
        mViewsOutsideScreenPool = new HashMap<>();
        mViewsOnScreen = new SparseArray<>();
        mCachedViews = new ArrayList<>();
        mContext = context;
    }

    public View getView(int position, RenderObjectImpl node, boolean isHiSpeed) {
        mIsHiSpeed = isHiSpeed;
        View view = createViewInternal(position, node);
        addViewToScreen(position, view);
        return view;
    }

    private View createViewInternal(int position, RenderObjectImpl impl) {
        if (impl.getViewImpl() != null) {
            View temp = (View) impl.getViewImpl();
            return temp;
        }

        View view;
        List<View> list = mViewsOutsideScreenPool.get(impl.getRenderObjectType());

        if (list == null || list.isEmpty()) {

            view = (View) LynxUIFactory.create(mContext, impl);

        } else {

            view = list.remove(list.size() - 1);
            // 当高速滑动的时候，禁止相关对象进行资源的加载
            // 当非高速滑动的时候，允许相关对象进行资源加载
            if (view instanceof HiSpeedStopLoadItem) {
                if (mIsHiSpeed) {
                    ((HiSpeedStopLoadItem) view).stopLoadResWhenViewInHiSpeed();
                } else {
                    ((HiSpeedStopLoadItem) view).allowLoadResWhenViewInHiSpeed();
                }
            }
            // bind data to view
            ((LynxRenderImplInterface) view).linkElement(impl);

        }

        impl.setViewImpl((LynxRenderImplInterface) view);

        // rebuild child view for the root node
        if (isContainer(view)) {
            buildViews(position, impl, (ViewGroup) view);
        }

        return view;
    }

    protected View buildViews(int position, RenderObjectImpl element, ViewGroup rootView) {
        for (int i = 0; i < element.getChildCount(); i++) {
            RenderObjectImpl child = element.getChildAt(i);
            View view = createViewInternal(position, child);
            if (view.getParent() != null) continue;
            rootView.addView(view);
        }

        return rootView;
    }

    private void addViewToScreen(int position, View view) {
        if (mCachedViews.contains(view)) {
            mCachedViews.remove(view);
        }
        mViewsOnScreen.put(position, view);
    }

    public void mvToCache(View view) {
        if (view == null) {
            return;
        }

        if (view.getParent() != null && view.getParent() instanceof AdapterView) {
            return;
        }

        int index = mViewsOnScreen.indexOfValue(view);

        if (index > 0) {
            mViewsOnScreen.removeAt(index);
        } else {
            return;
        }

        if (mCachedViews.contains(view)) {
            return;
        }

        mCachedViews.add(view);
        for (int i = 0; i < MAX_DELLOCATE_NUM; i++) {
            if (mCachedViews.size() >= MAX_CACHE_NUM) {
                mvViewsOnScreenToOutsidePool(mCachedViews.remove(0));
            } else {
                break;
            }
        }
    }

    private void mvViewsOnScreenToOutsidePool(View view) {
        if (view == null) {
            return;
        }
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                mvViewsOnScreenToOutsidePool(((ViewGroup) view).getChildAt(i));
            }
            if (view instanceof LynxRenderImplInterface) {
                ((ViewGroup) view).removeAllViews();
            }
        }
        if (view instanceof LynxRenderImplInterface && ((LynxRenderImplInterface) view).getImpl() != null) {
            // firstly get view's type
            int type = ((LynxRenderImplInterface) view).getImpl().getRenderObjectType();

            // unbind data from view
            ((LynxRenderImplInterface) view).separateElement();

            // add the view to pool
            List<View> list = mViewsOutsideScreenPool.get(type);
            if (list == null) {
                list = new ArrayList<>();
            }
            list.add(view);
            mViewsOutsideScreenPool.put(type, list);
        }
    }

    private boolean isContainer(View view) {
        return view instanceof ViewGroup;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("mViewOnScreen:\n");

        for (int i = 0; i < mViewsOnScreen.size(); i++) {
            builder.append("key,value=(" + mViewsOnScreen.keyAt(i) + "," + mViewsOnScreen.valueAt(i) + ")\n");
        }
        builder.append("\nmViewOutsideScreen:\n");

        return builder.toString();
    }

}
