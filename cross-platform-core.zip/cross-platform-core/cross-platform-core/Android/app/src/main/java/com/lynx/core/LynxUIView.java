package com.lynx.core;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.base.LynxEvent;
import com.lynx.core.impl.RenderObjectImpl;
import com.lynx.utils.RoundBackgroundUtil;
import com.lynx.utils.RoundCanvasClipper;

import java.util.List;

import static com.lynx.core.LynxUIFactory.UI_TYPE_CELLVIEW;

/**
 * Created by dli on 11/23/16.
 */
public class LynxUIView extends ViewGroup implements LynxRenderImplInterface {

    private final static String EVENT_TAG = "click";

    private RoundBackgroundUtil mRoundBackgroundUtil;

    protected RenderObjectImpl mImpl;

    private ViewOnClickListener mOnClickListener;

    public LynxUIView(Context context) {
        super(context);
        mRoundBackgroundUtil = new RoundBackgroundUtil();
    }

    public LynxUIView(Context context, RenderObjectImpl impl) {
        super(context);
        mRoundBackgroundUtil = new RoundBackgroundUtil();
        linkElement(impl);
    }

    @Override
    public void addEventListener(String event) {
        if(event.equalsIgnoreCase(EVENT_TAG)) {
            this.setClickable(true);
            mOnClickListener = new ViewOnClickListener();
            this.setOnClickListener(mOnClickListener);
        }
    }

    @Override
    public void removeEventListener(String event) {
        if(event.equalsIgnoreCase(EVENT_TAG)) {
            this.setOnClickListener(null);
            mOnClickListener = null;
            this.setClickable(false);
        }
    }

    @Override
    public void setBaseAttr(int attr, Object param) {

    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mImpl.getPosition() == null) {
            setMeasuredDimension(0, 0);
            return;
        }
        if(mImpl.getPosition().mBottom - mImpl.getPosition().mTop == 0
                && mImpl.getPosition().mRight - mImpl.getPosition().mLeft == 0) {
            int width = View.MeasureSpec.getSize(widthMeasureSpec);
            int height = View.MeasureSpec.getSize(heightMeasureSpec);
            setMeasuredDimension(width, height);
        } else {
            setMeasuredDimension(
                    mImpl.getPosition().mRight - mImpl.getPosition().mLeft,
                    mImpl.getPosition().mBottom - mImpl.getPosition().mTop
            );
        }
        for(int i = 0; i < getChildCount(); i++) {
            View view = getChildAt(i);
            view.measure(widthMeasureSpec, heightMeasureSpec);
        }
    }

    @Override
    protected void onLayout(boolean changed,
                            int l, int t, int r, int b) {
        for(int i = 0; i < getChildCount(); i++) {
            View view = getChildAt(i);
            ((LynxRenderImplInterface)view).layoutView();
        }
    }

    @Override
    public void updateStyle(Style style) {
        if(style == null || mImpl.getRenderObjectType() == UI_TYPE_CELLVIEW) return;
        this.setBackgroundColor(Color.TRANSPARENT);
        this.setAlpha((float) (style.mOpacity / 255f));
        mRoundBackgroundUtil.setDrawAttr(mImpl);
        postInvalidate();
    }

    @Override
    public void layoutView() {
        if(mImpl.getPosition() == null)
            return;
        super.layout(mImpl.getPosition().mLeft,
                mImpl.getPosition().mTop,
                mImpl.getPosition().mRight,
                mImpl.getPosition().mBottom);
    }

    @Override
    public void linkElement(RenderObjectImpl impl) {
        mImpl = impl;
        mImpl.setViewImpl(this);
        updateStyle(impl.getStyle());
        updateEvent(impl.getEvents());
    }

    public void updateEvent(List<String> events) {
        if (events != null) {
            for (String event : events) {
                addEventListener(event);
            }
        }
    }

    @Override
    public void separateElement() {
        mImpl.setViewImpl(null);
        mImpl = null;
        removeEventListener(EVENT_TAG);
    }

    @Override
    public RenderObjectImpl getImpl() {
        return mImpl;
    }

    @Override
    public void insertChild(RenderObjectImpl child, int index) {
        if (!child.hasViewImpl()) {
            attachChildElement(child);
        }
        View impl = (View) (child).getViewImpl();
        if (impl.getParent() != null) {
            ((ViewGroup) impl.getParent()).removeView(impl);
        }
        this.addView(impl, index);
    }

    @Override
    public void removeChild(RenderObjectImpl child) {
        if ((child).hasViewImpl()) {
            this.removeView((View) (child).getViewImpl());
        }
    }

    /**
     * Recursively create the child element's view and insert to their parent
     * @param childElement
     */
    public void attachChildElement(RenderObjectImpl childElement) {
        LynxRenderImplInterface ui = LynxUIFactory.create(getContext(), childElement);
        childElement.setViewImpl(ui);
        for (int i = 0; i < childElement.getChildCount(); i++) {
            ui.insertChild(childElement.getChildAt(i), i);
        }
    }

    @Override
    public void requestLayout() {
        super.requestLayout();
    }

    @Override
    public void setText(String text) {

    }

    @Override
    public void setPosition(Position position) {
        requestLayout();
    }

    @Override
    public void setSize(Size size) {

    }

    @Override
    public void setAttribute(String key, String value) {

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mImpl == null || mRoundBackgroundUtil == null) {
            return;
        }
        // 绘制背景
        mRoundBackgroundUtil.drawBackground(canvas);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {

        super.dispatchDraw(canvas);
        if (mImpl == null || mRoundBackgroundUtil == null) {
            return;
        }
        // 绘制边框
        mRoundBackgroundUtil.drawBorder(canvas);
    }

    @Override
    public void draw(Canvas canvas) {

        if (mImpl != null && mImpl.getStyle() != null && mImpl.getStyle().mBorderRadius > 0) {
            // 进行孩子的裁剪
            int count = canvas.saveLayer(0, 0, mImpl.getPosition().getWidth(), mImpl.getPosition().getHeight(), null, Canvas.HAS_ALPHA_LAYER_SAVE_FLAG);
            super.draw(canvas);
            RoundCanvasClipper.instance().clipRoundRectUseXfermode(canvas, mImpl);
            canvas.restoreToCount(count);
        } else {
            // 不裁剪孩子
            super.draw(canvas);
        }
    }

    public class ViewOnClickListener implements OnClickListener {
        @Override
        public void onClick(View v) {
            Object[] objects = new Object[1];
            LynxEvent event = new LynxEvent(EVENT_TAG);
            objects[0] = event;
            mImpl.dispatchEvent(EVENT_TAG, objects);
        }
    }
}
