// Copyright 2017 The Lynx Authors. All rights reserved.

package com.lynx.core.touch;


public class TouchAxis {
    public float x;
    public float y;
}
