package com.lynx.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by dli on 2017/7/6.
 */

public class RequestManager {
    private static RequestManager mInstance = null;
    private Map<Long, Map<String, RequestTask>> mManager;

    public RequestManager() {
        mManager = new HashMap<>();
    }

    public synchronized void AddTask(Long id, String url, RequestTask task) {
        Map<String, RequestTask> tasks = mManager.get(id);
        if(tasks == null) tasks = new HashMap<>();
        tasks.put(url, task);
        mManager.put(id, tasks);
    }

    public synchronized void RemoveTask(Long id, String url) {
        Map<String, RequestTask> tasks = mManager.get(id);
        if(tasks != null) {
            tasks.remove(url);
        }
    }

    public synchronized void CancelTasks(Long id) {
        Map<String, RequestTask> tasks = mManager.get(id);
        if(tasks == null || tasks.isEmpty()) return;
        Iterator<Map.Entry<String, RequestTask>> iter = tasks.entrySet().iterator();
        while(iter.hasNext()) {
            Map.Entry<String, RequestTask> entry = iter.next();
            entry.getValue().cancel(true);
        }
    }

    public static RequestManager GetInstance() {
        if(mInstance == null) {
            mInstance = new RequestManager();
        }
        return mInstance;
    }
}
