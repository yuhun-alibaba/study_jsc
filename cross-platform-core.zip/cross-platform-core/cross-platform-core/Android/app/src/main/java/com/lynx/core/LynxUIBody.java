package com.lynx.core;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.lynx.core.base.LynxEvent;
import com.lynx.core.impl.RenderObjectImpl;
import com.lynx.core.touch.TouchEventInfo;
import com.lynx.core.touch.TouchHandler;

/**
 * Created by yanxing on 17/7/15.
 */

public class LynxUIBody extends LynxUIView {

    private TouchHandler mTouchHandler;

    public LynxUIBody(Context context) {
        super(context);
        mTouchHandler = new TouchHandler(context);
    }


    @Override
    public void insertChild(RenderObjectImpl child, int i) {

        // Find the target index of thi child, and add to body view
        if (!child.hasViewImpl()) {
            attachChildElement(child);
        }

        // Remove self from parent
        View childView = (View) (child).getViewImpl();
        ViewGroup parent = (ViewGroup) childView.getParent();
        if(parent != null) {
            parent.removeView(childView);
        }

        // Find the target position to insert
        int curZIndex = child.getStyle() == null ? 0 : child.getStyle().mZIndex;
        int nearestZIndex = Integer.MAX_VALUE;
        RenderObjectImpl nearestItem = null;
        for (int j = 0; j < mImpl.getChildCount(); j++) {
            RenderObjectImpl renderObjectImpl = mImpl.getChildAt(j);
            if (renderObjectImpl == null) {
                continue;
            }
            int tempZIndex = renderObjectImpl.getStyle() == null ?
                    0 : renderObjectImpl.getStyle().mZIndex;
            if (tempZIndex > curZIndex) {
                if (nearestZIndex > tempZIndex) {
                    nearestZIndex = tempZIndex;
                    nearestItem = renderObjectImpl;
                }
            }
        }

        if (nearestItem != null) {
            int index = this.indexOfChild((View) nearestItem.getViewImpl());
            this.addView(childView, index);
        } else {
            if (i < 0) {
                i = mImpl.getChildCount() - 1;
            }
            this.addView(childView, i);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (mImpl != null) {
            // Handle motion event
            TouchEventInfo info = mTouchHandler.handleMotionEvent(ev);
            // Pass to RenderObject
            Object[] params = new Object[1];
            params[0] = info;
            mImpl.dispatchEvent(info.getTouchEventType(), params);
            // Reset
            mTouchHandler.reset();
        }
        super.dispatchTouchEvent(ev);
        // Always return true so that get touch event successively
        return true;
    }
}
