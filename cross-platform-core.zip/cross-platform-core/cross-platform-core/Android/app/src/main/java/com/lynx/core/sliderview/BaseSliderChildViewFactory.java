package com.lynx.core.sliderview;

import android.view.View;
import android.view.ViewGroup;

import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by Monster on 2017/3/14.
 */

public abstract class BaseSliderChildViewFactory {
    protected static final int ENABLE_RECYCLE_NUM = 5;

    protected PagerRecyclerBin mRecyclerBin;

    protected boolean mNotUseRecycler = false;

    public BaseSliderChildViewFactory() {
        mRecyclerBin = new PagerRecyclerBin();
        mRecyclerBin.enableRecycle(true);
    }

    public void appendChild(int index, RenderObjectImpl child) {

    }

    public RenderObjectImpl removeChild(int index) {
        return null;
    }

    /**
     * 与{@link SliderViewPagerAdapter#instantiateItem(ViewGroup, int)} 同步使用
     * @param position
     * @return
     */
    public View createView(int position) {
        View view = mNotUseRecycler ? null : mRecyclerBin.obtainView(position);

        if (view == null) {
            view = makeView(position % getChildCount());
        } else {
            reBindData(view);
        }

        if (!mNotUseRecycler) mRecyclerBin.addDisplayView(position, view);
        return view;
    }

    /**
     * 真正创建view的方法,需要复写
     * @param position
     * @return
     */
    public abstract View makeView(int position);

    /**
     * 提供重新绑定数据的方法
     * @param position
     * @return
     */
    public abstract void reBindData(View position);

    /**
     * 与{@link SliderViewPagerAdapter#destroyItem(ViewGroup, int, Object)} 同步使用
     * @param position
     * @return
     */
    public View removeView(int position) {
        return mNotUseRecycler ? null : mRecyclerBin.removeDisplayView(position);
    }

    public abstract int getChildCount();

    public boolean getNeedToFlush() {
        return false;
    }

    /**
     * 完全禁止回收功能
     */
    public void notUseRecycler() {
        mNotUseRecycler = true;
    }
}
