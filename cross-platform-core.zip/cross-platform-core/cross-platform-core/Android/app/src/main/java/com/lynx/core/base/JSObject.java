package com.lynx.core.base;

import android.support.annotation.Keep;

import com.lynx.core.base.JSArray;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by dli on 28/02/2017.
 */

public class JSObject {
    // jni use
    private JSArray mProperties;
    // for java use
    private Map<Object, Object> mPropertiesMap;

    public JSObject() {
        mPropertiesMap = new HashMap<>();
    }

    // for jni use
    @Keep
    private void setProperties(JSArray properties) {
        mProperties = properties;
        for (int i = 0; i < mProperties.length(); i += 2) {
            mPropertiesMap.put(mProperties.get(i), mProperties.get(i + 1));
        }
    }

    // for jni use
    @Keep
    private JSArray getProperties() {
        return mProperties;
    }

    public Object getProperty(Object key) {
        return mPropertiesMap.get(key);
    }

    public void setProperty(Object key, Object value) {
        mPropertiesMap.put(key, value);
        if (mProperties == null) {
            mProperties = new JSArray();
        }
        mProperties.add(key);
        mProperties.add(value);
    }

}
