package com.lynx.base;

/**
 * Created by dli on 3/19/16.
 */
public class Constants {

    public static final int UNDEFINED = 0x7FFFFFFF;

    public static boolean isUndefined(int value) {
        return value == UNDEFINED;
    }
}
