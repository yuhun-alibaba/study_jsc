package com.lynx.base;

/**
 * Created by dli on 28/02/2017.
 */

public @interface JNINamespace {
    public String value();
}
