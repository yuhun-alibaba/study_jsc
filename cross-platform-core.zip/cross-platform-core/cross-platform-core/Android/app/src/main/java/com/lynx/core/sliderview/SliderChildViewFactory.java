package com.lynx.core.sliderview;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.lynx.core.LynxUIFactory;
import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.impl.RenderObjectImpl;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yanxing on 16/11/3.
 */

public class SliderChildViewFactory extends BaseSliderChildViewFactory {

    private List<RenderObjectImpl> mShadowNodes;

    private boolean needToFlushAdd = false;
    private boolean needToFlushRemove = false;

    private int mChangeIndex;
    protected Context mContext;

    public SliderChildViewFactory(Context context) {
        mShadowNodes = new ArrayList<>();
        this.mContext = context;
    }

    @Override
    public void appendChild(int index, RenderObjectImpl child) {
        needToFlushAdd = false;
        mShadowNodes.add(index, child);

        if (index != mShadowNodes.size() - 1) {
            // 刷新Recycler里面的数组
            needToFlushAdd = true;
            mChangeIndex = index;
        }
    }

    @Override
    public RenderObjectImpl removeChild(int index) {
        needToFlushRemove = false;
        RenderObjectImpl removed = mShadowNodes.remove(index);
        if (removed == null) {
            return null;
        }

        // 刷新Recycler里面的数组
        needToFlushRemove = true;
        mChangeIndex = index;
        return removed;
    }

    @Override
    public View createView(int position) {

        flushRecyclerBin();

        return super.createView(position);
    }

    @Override
    public View makeView(int position) {
        return buildNodeView(position);
    }

    @Override
    public void reBindData(View position) {
    }

    @Override
    public View removeView(int position) {
        return super.removeView(position);
    }

    protected void flushRecyclerBin() {

        if (needToFlushAdd) {
            mRecyclerBin.flushWhenAddChild(mChangeIndex, mShadowNodes.size());
            needToFlushAdd = false;
        }

        if (needToFlushRemove) {
            mRecyclerBin.flushWhenRemoveChild(mChangeIndex, mShadowNodes.size());
            needToFlushRemove = false;
        }
    }

    @Override
    public int getChildCount() {
        return mShadowNodes.size();
    }

    @Override
    public boolean getNeedToFlush() {
        return needToFlushAdd || needToFlushRemove;
    }

    protected View buildNodeView(int position) {

        RenderObjectImpl node = mShadowNodes.get(position);

        buildChildNodeView(null, node);

        return (View) node.getViewImpl();
    }

    private void buildChildNodeView(RenderObjectImpl parent, RenderObjectImpl node) {

        int type = node.getRenderObjectType();

        View view = mRecyclerBin.getDeallocatedView(type);

        if (view != null) {
            ((LynxRenderImplInterface) view).separateElement();
        } else {
            view = (View) LynxUIFactory.create(mContext,node);
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            buildChildNodeView(node, node.getChildAt(i));
        }

        if (parent != null && parent.getViewImpl() != null) {
            ((ViewGroup)parent.getViewImpl()).addView(view);
        }
    }
}
