package com.lynx.base;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by dli on 2017/7/6.
 */

class RequestTask extends AsyncTask<String, Object, String> {
    private URLRequest.Listener callBack;
    private String url;

    public RequestTask(String url, URLRequest.Listener callBack) {
        this.callBack = callBack;
        this.url = url;
    }

    @Override
    protected String doInBackground(String... params) {
        HttpURLConnection connection = initUrlConnection(url);
        return readStream(connection);
    }

    @Override
    protected void onPostExecute(String response) {
        callBack.onResponse(response);
    }

    @Override
    protected void onCancelled() {
        callBack.onCancel();
    }

    private HttpURLConnection initUrlConnection(String urlstr) {
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlstr);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setConnectTimeout(5 * 1000);
            urlConnection.setRequestMethod("GET");
            urlConnection.setRequestProperty("Content-type", "text/json");
            urlConnection.setRequestProperty("Accept-Charset", "utf-8");
            urlConnection.setRequestProperty("contentType", "utf-8");
            urlConnection.setUseCaches(true);
            return urlConnection;
        } catch (Exception e) {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            e.printStackTrace();
            return null;
        }
    }

    private String readStream(HttpURLConnection urlConnection) {
        InputStream in = null;
        BufferedReader bufferedReader = null;
        try {
            in = urlConnection.getInputStream();
            if (in != null) {
                InputStreamReader inr = new InputStreamReader(in, "UTF-8");
                bufferedReader = new BufferedReader(inr);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                return sb.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return "";
    }

}
