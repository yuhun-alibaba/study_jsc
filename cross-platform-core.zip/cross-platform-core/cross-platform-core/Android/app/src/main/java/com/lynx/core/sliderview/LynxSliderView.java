package com.lynx.core.sliderview;

import android.content.Context;

import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by Monster on 2017/3/20.
 */

public class LynxSliderView extends SliderView implements LynxRenderImplInterface {

    private static final String PAGE_CHANGE_EVENT = "change";

    private RenderObjectImpl mImpl;

    private OnPageChangeListener mOnPageChangeListener;

    public LynxSliderView(Context context, RenderObjectImpl impl) {
        super(context);
        linkElement(impl);
    }


    @Override
    public void insertChild(RenderObjectImpl child, int index) {
        mAdapter.appendChild(index, child);
        notifyDataSetChange();
        if (mIsAutoPlay && mImpl.getChildCount() > 1 && !mLooperController.isStart()) {
            mLooperController.start();
        }
    }

    @Override
    public void removeChild(RenderObjectImpl child) {
    }

    @Override
    public void setText(String text) {

    }

    @Override
    public void setPosition(Position position) {

    }

    @Override
    public void setAttribute(String key, String value) {

    }

    @Override
    public void updateStyle(Style style) {

    }

    @Override
    public void setSize(Size size) {

    }

    @Override
    public void addEventListener(String event) {
        if (PAGE_CHANGE_EVENT.equals(event)) {
            this.addOnPageChangeListener(mOnPageChangeListener);
        }
    }

    @Override
    public void removeEventListener(String event) {
        if (PAGE_CHANGE_EVENT.equals(event)) {
            this.removeOnPageChangeListener(mOnPageChangeListener);
        }
    }

    @Override
    public void setBaseAttr(int attr, Object param) {

    }

    @Override
    public void layoutView() {
        if (mImpl == null) {
            super.layout(0, 0, 0, 0);
        } else {
            super.layout(mImpl.getPosition().mLeft,
                    mImpl.getPosition().mTop,
                    mImpl.getPosition().mRight,
                    mImpl.getPosition().mBottom);
        }
    }

    @Override
    public void linkElement(RenderObjectImpl impl) {
        this.mImpl = impl;
        impl.setViewImpl(this);
        this.addOnPageChangeListener(mOnPageChangeListener);
    }

    @Override
    public void separateElement() {
        mImpl.setViewImpl(null);
        mImpl = null;
        this.removeOnPageChangeListener(mOnPageChangeListener);
    }

    @Override
    public RenderObjectImpl getImpl() {
        return mImpl;
    }

    @Override
    public SliderViewPagerAdapter createSliderViewPagerAdapter() {
        return new SliderViewPagerAdapter(getContext());
    }

    @Override
    public SliderViewLooperController createLooperController() {
        return new SliderViewLooperController(this);
    }

    class OnSliderViewPageChangeListener implements OnPageChangeListener {

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {

        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    }
}
