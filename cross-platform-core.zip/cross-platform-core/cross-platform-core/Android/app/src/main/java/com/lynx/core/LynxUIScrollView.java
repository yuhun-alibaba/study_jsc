package com.lynx.core;

import android.content.Context;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.impl.RenderObjectAttr;
import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by yxp on 17/1/22.
 */

public class LynxUIScrollView extends ScrollView implements LynxRenderImplInterface {
    private RenderObjectImpl mImpl;
    private LinearLayout mLinearLayout;
    private boolean isLinearLayoutExist = false;
    private boolean isHorizontal = false;
    private HorizontalScrollView mHorizontalScrollView;

    public LynxUIScrollView(Context context, RenderObjectImpl renderObject) {
        super(context);
        init();
        linkElement(renderObject);
    }

    protected void init() {
        this.setHorizontalScrollBarEnabled(false);
    }

    @Override
    public void addEventListener(String event) {

    }

    @Override
    public void removeEventListener(String event) {

    }

    @Override
    public void setBaseAttr(int attr, Object param) {
        if (attr == RenderObjectAttr.SCROLL_LEFT.value()) {
            setScrollTo((Integer) param, 0, true);
        }
    }

    @Override
    public void addView(View child) {
        if (isLinearLayoutExist) {
            mLinearLayout.addView(child);
        } else {
            super.addView(child);
            isLinearLayoutExist = true;
        }
    }

    @Override
    public void addView(View child, int index) {
        if (isLinearLayoutExist) {
            mLinearLayout.addView(child, index);
        } else {
            super.addView(child, index);
            isLinearLayoutExist = true;
        }
    }

    @Override
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        if (isLinearLayoutExist) {
            mLinearLayout.addView(child, index, params);
        } else {
            super.addView(child, index, params);
            isLinearLayoutExist = true;
        }
    }

    @Override
    public void addView(View child, ViewGroup.LayoutParams params) {
        if (isLinearLayoutExist) {
            mLinearLayout.addView(child, params);
        } else {
            super.addView(child, params);
            isLinearLayoutExist = true;
        }
    }

    @Override
    public void addView(View child, int width, int height) {
        if (isLinearLayoutExist) {
            mLinearLayout.addView(child, width, height);
        } else {
            super.addView(child, width, height);
            isLinearLayoutExist = true;
        }
    }

    @Override
    public void removeView(View view) {
        if (isLinearLayoutExist) {
            mLinearLayout.removeView(view);
        } else {
            super.removeView(view);
        }
    }

    @Override
    public void removeViewAt(int index) {
        if (isLinearLayoutExist) {
            mLinearLayout.removeViewAt(index);
        } else {
            super.removeViewAt(index);
        }
    }

    @Override
    public void removeAllViews() {
        if (isLinearLayoutExist) {
            mLinearLayout.removeAllViews();
        } else {
            super.removeAllViews();
        }
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        mImpl.syncBaseAttr(RenderObjectAttr.SCROLL_TOP, this.getScrollY());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        super.onTouchEvent(event);
        return true;
    }

    public void setScrollTo(final int x, final int y, final boolean animate) {
        if (animate) {
            if (isHorizontal) {
                mHorizontalScrollView.smoothScrollTo(x, y);
            } else {
                this.smoothScrollTo(x, y);
            }
        } else {
            if (isHorizontal) {
                mHorizontalScrollView.scrollTo(x, y);
            } else {
                this.scrollTo(x, y);
            }
        }
    }

    private void createInnerComponent() {
        mLinearLayout = new LinearLayout(this.getContext()) {

            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                if (isHorizontal) {
                    int width = 0;
                    for(int i = 0; i < mImpl.getChildCount(); i++) {
                        width += mImpl.getChildAt(i).getPosition().getWidth();
                    }
                    setMeasuredDimension(width, mImpl.getPosition().mBottom - mImpl.getPosition().mTop);
                } else {
                    int height = 0;
                    for(int i = 0; i < mImpl.getChildCount(); i++) {
                        height += mImpl.getChildAt(i).getPosition().getHeight();
                    }
                    setMeasuredDimension(mImpl.getPosition().mRight - mImpl.getPosition().mLeft, height);
                }
            }

            @Override
            protected void onLayout(boolean changed, int l, int t, int r, int b) {
                for(int i = 0; i < getChildCount(); i++) {
                    View view = getChildAt(i);
                    ((LynxRenderImplInterface)view).layoutView();
                }
            }

        };
        mLinearLayout.setOrientation(LinearLayout.VERTICAL);
        mLinearLayout.setBackgroundColor(Color.TRANSPARENT);
    }

    private void createInnerScrollView() {
        mHorizontalScrollView = new HorizontalScrollView(this.getContext()) {

            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                if (isHorizontal) {
                    setMeasuredDimension(mImpl.getPosition().getWidth(), mImpl.getPosition().getHeight());
                } else {
                    int height = 0;
                    for(int i = 0; i < mImpl.getChildCount(); i++) {
                        height += mImpl.getChildAt(i).getPosition().getHeight();
                    }
                    setMeasuredDimension(mImpl.getPosition().mRight - mImpl.getPosition().mLeft, height);
                }
            }

            @Override
            public boolean onTouchEvent(MotionEvent ev) {
                if (isHorizontal) {
                    super.onTouchEvent(ev);
                    return true;
                } else {
                    return false;
                }
            }

            @Override
            protected void onScrollChanged(int l, int t, int oldl, int oldt) {
                super.onScrollChanged(l, t, oldl, oldt);

                mImpl.syncBaseAttr(RenderObjectAttr.SCROLL_LEFT, this.getScrollX());
            }
        };
        mHorizontalScrollView.setHorizontalScrollBarEnabled(false);
        mHorizontalScrollView.setBackgroundColor(Color.TRANSPARENT);
    }

    private void createInternalLinearLayout() {
        if (mLinearLayout == null) {
            createInnerComponent();
            createInnerScrollView();
            mHorizontalScrollView.addView(mLinearLayout);
            this.addView(mHorizontalScrollView);
        }
    }

    @Override
    public void layoutView() {
        if (mImpl == null) {
            layout(0, 0, 0, 0);
        } else {
            layout(mImpl.getPosition().mLeft,
                    mImpl.getPosition().mTop,
                    mImpl.getPosition().mRight,
                    mImpl.getPosition().mBottom);
        }
    }

    @Override
    public void linkElement(RenderObjectImpl impl) {
        mImpl = impl;
        mImpl.setViewImpl(this);
        createInternalLinearLayout();
        updateStyle(impl.getStyle());
    }

    @Override
    public void separateElement() {
        mImpl.setViewImpl(null);
        mImpl = null;
    }

    @Override
    public RenderObjectImpl getImpl() {
        return mImpl;
    }

    @Override
    public void insertChild(RenderObjectImpl child, int index) {
        if (!child.hasViewImpl()) {
            attachChildElement(child);
        }
        this.addView((View) ((RenderObjectImpl)child).getViewImpl(), index);
    }

    @Override
    public void removeChild(RenderObjectImpl child) {
        if (child.hasViewImpl()) {
            this.removeView((View) child.getViewImpl());
        }
    }

    /**
     * Recursively creat the child element's view and insert to their parent
     * @param childElement
     */
    public void attachChildElement(RenderObjectImpl childElement) {
        LynxRenderImplInterface ui = LynxUIFactory.create(getContext(), childElement);
        childElement.setViewImpl(ui);
        for (int i = 0; i < childElement.getChildCount(); i++) {
            ui.insertChild(childElement.getChildAt(i), i);
        }
    }

    @Override
    public void setText(String text) {

    }

    @Override
    public void setPosition(Position position) {
        requestLayout();
    }

    @Override
    public void setAttribute(String key, String value) {

    }

    @Override
    public void updateStyle(Style style) {
        if (style != null) {
            this.setBackgroundColor(style.mBackgroundColor);
            this.getBackground().setAlpha((int) style.mOpacity);
            if (mImpl.getStyle().mFlexDirection == Style.CSSFLEX_DIRECTION_ROW) {
                mLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
                isHorizontal = true;
            }
            if (mImpl.getStyle().mFlexDirection == Style.CSSFLEX_DIRECTION_COLUMN) {
                mLinearLayout.setOrientation(LinearLayout.VERTICAL);
                isHorizontal = false;
            }
            this.requestLayout();
        }
    }

    @Override
    public void setSize(Size size) {

    }
}
