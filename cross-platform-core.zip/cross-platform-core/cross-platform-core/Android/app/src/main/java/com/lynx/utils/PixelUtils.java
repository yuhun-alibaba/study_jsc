package com.lynx.utils;

import com.lynx.base.Style;

/**
 * Created by dli on 6/16/16.
 */
public class PixelUtils {

    public static int toSPFromPixel(double value) {
        return (int)(value / Style.mDensity + 0.5);
    }

    public static int toPixelFromSP(double value) {
        return (int)(value * Style.mDensity + 1.0);
    }
}
