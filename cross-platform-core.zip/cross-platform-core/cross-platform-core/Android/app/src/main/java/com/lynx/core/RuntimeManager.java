package com.lynx.core;

/**
 * Created by dli on 11/05/2017.
 */

public class RuntimeManager {

    private static boolean mInited = false;

    private static JSRuntime mIdleRuntime = null;

    private static boolean mEnableMemoryCheck = false;

    public static synchronized void initialize() {
        if(mEnableMemoryCheck) return;
        mIdleRuntime = new JSRuntime();
        mIdleRuntime.initialize();
        mInited = true;
    }

    public static synchronized JSRuntime getIdleRuntime() {
        if(mEnableMemoryCheck) {
            mIdleRuntime = new JSRuntime();
            mIdleRuntime.initialize();
            return mIdleRuntime;
        }else {
            if (!mInited) initialize();
            JSRuntime runtime = mIdleRuntime;
            mIdleRuntime = new JSRuntime();
            mIdleRuntime.initialize();
            return runtime;
        }
    }

    static {
        System.loadLibrary("lynx");
    }
}
