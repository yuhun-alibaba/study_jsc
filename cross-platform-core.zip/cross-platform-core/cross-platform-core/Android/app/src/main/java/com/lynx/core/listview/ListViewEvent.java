package com.lynx.core.listview;

import com.lynx.core.base.LynxEvent;

/**
 * Created by dli on 28/02/2017.
 */

public class ListViewEvent extends LynxEvent {
    public String type;
    public int index;
    public int scrollHeight;
    public int offsetHeight;
    public int scrollTop;

    public ListViewEvent(String type, int index, int scrollHeight,
                         int offsetHeight, int scrollTop) {
        super(type);
        this.type = type;
        this.index = index;
        this.scrollHeight = scrollHeight;
        this.offsetHeight = offsetHeight;
        this.scrollTop = scrollTop;
    }

    public void updateValue(int scrollHeight, int offsetHeight, int scrollTop) {
        this.scrollHeight = scrollHeight;
        this.offsetHeight = offsetHeight;
        this.scrollTop = scrollTop;
    }

    public String getType() {
        return type;
    }
    
    public int getIndex() {
        return index;
    }
}
