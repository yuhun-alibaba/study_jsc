package com.lynx.core.tree;

/**
 * Created by dli on 30/03/2017.
 */

public enum LynxUIActionType {
    DO_EVENT_NONe,
    DO_EVENT_ACTION,
    DO_SYNC_ATTR_ACTION,
}
