package com.lynx.core.listview;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;

import com.lynx.core.LynxUIFactory;
import com.lynx.core.impl.RenderObjectImpl;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yxp on 17/01/31.
 */

public class LynxUIListViewAdapter extends BaseAdapter {
    private List<ChildView> mChildViews;
    private ViewPoolManager mViewPoolManager;
    private List<RenderObjectImpl> mProxyList;

    private int mCurTop = 0;
    private int mCurBottom = 0;
    private int mPreFirstItem = -1;
    // 前一个scrollChange事件触发时间
    private long mPreviousEventTime = 0;
    // 当前滑动速度（当前1s内滑动多少个iterm)
    private int mScrollSpeed = 0;
    // 在一个页面内最多同时展示的Item个数
    private int mMaxShowItemCounts = 0;
    // 基准判断的最多同时展示item个数
    private final static double STANDARD_MAX_SHOW_ITEM = 3d;
    // 页面内最多同时展示的item个数与基准的比例
    private double mMaxShowItemRatio = 1d;
    // 速度阈值，当超过了这个阈值，则不进行资源的加载
    private final static int SPEED_THRESHOLD = 25;
    // 判断是否是高速滑动状态
    private boolean mIsHiSpeed = false;


    public LynxUIListViewAdapter(Context context) {
        mViewPoolManager = new ViewPoolManager(context);
        mProxyList = new ArrayList<>();
        mChildViews = new ArrayList<>();
    }

    public void appendChildAt(RenderObjectImpl node, int index) {
        if (index < 0) {
            mProxyList.add(node);
        } else {
            mProxyList.add(index, node);
        }
        notifyDataSetChanged();
    }

    public RenderObjectImpl removeChildByIndex(int index) {
        RenderObjectImpl node = mProxyList.remove(index);
        notifyDataSetChanged();
        return node;
    }

    public void removeChild(RenderObjectImpl node) {
        mProxyList.remove(node);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ChildView childView = mChildViews.get(position);

        if (childView.getState() == State.Immutable && childView.getImpl().getViewImpl() != null) {
            return (View) childView.getImpl().getViewImpl();
        }

        convertView = mViewPoolManager.getView(position, childView.getImpl(), mIsHiSpeed);

        return convertView;
    }

    /**
     * 将超出屏幕外的view进行回收
     */
    protected void addToRecyclerIfCan() {

        for (int i = 0; i < mChildViews.size(); i++) {

            ChildView child = mChildViews.get(i);

            if (child.getState() == State.Immutable) {
                continue;
            }

            View childView = (View) child.getImpl().getViewImpl();
            if (childView == null) {
                continue;
            }

            int childActualTop = child.getTop();
            int childActualBottom = child.getBottom();
            if ((childActualBottom >= mCurTop && childActualTop <= mCurTop)
                    || (childActualBottom <= mCurBottom && childActualTop >= mCurTop)
                    || (childActualBottom >= mCurBottom && childActualTop <= mCurBottom)) {
                continue;
            }

            mViewPoolManager.mvToCache(childView);
        }
    }

    public void setChildViewPosition() {
        int scrollY = 0;
        for (int i = 0; i < mChildViews.size(); ++i) {
            RenderObjectImpl child = getElement(i);
            if (child != null) {
                mChildViews.get(i).setScrollY(scrollY);
                scrollY += child.getPosition().getHeight();
            }
        }
    }

    @Override
    public void notifyDataSetChanged() {
        // 当有新的孩子加入，则首先重置所有的属性
        resetSpeed();
        resetChildCount();
        super.notifyDataSetChanged();
    }

    private void resetChildCount() {
        mChildViews.clear();
        for(int i = 0; i < mProxyList.size(); i++) {
            RenderObjectImpl node = mProxyList.get(i);
            if(node.getRenderObjectType() == LynxUIFactory.UI_TYPE_LIST_SHADOW) {
                for (int j = 0; j < node.getChildCount(); j++) {
                    mChildViews.add(new ChildView(node.getChildAt(j), State.Mercurial));
                }
            }else{
                mChildViews.add(new ChildView(node, State.Immutable));
            }
        }
    }

    /**
     * 重置滑动速度
     */
    private void resetSpeed() {
        mScrollSpeed = 0;
        mIsHiSpeed = false;
    }

    /**
     * 强制加载正在展示的item的图片
     */
    public void forceInvalidate() {
        resetSpeed();
        int maxCount = 0;
        for (int i = 0; i < mChildViews.size(); i++) {

            ChildView child = mChildViews.get(i);

            if (child.getState() == State.Immutable) {
                continue;
            }

            View childView = (View) child.getImpl().getViewImpl();
            if (childView == null) {
                continue;
            }
            maxCount++;
            reloadItemRes(child.getImpl());
        }
        mMaxShowItemCounts = Math.max(mMaxShowItemCounts, maxCount);
        mMaxShowItemRatio = mMaxShowItemCounts / STANDARD_MAX_SHOW_ITEM;
    }

    /**
     * 对象进行重新加载资源
     * @param node
     */
    protected void reloadItemRes(RenderObjectImpl node) {

        for (int i = 0; i < node.getChildCount(); i++) {
            RenderObjectImpl child = node.getChildAt(i);
            View view = (View) child.getViewImpl();

            if (view instanceof HiSpeedStopLoadItem) {
                ((HiSpeedStopLoadItem) view).reloadResWhenSuitable();
            }

            if (view instanceof ViewGroup) {
                reloadItemRes(child);
            }
        }

    }

    public void onScrollItemChange(int scrollState) {
        // 在listview停止的时候进行资源的重新加载
        if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
            forceInvalidate();
        }
    }

    public void onScrollItemChange(int curFirstItem, int visibleItem) {

        if (curFirstItem == mPreFirstItem) {
            return;
        }
        // 计算滑动时1s时间内滑动了多少个item
        calculateCurSpeed(curFirstItem);

        mPreFirstItem = curFirstItem;
        setChildViewPosition();
        mCurTop = mChildViews.get(curFirstItem).getTop();
        int mLastItem = curFirstItem + visibleItem - 1;
        if (mLastItem < 0) {
            return;
        }
        mCurBottom = mChildViews.get(mLastItem).getBottom();
        addToRecyclerIfCan();
    }

    /**
     * 计算当前滑动的速度，并判断是否是高速状态
     * @param curFirstItem
     */
    public void calculateCurSpeed(int curFirstItem) {
        if (mPreFirstItem != curFirstItem && mMaxShowItemCounts != 0){
            long currTime = System.currentTimeMillis();
            long timeToScrollOneElement = currTime - mPreviousEventTime;
            if (timeToScrollOneElement == 0) {
                timeToScrollOneElement = 1;
            }
            if (mMaxShowItemRatio == 0) {
                mMaxShowItemRatio = 1d;
            }
            mScrollSpeed = (int) ((1000 / timeToScrollOneElement) / mMaxShowItemRatio);
            mPreFirstItem = curFirstItem;
            mPreviousEventTime = currTime;
            mIsHiSpeed = (mScrollSpeed >= SPEED_THRESHOLD);
        }
    }

    @Override
    public int getCount() {
        return mChildViews.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    protected RenderObjectImpl getElement(int position) {
        if (position >= mChildViews.size() || position < 0) {
            return null;
        }
        return mChildViews.get(position).getImpl();
    }

    public List<RenderObjectImpl> getProxyList() {
        return mProxyList;
    }

    @Override
    public int getItemViewType(int position) {
        return AdapterView.ITEM_VIEW_TYPE_HEADER_OR_FOOTER;
    }

    enum State {
        Immutable,
        Mercurial
    }

    class ChildView {

        private State state = State.Immutable;
        private RenderObjectImpl mImpl;
        private int scrollY = 0;
        private int top = scrollY;
        private int bottom = scrollY;

        public ChildView(RenderObjectImpl impl, State state) {
            this.mImpl = impl;
            this.state = state;
        }

        public RenderObjectImpl getImpl() {
            return mImpl;
        }

        public State getState() {
            return state;
        }

        public void setScrollY(int scrollY) {
            this.scrollY = scrollY;
            this.top = this.scrollY;
            this.bottom = this.scrollY + mImpl.getPosition().getHeight();
        }

        public int getTop() {
            return top;
        }

        public int getBottom() {
            return bottom;
        }
    }
}
