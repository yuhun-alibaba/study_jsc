package com.lynx.core;

import android.content.Context;

import com.lynx.core.input.LynxUIInput;
import com.lynx.core.listview.LynxUIListView;
import com.lynx.core.impl.RenderObjectImpl;
import com.lynx.core.sliderimage.LynxUISliderImage;

/**
 * Created by dli on 11/23/16.
 */
public class LynxUIFactory {

    public final static int UI_TYPE_VIEW = 1;
    public final static int UI_TYPE_LABEL = 2;
    public final static int  UI_TYPE_LISTVIEW = 3;
    public final static int  UI_TYPE_CELLVIEW= 4;
    public final static int  UI_TYPE_LIST_SHADOW = 5;
    public final static int UI_TYPE_IMAGE = 6;
    public final static int UI_TYPE_SCROLLVIEW = 7;
    public final static int UI_TYPE_INPUT = 8;
    public final static int UI_TYPE_SLIDE_IMAGE = 9;
    public final static int UI_TYPE_SLIDE_VIEW = 10;

    public static LynxRenderImplInterface create(Context context, RenderObjectImpl impl) {
        LynxRenderImplInterface ui = null;

        switch (impl.getRenderObjectType()) {
            case UI_TYPE_VIEW:
            case UI_TYPE_CELLVIEW:
            case UI_TYPE_LIST_SHADOW:
                ui = new LynxUIView(context, impl);
                break;
            case UI_TYPE_LABEL:
                ui = new LynxUILabel(context, impl);
                break;
            case UI_TYPE_IMAGE:
                ui = new LynxUIImage(context, impl);
                break;
            case UI_TYPE_LISTVIEW:
                ui = new LynxUIListView(context, impl);
                break;
            case UI_TYPE_SCROLLVIEW:
                ui = new LynxUIScrollView(context, impl);
                break;
            case UI_TYPE_INPUT:
                ui = new LynxUIInput(context, impl);
                break;
            case UI_TYPE_SLIDE_IMAGE:
                ui = new LynxUISliderImage(context, impl);
                break;
            case UI_TYPE_SLIDE_VIEW:
                ui = new LynxUISliderImage(context, impl);
                break;
            default:
                break;
        }
        return ui;
    }

}
