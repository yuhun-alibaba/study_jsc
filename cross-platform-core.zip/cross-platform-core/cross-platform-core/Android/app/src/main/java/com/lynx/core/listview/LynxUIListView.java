package com.lynx.core.listview;

import android.content.Context;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ListView;

import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.impl.RenderObjectAttr;
import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by yxp on 17/01/31.
 */

public class LynxUIListView extends ListView implements LynxRenderImplInterface {
    public final static String SCROLL_EVENT_TAG = "scroll";

    private RenderObjectImpl mImpl;
    private LynxUIListViewAdapter mAdapter;
    private int mListViewHeight = Integer.MAX_VALUE;

    private int mLastScrollHeight = 0;
    private int mLastOffsetHeight = 0;
    private int mLastScrollTop = 0;

    private ListViewEvent mScrollEventToJs = new ListViewEvent(SCROLL_EVENT_TAG, 0,
            0, 0, 0);
    private Object[] mParamsToJs;
    private boolean isAllowToSendScrollEvent = false;

    public LynxUIListView(Context context, RenderObjectImpl impl) {
        super(context);
        mAdapter = new LynxUIListViewAdapter(context);
        linkElement(impl);
    }

    @Override
    public void addEventListener(String event) {
        if(event.equalsIgnoreCase(SCROLL_EVENT_TAG)) {
            setOnScrollListener(new ListViewOnScrollListener());
        }
    }

    @Override
    public void removeEventListener(String event) {
        if(event.equalsIgnoreCase(SCROLL_EVENT_TAG)) {
            setOnScrollListener(null);
        }
    }

    @Override
    public void setBaseAttr(int attr, Object param) {
        if (attr == RenderObjectAttr.SCROLL_TOP.value()) {
            scrollTop((Integer) param);
        }
    }

    @Override
    public void layoutView() {
        if(mImpl.getPosition() == null)
            return;
        super.layout(mImpl.getPosition().mLeft,
                mImpl.getPosition().mTop,
                mImpl.getPosition().mRight,
                mImpl.getPosition().mBottom);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if(mAdapter != null && !mAdapter.getProxyList().isEmpty()) {
            mListViewHeight = 0;
            for(int i = 0; i < mAdapter.getProxyList().size(); i++) {
                mListViewHeight += mAdapter.getProxyList().get(i).getPosition().getHeight();
            }
        }
        this.setMeasuredDimension(
                mImpl.getPosition().mRight - mImpl.getPosition().mLeft,
                mListViewHeight
        );
    }

    @Override
    public void linkElement(RenderObjectImpl impl) {
        mImpl = impl;
        mImpl.setViewImpl(this);
        updateStyle(impl.getStyle());
        this.setAdapter(mAdapter);
    }

    @Override
    public void separateElement() {
        mImpl = null;
        this.setAdapter(null);
    }

    @Override
    public RenderObjectImpl getImpl() {
        return mImpl;
    }

    @Override
    public void insertChild(RenderObjectImpl child, int index) {
        mAdapter.appendChildAt(child, index);
    }

    @Override
    public void removeChild(RenderObjectImpl child) {
        mAdapter.removeChild(child);
    }

    @Override
    public void setText(String text) {

    }

    @Override
    public void setPosition(Position position) {
        requestLayout();
    }

    @Override
    public void setSize(Size size) {

    }

    @Override
    public void setAttribute(String key, String value) {

    }

    @Override
    public void updateStyle(Style style) {
        this.setDividerHeight(0);
        if (style != null) {
            this.setBackgroundColor(style.mBackgroundColor);
        } else {
            this.setBackgroundColor(Color.WHITE);
        }

    }

    public boolean onTouchEvent(MotionEvent ev) {
        // 允许传递滑动事件
        isAllowToSendScrollEvent = true;
        return super.onTouchEvent(ev);
    }

    public void notifyDataSetChanged() {
        mAdapter.notifyDataSetChanged();
    }

    public void syncScrollPosition(int scrollHeight, int offsetHeight, int scrollTop) {

        if(scrollHeight == mLastScrollHeight
                && offsetHeight == mLastOffsetHeight
                && scrollTop == mLastScrollTop) {
            return;
        }

        mLastScrollHeight = scrollHeight;
        mLastOffsetHeight = offsetHeight;
        mLastScrollTop = scrollTop;

        mImpl.syncBaseAttr(RenderObjectAttr.SCROLL_TOP, scrollTop);
        mScrollEventToJs.updateValue(scrollHeight, offsetHeight, scrollTop);
        if (mParamsToJs == null) {
            mParamsToJs = new Object[2];
        }
        mParamsToJs[0] = mScrollEventToJs;
        mImpl.dispatchEvent(SCROLL_EVENT_TAG, mParamsToJs);

    }

    public int getScrollTop() {
        View view = getChildAt(0); //this is the first visible row
        if(view == null) {
            return 0;
        }

        int scrollY = -view.getTop();

        int firstVisiblePosition = getFirstVisiblePosition();
        for (int i = 0; i < firstVisiblePosition && i < mAdapter.getProxyList().size(); i++) {
            RenderObjectImpl child = mAdapter.getProxyList().get(i);
            if (child != null) {
                scrollY += child.getPosition().getHeight();
            }
        }
        return scrollY;
    }

    public void scrollTop(int scrollTop) {
        int totalHeight = 0;
        int targetSection = -1;
        for (int i = 0; i < mAdapter.getCount(); i++) {
            if (mAdapter.getElement(i) == null || mAdapter.getElement(i).getPosition() == null) {
                return;
            }
            totalHeight += mAdapter.getElement(i).getPosition().getHeight();
            targetSection = i;
            if (scrollTop - totalHeight < 0) {
                break;
            }
        }
        int offsetTop = totalHeight - scrollTop;

        //Using the post method permits to wait the update of the ListView before change position.
        final int fTargetSection = targetSection;
        final int fOffsetTop = offsetTop;
        this.post(new Runnable() {
            @Override
            public void run() {
                setSelectionFromTop(fTargetSection + 1, fOffsetTop);
            }
        });
    }

    public class ListViewOnScrollListener implements AbsListView.OnScrollListener {
        @Override
        public void onScrollStateChanged(AbsListView view, int scrollState) {
            mAdapter.onScrollItemChange(scrollState);
        }

        @Override
        public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            if (isAllowToSendScrollEvent) {
                // 允许传递滑动事件后开始传递给Js
                int scrollHeight = mListViewHeight;
                int offsetHeight = view.getHeight();
                int scrollTop = getScrollTop();
                syncScrollPosition(scrollHeight, offsetHeight, scrollTop);
            }
            mAdapter.onScrollItemChange(firstVisibleItem, visibleItemCount);
        }
    }
}
