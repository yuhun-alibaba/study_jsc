package com.lynx.base;

/**
 * Created by dli on 11/25/16.
 */
public class Position {
    public int mLeft;
    public int mTop;
    public int mRight;
    public int mBottom;

    public Position() {
        this.mLeft = 0;
        this.mTop = 0;
        this.mRight = 0;
        this.mBottom = 0;
    }

    public Position(int left, int top, int right, int bottom) {
        this.mLeft = left;
        this.mTop = top;
        this.mRight = right;
        this.mBottom = bottom;
    }

    public int getWidth() { return  mRight - mLeft; }

    public int getHeight() { return  mBottom- mTop; }
}
