package com.lynx.core;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.ImageView;

import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.core.image.WebImageView;
import com.lynx.core.impl.RenderObjectImpl;
import com.lynx.utils.RoundBackgroundUtil;
import com.lynx.utils.RoundCanvasClipper;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.squareup.picasso.Transformation;

/**
 * Created by dli on 10/01/2017.
 */

public class LynxUIImage extends WebImageView implements LynxRenderImplInterface {

    private RenderObjectImpl mImpl;
    private RoundBackgroundUtil mRoundBackgroundUtil;

    public LynxUIImage(Context context, RenderObjectImpl impl) {
        super(context);
        mRoundBackgroundUtil = new RoundBackgroundUtil();
        linkElement(impl);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (mImpl == null) {
            return;
        }
        // 绘制背景
        mRoundBackgroundUtil.drawBackground(canvas);
        // 绘制图片
        super.onDraw(canvas);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        if (mImpl == null) {
            return;
        }
        mRoundBackgroundUtil.drawBorder(canvas);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mImpl == null) {
            setMeasuredDimension(0, 0);
        } else {
            setMeasuredDimension(
                    mImpl.getPosition().mRight - mImpl.getPosition().mLeft,
                    mImpl.getPosition().mBottom - mImpl.getPosition().mTop
            );
        }
    }

    @Override
    public void addEventListener(String event) {

    }

    @Override
    public void removeEventListener(String event) {

    }

    @Override
    public void setBaseAttr(int attr, Object param) {

    }

    @Override
    protected void onLayout(boolean changed,
                            int l, int t, int r, int b) {
    }

    @Override
    public void layoutView() {
        if (mImpl == null) {
            layout(0, 0, 0, 0);
        } else {
            layout(mImpl.getPosition().mLeft,
                    mImpl.getPosition().mTop,
                    mImpl.getPosition().mRight,
                    mImpl.getPosition().mBottom);
        }
    }

    @Override
    public void linkElement(RenderObjectImpl impl) {
        mImpl = impl;
        mImpl.setViewImpl(this);
        updateStyle(impl.getStyle());
    }

    @Override
    public void separateElement() {
        mImpl.setViewImpl(null);
        mImpl = null;
    }

    @Override
    public RenderObjectImpl getImpl() {
        return mImpl;
    }

    @Override
    public void insertChild(RenderObjectImpl child, int index) {

    }

    @Override
    public void removeChild(RenderObjectImpl child) {
    }

    @Override
    public void requestLayout() {
        super.requestLayout();
    }

    @Override
    public void setText(String text) {
        return;
    }

    @Override
    public void setPosition(Position position) {
        requestLayout();
    }

    @Override
    public void setSize(Size size) {

    }

    @Override
    public void updateStyle(Style style) {
        //setScale(style.mCSSObjectFitType);
        this.setBackgroundColor(Color.TRANSPARENT);
        mRoundBackgroundUtil.setDrawAttr(mImpl);
        // 设置图片缩放格式
        setScale();
        // 在设置完属性后进行图片设置，因为图片的设置是根据imagenode的style进行变化
        updateImageSrc();
    }

    @Override
    public void setAttribute(String key, String value) {
        if(key == "src") {
            setImageUrl(value);
        }
    }
    private void setScale(){

        if (mImpl != null && mImpl.getStyle().mBorderRadius > 0) {
            // 如果是有设置圆角，则设置居中处理即可，其他处理在transform里面做
            setScaleType(ScaleType.CENTER);
            return;
        }

        switch (mImpl.getStyle().mObjectFit){
            case Style.CSSIMAGE_OBJECT_FIT_FILL:
                this.setScaleType(ImageView.ScaleType.FIT_XY);
                break;
            case Style.CSSIMAGE_OBJECT_FIT_CONTAIN:
                this.setScaleType(ScaleType.FIT_CENTER);
                break;
            case Style.CSSIMAGE_OBJECT_FIT_COVER:
                this.setScaleType(ScaleType.CENTER_CROP);
                break;
            default:break;
        }
    }

    private void updateImageSrc() {
        String imageSrc = mImpl.getValue("src");
        if (imageSrc != null) {
            this.setImageUrl(imageSrc);
        } else {
            this.setImageUrl(null);
        }
    }

    @Override
    public void setImageUrl(String url) {
        super.setImageUrl(url,new ListenTarget(),new ImageTransformation());
    }

    /* picasso 监听图片下载结果的target*/
    class ListenTarget implements Target{
        @Override
        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
            if (mImpl == null || bitmap == null) {
                return;
            }
            LynxUIImage.this.setImageBitmap(bitmap);
        }

        @Override
        public void onBitmapFailed(Drawable errorDrawable) {
            Log.e("lynx", "image load failed");
        }

        @Override
        public void onPrepareLoad(Drawable placeHolderDrawable) {}
    }

    /**
     *  由于web只有三种图片scaleType类型，都是在满足与设置图片宽度或高度相同，或者是拉伸成屏幕一样的情况，所以提前进行图片的切割，如果有圆角则在这个时候进行裁剪
     */
    class ImageTransformation implements Transformation {
        private String mKey;

        public ImageTransformation() {
            if (mImpl == null ||
                    (mImpl != null && mImpl.getPosition() == null) ||
                    (mImpl != null && mImpl.getStyle() == null)) {
                mKey = "null";
            } else {
                // 根据相关属性设置key，确保处理的图片能唯一的对应
                StringBuilder builder = new StringBuilder();
                // height
                builder.append(mImpl.getStyle().mBorderRadius).append(";");
                // width
                builder.append(mImpl.getPosition().getWidth()).append(";");
                // radius
                builder.append(mImpl.getPosition().getHeight()).append(";");
                // object-fit
                //builder.append(mImpl.getStyle().mCSSObjectFitType).append(";");
                mKey = builder.toString();
            }
        }

        /* 在进行图片下载完成后根据图片的属性进行提前处理 */
        @Override
        public Bitmap transform(Bitmap source) {
            if (mImpl == null || (mImpl != null && (mImpl.getPosition().getWidth() == 0 || mImpl.getPosition().getHeight() == 0))) {
                return source;
            }
            // 没有设置圆角则正常处理
            if (mImpl.getStyle() == null || (mImpl.getStyle().mBorderRadius == 0)) {
                return source;
            }
            // 设置了圆角则进行提前处理，将object-fit都一起处理，否则圆角需要在draw的时候处理，考虑到性能损耗，提前把bitmap变成圆角
            int w = mImpl.getPosition().getWidth();
            int h = mImpl.getPosition().getHeight();
            // 创建另外的bitmap，这里不会对图片进行压缩，需要压缩需要提前处理
            Bitmap bitmap = Bitmap.createBitmap(w, h, source.getConfig());
            RectF rectF = null;
            Matrix matrix = new Matrix();
            Canvas canvas = new Canvas(bitmap);
            canvas.drawARGB(0, 0, 0, 0);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            // 利用bitmapShader将图片作为纹理设置进paint中，再进行绘制
            BitmapShader shader = new BitmapShader(source, BitmapShader.TileMode.CLAMP, BitmapShader.TileMode.CLAMP);
            // 绘制图片
            switch (mImpl.getStyle().mObjectFit){
                case Style.CSSIMAGE_OBJECT_FIT_FILL:
                    // 图片按照所给宽度和高度进行变化
                    matrix.setScale(w / (float) source.getWidth(), h / (float) source.getHeight());
                    rectF = new RectF(0, 0, w, h);
                    break;
                case Style.CSSIMAGE_OBJECT_FIT_CONTAIN:
                    // 根据所给的宽度比例与高度比例的最小值进行图片缩小，居中显示
                {
                    float w_rate = w / (float) source.getWidth();
                    float h_rate = h / (float) source.getHeight();
                    if (w_rate > h_rate) {
                        int finalWidth = (int) (source.getWidth() * h_rate);
                        int startW = (w - finalWidth) / 2;
                        rectF = new RectF(startW, 0, startW + finalWidth, h);
                        matrix.setScale(h_rate, h_rate);
                        matrix.postTranslate(startW, 0);
                    } else {
                        int finalHeight = (int) (source.getHeight() * w_rate);
                        int startH = (h - finalHeight) / 2;
                        rectF = new RectF(0, startH, w, startH + finalHeight);
                        matrix.setScale(w_rate, w_rate);
                        matrix.postTranslate(0, startH);
                    }
                }
                break;
                case Style.CSSIMAGE_OBJECT_FIT_COVER:
                    // 根据所给的宽度比例与高度比例的最小值进行图片放大，居中显示
                {
                    float w_rate = w / (float) source.getWidth();
                    float h_rate = h / (float) source.getHeight();
                    if (w_rate > h_rate) {
                        int finalHeight = (int) (source.getHeight() * w_rate);
                        int startH = (h - finalHeight) / 2;
                        rectF = new RectF(0, startH, w, h);
                        matrix.setScale(w_rate, w_rate);
                        matrix.postTranslate(0, startH);
                    } else {
                        int finalWidth = (int) (source.getWidth() * h_rate);
                        int startW = (w - finalWidth) / 2;
                        rectF = new RectF(startW, 0, w, h);
                        matrix.setScale(h_rate, h_rate);
                        matrix.postTranslate(startW, 0);
                    }
                }
                break;
                default:
                    break;
            }
            shader.setLocalMatrix(matrix);
            paint.setShader(shader);
            canvas.drawRect(rectF, paint);
            // 如果radius>0则绘制圆角
            float radius = (float) mImpl.getStyle().mBorderRadius;
            if (radius > 0) {
                paint.setShader(null);
                RoundCanvasClipper.instance().clipRoundRectUseXfermode(canvas, mImpl, source.getConfig());
            }
            // 回收原始的bitmap
            source.recycle();
            return bitmap;
        }

        /* 根据key值进行缓存，将radius width height objectFit作为key值*/
        @Override
        public String key() {
            return mKey;
        }
    }

}
