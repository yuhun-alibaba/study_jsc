package com.lynx.core;

import android.graphics.Typeface;
import android.os.Build;
import android.text.BoringLayout;
import android.text.Layout;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;

import com.lynx.base.CalledByNative;
import com.lynx.base.Constants;
import com.lynx.base.Size;
import com.lynx.base.Style;
import com.lynx.utils.PixelUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dli on 6/8/16.
 */
public class LabelMeasurer {

    public static final int UNSET = -1;
    public static final double FONT_SIZE_SP = 14.0;

    private final static String XIAO_MI = "xiaomi";
    private static TextPaint sTextPaintInstance = null;

    private static synchronized TextPaint getTextPaint(){
        if(sTextPaintInstance == null) {
            sTextPaintInstance = new TextPaint();
            sTextPaintInstance.setFlags(TextPaint.ANTI_ALIAS_FLAG);

            String manufacturer = Build.MANUFACTURER.toLowerCase();
            if (TextUtils.equals(XIAO_MI, manufacturer)) {
                Typeface sansSerif = Typeface.SERIF;
                sTextPaintInstance.setTypeface(sansSerif);
            }
        }
        return sTextPaintInstance;
    }

    public static Typeface getTypeface() {
        return getTextPaint().getTypeface();
    }

    @CalledByNative
    public static Size measureLabelSize(String labelText, Style style, int width, int height) {

        Size measuredSize = new Size();

        int numberOfLines = UNSET;
        int lineHeight = UNSET;

        TextPaint textPaint = getTextPaint();
        Layout layout;

        labelText = labelText != null ?
                labelText :
                "Spannable element has not been prepared in onBeforeLayout";
        Spanned text = fromLabelNode(labelText, style);
//        Spanned text = Spannable.Factory.getInstance().newSpannable(this.mText);
        BoringLayout.Metrics boring = BoringLayout.isBoring(text, textPaint);
        float desiredWidth = boring == null ?
                (int) Math.ceil(Layout.getDesiredWidth(text, textPaint)) : Float.NaN;

        if (boring == null
                && (Constants.isUndefined(style.mWidth) ||
                    Constants.isUndefined(width) ||
                    (!Float.isNaN(desiredWidth) && desiredWidth <= width))) {
            // Is used when the width is not known and the text is not boring, ie. if it contains
            // unicode characters.
            layout = new StaticLayout(
                    text,
                    textPaint,
                    (int) Math.ceil(desiredWidth),
                    Layout.Alignment.ALIGN_NORMAL,
                    1,
                    0,
                    true);
        } else if (boring != null && (Constants.isUndefined(style.mWidth)
                || (Constants.isUndefined(width)
                || boring.width <= width))) {
            // Is used for single-line, boring text when the width is either unknown or bigger
            // than the width of the text.
            layout = BoringLayout.make(
                    text,
                    textPaint,
                    boring.width,
                    Layout.Alignment.ALIGN_NORMAL,
                    1,
                    0,
                    boring,
                    true);
        } else {
            // Is used for multiline, boring text and the width is known.
            layout = new StaticLayout(
                    text,
                    textPaint,
                    (int) width,
                    Layout.Alignment.ALIGN_NORMAL,
                    1,
                    0,
                    true);
        }

        measuredSize.mWidth = layout.getWidth();
        measuredSize.mHeight = layout.getHeight();
        if (numberOfLines != UNSET &&
                numberOfLines < layout.getLineCount()) {
            measuredSize.mWidth = layout.getLineBottom(numberOfLines - 1);
        }
        if (lineHeight != UNSET) {
            int lines = numberOfLines != UNSET
                    ? Math.min(numberOfLines, layout.getLineCount())
                    : layout.getLineCount();
            measuredSize.mHeight = Style.mDensity * lineHeight * lines;
        }
        if(style.mWhiteSpace == Style.CSSTEXT_WHITESPACE_NOWRAP) {
            measuredSize.mHeight /= layout.getLineCount();
        }

        return measuredSize;
    }

    private static class SetSpanOperation {
        protected int start, end;
        protected Object what;
        SetSpanOperation(int start, int end, Object what) {
            this.start = start;
            this.end = end;
            this.what = what;
        }
        public void execute(SpannableStringBuilder sb) {
            // All spans will automatically extend to the right of the text, but not the left - except
            // for spans that start at the beginning of the text.
            int spanFlags = Spannable.SPAN_EXCLUSIVE_INCLUSIVE;
            if (start == 0) {
                spanFlags = Spannable.SPAN_INCLUSIVE_INCLUSIVE;
            }
            sb.setSpan(what, start, end, spanFlags);
        }
    }

    private static final void buildSpannedFromTextCSSNode(
            String labeltext,
            Style style,
            SpannableStringBuilder sb,
            List<SetSpanOperation> ops) {
        int start = sb.length();
        if (labeltext != null) {
            sb.append(labeltext);
        }

        int end = sb.length();
        if (end >= start) {
            ops.add(new SetSpanOperation(start, end, new ForegroundColorSpan(style.mFontColor)));

            ops.add(new SetSpanOperation(
                    start,
                    end,
                    new BackgroundColorSpan(style.mBackgroundColor)));

            if (!Constants.isUndefined(style.mFontSize)) {
                ops.add(new SetSpanOperation(start, end,
                        new AbsoluteSizeSpan(PixelUtils.toPixelFromSP(style.mFontSize))));
            }

            /*
            if (textCSSNode.mFontStyle != UNSET ||
                    textCSSNode.mFontWeight != UNSET ||
                    textCSSNode.mFontFamily != null) {
                ops.add(new SetSpanOperation(
                        start,
                        end,
                        new CustomStyleSpan(
                                textCSSNode.mFontStyle,
                                textCSSNode.mFontWeight,
                                textCSSNode.mFontFamily,
                                textCSSNode.getThemedContext().getAssets())));
            }
            if (textCSSNode.mTextShadowOffsetDx != 0 || textCSSNode.mTextShadowOffsetDy != 0) {
                ops.add(new SetSpanOperation(
                        start,
                        end,
                        new ShadowStyleSpan(
                                textCSSNode.mTextShadowOffsetDx,
                                textCSSNode.mTextShadowOffsetDy,
                                textCSSNode.mTextShadowRadius,
                                textCSSNode.mTextShadowColor)));
            }
            ops.add(new SetSpanOperation(start, end, new ReactTagSpan(textCSSNode.getReactTag())));
            */
        }
    }

    protected static final Spannable fromLabelNode(String labelText, Style style) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        // TODO(5837930): Investigate whether it's worth optimizing this part and do it if so

        // The {@link SpannableStringBuilder} implementation require setSpan operation to be called
        // up-to-bottom, otherwise all the spannables that are withing the region for which one may set
        // a new spannable will be wiped out
        List<SetSpanOperation> ops = new ArrayList<SetSpanOperation>();
        buildSpannedFromTextCSSNode(labelText, style, sb, ops);
        if (Constants.isUndefined(style.mFontSize)) {
            sb.setSpan(
                    new AbsoluteSizeSpan((int) Math.ceil(PixelUtils.toPixelFromSP(FONT_SIZE_SP))),
                    0,
                    sb.length(),
                    Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        }


        // While setting the Spans on the final text, we also check whether any of them are images
        for (int i = ops.size() - 1; i >= 0; i--) {
            SetSpanOperation op = ops.get(i);
            op.execute(sb);
        }
        return sb;
    }
}
