package com.lynx.core.impl;

/**
 * Created by yanxing on 17/3/1.
 */

public enum RenderObjectAttr {
    SCROLL_TOP(0),
    SCROLL_LEFT(1),
    GET_TEXT(2);

    private int mValue;
    RenderObjectAttr(int value) {
        this.mValue = value;
    }

    public int value() {
        return mValue;
    }
}
