package com.lynx.base;

import android.os.AsyncTask;
import android.support.annotation.Keep;

import java.util.Set;

/**
 * Created by yanxing on 17/2/14.
 */

public class URLRequest {

    private long mID;

    public URLRequest(long id) {
        mID = id;
    }

    @CalledByNative
    static URLRequest create(long id) {
        return new URLRequest(id);
    }

    @Keep
    @CalledByNative
    public void fetch(final long id, final String url, final long delegate) {
        Listener listener = new Listener(){
            @Override
            public void onResponse(String response) {
                if (delegate != 0 && !response.isEmpty()) {
                    nativeOnSuccess(delegate, url, response);
                    RequestManager.GetInstance().RemoveTask(id, url);
                }
            }
            @Override
            public void onError(String error) {
                if (delegate != 0 && !error.isEmpty()) {
                    nativeOnFailed(delegate, url, error);
                    RequestManager.GetInstance().RemoveTask(id, url);
                }
            }

            @Override
            public void onCancel() {
                if (delegate != 0) {
                    nativeOnCancel(delegate);
                    RequestManager.GetInstance().RemoveTask(id, url);
                }
            }
        };
        RequestTask task = new RequestTask(url, listener);
        RequestManager.GetInstance().AddTask(id, url, task);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    @Keep
    public native void nativeOnSuccess(long ptr, String url, String response);

    @Keep
    public native void nativeOnFailed(long ptr, String url, String error);

    @Keep
    public native void nativeOnCancel(long ptr);

    public void Cancel() {

    }

    interface Listener {
        void onResponse(String response);
        void onError(String error);
        void onCancel();
    }

}
