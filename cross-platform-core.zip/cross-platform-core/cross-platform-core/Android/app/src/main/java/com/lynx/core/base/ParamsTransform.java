package com.lynx.core.base;

import com.lynx.base.CalledByNative;

/**
 * Created by dli on 28/02/2017.
 */

public class ParamsTransform {

    @CalledByNative
    public static String transform(Object[] params) {
        if (params != null) {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < params.length; i++) {
                builder.append(transform(params[i]));
            }
            return builder.toString();
        }
        return "";
    }

    @CalledByNative
    public static String transform(Object param) {
        if (param == null) {
            return "V";
        }
        Class clazz = param.getClass();
        if (clazz == void.class) {
            return "V";
        } if (clazz.getComponentType() != null) {
            throw new RuntimeException("Do not use system array as params, use JSArray instead !");
        }else if (clazz == short.class || clazz == Short.class) {
            return "S";
        } else if (clazz == int.class || clazz == Integer.class) {
            return "I";
        } else if (clazz == long.class || clazz == Long.class) {
            return "J";
        } else if (clazz == float.class || clazz == Float.class) {
            return "F";
        } else if (clazz == double.class || clazz == Double.class) {
            return "D";
        } else if (clazz == char.class || clazz == Character.class) {
            return "C";
        } else if (clazz == boolean.class || clazz == Boolean.class) {
            return "Z";
        } else if (clazz == byte.class || clazz == Byte.class) {
            return "B";
        } else if (clazz == String.class) {
            return "s";
        } else if (JSArray.class.isAssignableFrom(clazz)) {
            return "b";
        } else if (JSObject.class.isAssignableFrom(clazz)) {
            return "c";
        }
        throw new RuntimeException(clazz.getCanonicalName() + " is not defined as a property to lynx jni !");
    }

}
