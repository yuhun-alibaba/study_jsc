package com.lynx.core.impl;

import com.lynx.base.Position;
import com.lynx.base.Size;
import com.lynx.base.Style;

/**
 * Created by dli on 05/01/2017.
 */

public interface RenderImplInterface {
    void insertChild(RenderObjectImpl child, int index);
    void removeChild(RenderObjectImpl child);
    void requestLayout();
    void setText(String text);
    void setPosition(Position position);
    void setAttribute(String key, String value);
    void updateStyle(Style style);
    void setSize(Size size);
    void addEventListener(String event);
    void removeEventListener(String event);
    void setBaseAttr(int attr, Object param);
}
