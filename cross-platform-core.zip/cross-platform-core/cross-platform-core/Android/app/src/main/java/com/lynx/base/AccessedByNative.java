package com.lynx.base;

/**
 * Created by dli on 01/03/2017.
 */

public @interface AccessedByNative {
}
