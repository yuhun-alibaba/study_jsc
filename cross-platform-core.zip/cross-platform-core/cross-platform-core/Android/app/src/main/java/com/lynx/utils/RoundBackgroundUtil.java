package com.lynx.utils;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by yanxing on 16/8/1.
 * 1.支持绘制圆角或直角border，不进行孩子的裁剪
 * 2.支持绘制background.
 * 需要裁剪可用{@link RoundCanvasClipper}类进行裁剪。
 */
public class RoundBackgroundUtil {
    private RectF mBorderRectF;
    private Paint mBorderPaint;
    private Paint mBackgroundPaint;
    private boolean needBgColor = true;
    private boolean needBorder = false;
    private float mRadius = 0;

    public RoundBackgroundUtil() {
        mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBackgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBorderRectF = new RectF();
    }

    public void drawBackground(Canvas canvas) {
        if (needBgColor) {
            mBorderRectF.set(0, 0, canvas.getWidth(), canvas.getHeight());
            canvas.drawRoundRect(mBorderRectF, mRadius, mRadius, mBackgroundPaint);
        }
    }
    public void drawBorder(Canvas canvas) {
        if (needBorder) {
            mBorderRectF.set(0, 0, canvas.getWidth(), canvas.getHeight());
            canvas.drawRoundRect(mBorderRectF, mRadius, mRadius, mBorderPaint);
        }
    }

    public void setDrawAttr(RenderObjectImpl impl) {
        if ((float) impl.getStyle().mBorderWidth > 0) {
            needBorder = true;
        } else {
            needBorder = false;
        }
        // 设置边框
        if (needBorder) {
            mBorderPaint.setColor(impl.getStyle().mBorderColor);
            mBorderPaint.setAntiAlias(true);
            mBorderPaint.setStrokeWidth((float) impl.getStyle().mBorderWidth);
            mBorderPaint.setStyle(Paint.Style.STROKE);
        }
        if (impl.getStyle().mBackgroundColor != 0) {
            needBgColor = true;
            // 设置背景颜色
            mBackgroundPaint.setColor(impl.getStyle().mBackgroundColor);
        } else {
            needBgColor = false;
        }
        // 设置圆角
        if ((float) impl.getStyle().mBorderRadius > 0) {
            mRadius = (float) (impl.getStyle().mBorderRadius);
        } else {
            mRadius = 0;
        }
    }

    public void reset() {
        mBorderPaint.reset();
        mBackgroundPaint.reset();
        mBorderRectF.setEmpty();
    }
}
