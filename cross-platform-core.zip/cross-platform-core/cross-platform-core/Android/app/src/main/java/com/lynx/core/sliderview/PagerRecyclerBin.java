package com.lynx.core.sliderview;

import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;

import com.lynx.core.LynxRenderImplInterface;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Monster on 2017/3/14.
 */

public class PagerRecyclerBin {

    private static final int CACHE_TO_DEALLOCATE_THRESHOLD = 3;

    private SparseArray<View> mDisplayBin;
    private SparseArray<View> mCacheBin;

    private SparseArray<List<View>> mDeallocatedLynxUIInterfaceTypeBin;
    private Map<Class, List<View>> mDeallocatedViewBin;

    private boolean enableRecycle = false;


    public PagerRecyclerBin() {
        mDisplayBin = new SparseArray<>();
        mCacheBin = new SparseArray<>();
        mDeallocatedLynxUIInterfaceTypeBin = new SparseArray<>();
        mDeallocatedViewBin = new HashMap<>();
    }

    public View removeDisplayView(int position) {
        View view = mDisplayBin.get(position);
        mDisplayBin.remove(position);
        addCacheView(position, view);
        return view;
    }

    public void flushWhenAddChild(int position, int length) {
        // 将缓存中的和在展示的都往后移动
        for (int i = length - 1; i > position; i--) {
            View temp = mCacheBin.get(i - 1);

            if (temp != null) {
                mCacheBin.put(i, temp);
                mCacheBin.remove(i - 1);
            }

            temp = mDisplayBin.get(i - 1);
            if (temp != null) {

                if (mDisplayBin.size() >= 3 && i - 1 < length - 2) {
                    // 如果不是边界值,则将越界的一个塞入cache中,displayBin中只能存储3个
                    if (temp.getParent() != null) {
                        ((ViewGroup) temp.getParent()).removeView(temp);
                    }
                    mDisplayBin.remove(i - 1);
                    addCacheView(i, temp);
                } else {
                    // 在displayBin中往后移动
                    mDisplayBin.put(i, temp);
                    mDisplayBin.remove(i - 1);
                }
            }

        }
    }

    public void flushWhenRemoveChild(int position, int length) {

        View view = mDisplayBin.get(position);
        if (view != null) {
            mDisplayBin.remove(position);
            deallocateView(view);
        }

        view = mCacheBin.get(position);
        if (view != null) {
            mCacheBin.remove(position);
            deallocateView(view);
        }

        // 将缓存中的和在展示的都往前移动
        for (int i = position + 1; i < length; i++) {
            View temp = mDisplayBin.get(i);
            if (temp != null) {
                mDisplayBin.put(i - 1, temp);
                mDisplayBin.remove(i);
            }

            temp = mCacheBin.get(i);
            if (temp != null) {
                mCacheBin.put(i - 1, temp);
                mCacheBin.remove(i);
            }
        }
    }

    public View obtainView(int position) {

        View cur = mCacheBin.get(position);

        if (cur != null) {
            removeCacheView(position);
        } else {
            cur = mDisplayBin.get(position);
        }

        if (cur != null) {
            return cur;
        }
        return null;
    }

    /**
     * 获取被回收的view,可以进行重复使用
     * @param type
     * @return
     */
    public View getDeallocatedView(int type) {

        List<View> list = mDeallocatedLynxUIInterfaceTypeBin.get(type);

        if (list != null && list.size() > 0) {
            return list.remove(0);
        }
        return null;
    }

    /**
     * 获取被回收的view,可以进行重复使用
     * @param type
     * @return
     */
    public View getDeallocatedView(Class type) {
        List<View> list = mDeallocatedViewBin.get(type);

        if (list != null && list.size() > 0) {
            return list.remove(0);
        }
        return null;
    }

    public void addDisplayView(int position, View display) {

        int aliveIndex = mDisplayBin.indexOfValue(display);

        if (aliveIndex >= 0) {
            mDisplayBin.remove(aliveIndex);
        }

        mDisplayBin.put(position, display);
    }

    private void addCacheView(int position, View cache) {

        mCacheBin.put(position, cache);

        if (mCacheBin.size() > CACHE_TO_DEALLOCATE_THRESHOLD) {
            int target = mCacheBin.keyAt(0);
            deallocateView(target);
            mCacheBin.remove(target);
        }

    }
    private void removeCacheView(int position) {
        mCacheBin.remove(position);
    }

    private void deallocateView(int position) {
        if (!enableRecycle) {
            return;
        }
        View view = mCacheBin.get(position);
        deallocateView(view);
    }

    private void deallocateView(View view) {

        if (view instanceof ViewGroup) {
            while (((ViewGroup) view).getChildCount() > 0) {
                deallocateView(((ViewGroup) view).getChildAt(0));
            }
        }

        if (view instanceof LynxRenderImplInterface && ((LynxRenderImplInterface) view).getImpl() != null) {
            // firstly get view's type
            int type = ((LynxRenderImplInterface) view).getImpl().getRenderObjectType();

            // unbind data from view
            ((LynxRenderImplInterface) view).separateElement();

            // remove view from parent
            if (view.getParent() != null) {
                ((ViewGroup)view.getParent()).removeView(view);
            }

            // add the view to pool
            List<View> list = mDeallocatedLynxUIInterfaceTypeBin.get(type);

            if (list == null) {
                list = new ArrayList<>();
                mDeallocatedLynxUIInterfaceTypeBin.put(type, list);
            }
            list.add(view);
        } else {
            // 回收普通的view
            if (view.getParent() != null) {
                ((ViewGroup)view.getParent()).removeView(view);
            }

            List<View> list = mDeallocatedViewBin.get(view.getClass());

            if (list == null) {
                list = new ArrayList<>();
                mDeallocatedViewBin.put(view.getClass(), list);
            }
            list.add(view);
        }
    }

    public void enableRecycle(boolean enable) {
        enableRecycle = enable;
    }


}
