package com.lynx.core.sliderimage;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.lynx.core.image.WebImageView;
import com.lynx.core.sliderview.BaseSliderChildViewFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Monster on 2017/3/14.
 */

public class SliderImageChildFactory extends BaseSliderChildViewFactory {
    private Context mContext;
    private List<? extends ImageData> mDataList;
    private boolean mNeedToFlush = false;

    public SliderImageChildFactory(Context context) {
        super();
        this.mContext = context;
    }

    public void setDataList(List<? extends ImageData> dataList) {
        mNeedToFlush = false;
        // 判断是否需要刷新
        if (dataList != null && mDataList != null && mDataList.size() == dataList.size()) {
            for (int i = 0; i < mDataList.size(); i++) {
                if (!mDataList.get(i).equals(dataList.get(i))) {
                    mNeedToFlush = true;
                    break;
                }
            }
        } else {
            mNeedToFlush = true;
        }
        // 设置数据
        if (dataList != null) {
            mDataList = new ArrayList<>(dataList);
        } else {
            mDataList = null;
        }
    }

    @Override
    public View makeView(int position) {
        return makeEachImageView(position);
    }

    @Override
    public void reBindData(View position) {

    }

    @Override
    public int getChildCount() {
        if (mDataList == null) {
            return 0;
        }
        return mDataList.size();
    }

    private View makeEachImageView(int position) {
        if (mDataList == null) {
            return null;
        }

        ImageData itemData = mDataList.get(position);

        if (itemData == null) {
            return null;
        }

        // reuse the view from recycler bin
        WebImageView webImageView = (WebImageView) mRecyclerBin.getDeallocatedView(WebImageView.class);
        if (webImageView == null) {
            webImageView = new WebImageView(mContext);
            webImageView.setBackgroundColor(Color.parseColor("#f5f5f5"));
            webImageView.setScaleType(ImageView.ScaleType.FIT_XY);
            webImageView.setClickable(false);
        }

        final String imgUrl = itemData.getImg();
        int w = 0;
        int h = 0;

        if (!TextUtils.isEmpty(imgUrl)) {
            webImageView.setImageUrl(imgUrl);
        }

        return webImageView;
    }

    @Override
    public boolean getNeedToFlush() {
        return mNeedToFlush;
    }
}
