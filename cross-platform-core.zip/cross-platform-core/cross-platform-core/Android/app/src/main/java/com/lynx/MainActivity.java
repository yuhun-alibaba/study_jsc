package com.lynx;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.lynx.core.LynxView;
import com.lynx.core.RuntimeManager;
import com.lynx.utils.StringUtil;

public class MainActivity extends AppCompatActivity {

    LynxView mView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        RuntimeManager.initialize();
        mView = new LynxView(this);
        mView.loadScriptData(readBundleScript("test.js"));
//        mView.loadUrl("http://172.17.37.39:7010/bundle.js");

        setContentView(mView);
    }

    private String readBundleScript(String fileName) {
        try {
            return StringUtil.convertToString(getResources().getAssets().open(fileName));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


}
