package com.lynx.core.base;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dli on 28/02/2017.
 */

public class JSArray {
    private List<Object> mObjects;

    public JSArray(int length) {
        mObjects = new ArrayList<>();
        for (int i = 0; i < length; i++) {
            mObjects.add(null);
        }
    }

    public JSArray() {
        mObjects = new ArrayList<>();
    }

    public void set(int index, Object object) {
        mObjects.set(index, object);
    }

    public void add(Object object) {
        mObjects.add(object);
    }

    public int length() {
        return mObjects.size();
    }

    public Object get(int index) {
        return mObjects.get(index);
    }

    public String getComponentsType() {
        return ParamsTransform.transform(mObjects.toArray());
    }
}
