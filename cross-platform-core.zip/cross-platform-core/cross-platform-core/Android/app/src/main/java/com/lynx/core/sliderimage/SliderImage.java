package com.lynx.core.sliderimage;

import android.content.Context;
import android.view.MotionEvent;

import com.lynx.core.sliderview.SliderView;
import com.lynx.core.sliderview.SliderViewLooperController;
import com.lynx.core.sliderview.SliderViewPagerAdapter;

import java.util.List;

/**
 * Created by Monster on 2017/3/14.
 */

public class SliderImage extends SliderView {
    private final static int DEFAULT_DURATION = 200;

    public SliderImage(Context context) {
        super(context);
        enableLooper();
        setDuration(DEFAULT_DURATION);
    }

    @Override
    public SliderViewPagerAdapter createSliderViewPagerAdapter() {
        return new SliderImagePagerAdapter(getContext());
    }

    @Override
    public SliderViewLooperController createLooperController() {
        return new SliderViewLooperController(this);
    }

    public void setData(List<? extends ImageData> list) {
        ((SliderImagePagerAdapter)mAdapter).setDataList(list);
        notifyDataSetChange();
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        super.onTouchEvent(ev);
        if (ev.getAction() == MotionEvent.ACTION_DOWN ) {
            return true;
        }
        return false;
    }
}
