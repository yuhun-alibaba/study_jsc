package com.lynx.core.sliderview;

import android.content.Context;
import android.support.v4.view.ViewPager;

/**
 * Created by Monster on 2017/3/14.
 */

public abstract class SliderView extends ViewPager {
    protected SliderViewPagerAdapter mAdapter;
    protected SliderViewLooperController mLooperController;

    protected boolean mIsAutoPlay = false;
    protected boolean mIsLooper = false;
    protected boolean mIsLooperState = false;
    public SliderView(Context context) {
        super(context);
        mAdapter = createSliderViewPagerAdapter();
        mLooperController = createLooperController();
        setAdapter(mAdapter);
    }

    public abstract SliderViewPagerAdapter createSliderViewPagerAdapter();

    public abstract SliderViewLooperController createLooperController();

    public void enableLooper() {
        mAdapter.setLooper(true);
        mIsLooper = true;
    }

    public void disableLooper() {
        clearLooperState();
        mAdapter.setLooper(false);
        mIsLooper = false;
    }

    public void setDuration(int duration) {
        mLooperController.setDuration(duration);
    }

    public void setInterval(int interval) {
        mLooperController.setInterval(interval);
    }

    public void enableAutoPlay() {
        mIsAutoPlay = true;
    }

    public void disableAutoPlay() {
        mIsAutoPlay = false;
    }

    public void startPlay() {
        if (mAdapter.getActualChildCount() > 1 && !mLooperController.isStart()) {
            mLooperController.start();
        }
    }

    public void stopPlay() {
        disableAutoPlay();
        mLooperController.stop();
    }

    /**
     * 通知sliderview孩子数量的变动
     */
    public void notifyDataSetChange() {
        if (mIsAutoPlay && mAdapter.getActualChildCount() > 1 && !mLooperController.isStart()) {
            startPlay();
        }
        if (mAdapter.getActualChildCount() <= 1 && mLooperController.isStart()) {
            stopPlay();
        }
        resetLooperState();
    }

    /**
     * 当初始化Item的looper状态的时候,设置初始的index
     */
    private void resetLooperState() {
        if (mAdapter.getActualChildCount() <= 1) {
            return;
        }
        if (!mIsLooper) {
            return;
        }
        if (mIsLooperState) {
            return;
        }
        mIsLooperState = true;

        int curItem = getLooperStartIndex() + getCurrentItem();
        int remainder = 0;

        if (mAdapter.getActualChildCount() != 0) {
            remainder = curItem % mAdapter.getActualChildCount();
        }

        if (remainder != 0) {
            curItem -= remainder;
        }
        final int finalCurItem = curItem;
        post(new Runnable() {
            @Override
            public void run() {
                setCurrentItem(finalCurItem, false);
            }
        });
    }

    protected int getLooperStartIndex() {
        return 500;
    }

    /**
     * 取消looper状态,将viewPager的index设置正确
     */
    private void clearLooperState() {

        if (!mIsLooper) {
            return;
        }

        mIsLooperState = false;
        int curItem = getCurrentItem();
        curItem %= mAdapter.getActualChildCount();
        setCurrentItem(curItem, false);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopPlay();
    }
}
