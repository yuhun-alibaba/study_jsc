package com.lynx.core.input;

import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.base.LynxEvent;
import com.lynx.core.impl.RenderObjectImpl;

import static com.lynx.core.input.EventType.FOCUS_EVENT;


/**
 * Created by Monster on 2016/11/10.
 * input组件的聚焦事件处理。
 * 事件定义:光标第一次移动到此控件上。
 */

public class FocusEventListener implements View.OnTouchListener {
    private RenderObjectImpl mImpl;
    //通过listener设置焦点事件触发时的输入框文本内容
    private BlurAndChangeEventListener listener;
    //通过mHandler判断是否可以触发获取焦点事件
    private EventHandler mHandler;
    //是否触发聚焦事件
    private boolean enableFocus = false;
    //是否第一次触发
    private boolean isFirst = true;

    public FocusEventListener(RenderObjectImpl impl, BlurAndChangeEventListener listener, EventHandler mHandler) {
        this.mImpl = impl;
        this.listener = listener;
        this.mHandler = mHandler;
    }

    public void setEnableFocus(boolean enableFocus) {
        this.enableFocus = enableFocus;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (isFirst) {
                sendToJs();
                isFirst = false;
            } else {
                if (mHandler.isEnableFocus()) {
                    sendToJs();
                    //触发过就不能触发，直到下一次失焦事件触发之后才能再次触发
                    mHandler.setEnableFocus(false);
                }
            }
        }
        return false;

    }

    /**
     * 发送到js
     */
    private void sendToJs() {
        try {
            //设置聚焦之后文本的内容，用于change事件中的文本对比
            LynxRenderImplInterface impl = mImpl.getViewImpl();
            if (impl == null){
                return;
            }
            listener.setOriginText(((EditText) impl).getText().toString());
        } catch (Exception e) {
            return;
        }
        if (enableFocus) {
            LynxEvent mEventToJs = new LynxEvent(FOCUS_EVENT);
            Object[] mParamsToJs = new Object[1];
            mParamsToJs[0] = mEventToJs;
            mImpl.dispatchEvent(FOCUS_EVENT, mParamsToJs);
        }
    }
}
