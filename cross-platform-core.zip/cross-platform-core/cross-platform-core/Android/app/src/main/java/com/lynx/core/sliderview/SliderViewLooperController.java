package com.lynx.core.sliderview;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.view.animation.AccelerateInterpolator;

/**
 * Created by Monster on 2017/3/14.
 */

public class SliderViewLooperController implements Runnable {
    private final static int DEFAULT_DURATION = 1000;
    private final static int DEFAULT_INTERVAL = 5000;

    private int mDuration = DEFAULT_DURATION;
    private int mInterval = DEFAULT_INTERVAL;
    private int oldDragPosition = 0;

    private Thread mThread;
    private ViewPager mViewPager;
    private ValueAnimator mValueAnimator;

    private boolean mIsForward = true;
    private boolean mIsStop = true;

    public SliderViewLooperController(ViewPager viewPager) {
        this(viewPager, DEFAULT_DURATION, DEFAULT_INTERVAL);
    }

    public SliderViewLooperController(ViewPager viewPager, int duration, int interval) {
        this.mViewPager = viewPager;
        this.mDuration = duration;
        this.mInterval = interval;
        prepareAnimator();
    }

    public void start() {
//        mIsStop = false;
//
//        if (mThread != null && mThread.isAlive()) {
//            return;
//        }
//        mThread = new Thread(this);
//        mThread.start();
    }

    public boolean isStart() {
        return !mIsStop;
    }

    public void stop() {
        mIsStop = true;
    }

    public void setDuration(int duration) {
        mDuration = duration;
        mValueAnimator.setDuration(mDuration);
    }

    public void setInterval(int interval) {
        mInterval = interval;
    }

    protected void prepareAnimator() {

        mValueAnimator = ValueAnimator.ofInt(0, mViewPager.getWidth() - (mIsForward ? mViewPager.getPaddingLeft() : mViewPager.getPaddingRight()));

        mValueAnimator.addListener(mAnimatorListener);

        mValueAnimator.setInterpolator(mAccelerateInterpolator);

        mValueAnimator.addUpdateListener(mAnimatorUpdateListener);

        mValueAnimator.setDuration(mDuration);
    }

    @Override
    public void run() {
        while (!mIsStop) {
            try {
                Thread.sleep(mInterval);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (mIsStop) break;
            mHandler.sendEmptyMessage(0x11);
        }
    }

    private void animatePagerLoop() {
//        mValueAnimator.setIntValues(0, mViewPager.getWidth() - (mIsForward ? mViewPager.getPaddingLeft() : mViewPager.getPaddingRight()));
//        oldDragPosition = 0;
//        mViewPager.beginFakeDrag();
//        mValueAnimator.start();
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            animatePagerLoop();
        }
    };

    private ValueAnimator.AnimatorUpdateListener mAnimatorUpdateListener = new ValueAnimator.AnimatorUpdateListener() {

        @Override
        public void onAnimationUpdate(ValueAnimator animation) {
//            int dragPosition = (Integer) animation.getAnimatedValue();
//            int dragOffset = dragPosition - oldDragPosition;
//            oldDragPosition = dragPosition;
//            if (mViewPager != null && mViewPager.isFakeDragging() && mViewPager.getChildCount() > 0) {
//                mViewPager.fakeDragBy(dragOffset * (mIsForward ? -1 : 1));
//            }
        }

    };

    private AccelerateInterpolator mAccelerateInterpolator = new AccelerateInterpolator();

    private Animator.AnimatorListener mAnimatorListener = new Animator.AnimatorListener() {
        @Override
        public void onAnimationStart(Animator animation) {
        }

        @Override
        public void onAnimationEnd(Animator animation) {
            //if (mViewPager != null && mViewPager.isFakeDragging()) {
            //    mViewPager.endFakeDrag();
           // }
        }

        @Override
        public void onAnimationCancel(Animator animation) {
            //mViewPager.endFakeDrag();
        }

        @Override
        public void onAnimationRepeat(Animator animation) {
        }
    };
}
