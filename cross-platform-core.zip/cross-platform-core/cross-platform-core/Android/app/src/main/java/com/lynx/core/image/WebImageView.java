package com.lynx.core.image;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;

import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import com.squareup.picasso.Target;
import com.squareup.picasso.Transformation;

/**
 * Created by Monster on 2017/3/16.
 */

public class WebImageView extends android.support.v7.widget.AppCompatImageView {

    protected String mCurUrl;
    protected Target mListenTarget;

    public WebImageView(Context context) {
        super(context);
    }

    public void setImageUrl(String url) {
        this.setImageUrl(url,null);
    }

    public void setListenTarget(Target target) {
        this.mListenTarget = target;
    }

    public void setImageUrl(String url, Target target) {
        this.setImageUrl(url,target,null);
    }

    public void setImageUrl(String url, Target target, Transformation transformation) {
        if (mCurUrl != null && mCurUrl.equals(url)) {
            return;
        }
        if (TextUtils.isEmpty(url)) {
            this.setImageResource(android.R.color.transparent);
        } else {
            if (target != null) {
                mListenTarget = target;
            } else {
                if (mListenTarget == null) {
                    mListenTarget = new DefaultListenTarget();
                }
            }
            RequestCreator requestCreator = Picasso.with(getContext()).load(url);
            if (transformation != null) {
                requestCreator.transform(transformation);
            }
            requestCreator.tag(getContext())
                    .into(mListenTarget);
        }
        mCurUrl = url;
    }

    /* picasso 监听图片下载结果的target*/
    private class DefaultListenTarget implements Target {
        @Override
        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
            if (bitmap == null) {
                return;
            }
            WebImageView.this.setImageBitmap(bitmap);
        }

        @Override
        public void onBitmapFailed(Drawable errorDrawable) {
            Log.e("lynx", "image load failed");
        }

        @Override
        public void onPrepareLoad(Drawable placeHolderDrawable) {
        }
    }
}
