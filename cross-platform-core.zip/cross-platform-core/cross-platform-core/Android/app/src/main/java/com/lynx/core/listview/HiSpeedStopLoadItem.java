package com.lynx.core.listview;

/**
 * Created by yxp on 17/01/31.
 *
 */

public interface HiSpeedStopLoadItem {

    void stopLoadResWhenViewInHiSpeed();

    void allowLoadResWhenViewInHiSpeed();

    void reloadResWhenSuitable();

}
