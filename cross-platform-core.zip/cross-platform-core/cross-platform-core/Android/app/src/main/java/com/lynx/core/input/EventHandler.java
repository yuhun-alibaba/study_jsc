package com.lynx.core.input;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.widget.EditText;

import com.lynx.core.LynxRenderImplInterface;
import com.lynx.core.base.LynxEvent;
import com.lynx.core.impl.RenderObjectImpl;

import static com.lynx.core.input.EventHandlerType.BLUR_EVENT_TYPE;
import static com.lynx.core.input.EventHandlerType.CHANGE_EVENT_TYPE;
import static com.lynx.core.input.EventType.BLUR_EVENT;
import static com.lynx.core.input.EventType.CHANGE_EVENT;


/**
 * Created by Monster on 2016/11/10.
 * input组件事件传递处理
 */
public class EventHandler extends Handler {
    private RenderObjectImpl mImpl;
    //是否可以触发聚焦事件
    private boolean enableFocus = false;

    //是否使能失焦事件
    private boolean enableBlur = false;
    //是否使能change事件
    private boolean enableChange = false;

    public EventHandler(RenderObjectImpl impl) {
        this.mImpl = impl;
    }

    public boolean isEnableFocus() {
        return enableFocus;
    }

    public void setEnableFocus(boolean enableFocus) {
        this.enableFocus = enableFocus;
    }

    public void setEnableBlur(boolean enableBlur) {
        this.enableBlur = enableBlur;
    }

    public void setEnableChange(boolean enableChange) {
        this.enableChange = enableChange;
    }

    @Override
    public void handleMessage(Message msg) {
        //处理change事件
        if (msg.what == CHANGE_EVENT_TYPE.ordinal()) {
            try {
                LynxRenderImplInterface impl = mImpl.getViewImpl();
                if (impl == null){
                    return;
                }
                String newText = ((EditText) impl).getText().toString();
                String mText = (String) msg.obj;
                if (!TextUtils.isEmpty(newText)) {
                    if (!TextUtils.isEmpty(mText)) {
                        if (!newText.equals(mText)) {
                            sendToJs(CHANGE_EVENT, enableChange);
                        }
                    } else {
                        sendToJs(CHANGE_EVENT, enableChange);
                    }
                } else {
                    if (!TextUtils.isEmpty(mText)) {
                        sendToJs(CHANGE_EVENT, enableChange);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            //处理失焦事件
        } else if (msg.what == BLUR_EVENT_TYPE.ordinal()) {
            enableFocus = true;
            sendToJs(BLUR_EVENT, enableBlur);
        }
    }


    /**
     * 发送到js
     *
     * @param eventType
     */
    private void sendToJs(String eventType, boolean flag) {
        if (flag) {
            LynxEvent mEventToJs = new LynxEvent(eventType);
            Object[] mParamsToJs = new Object[1];
            mParamsToJs[0] = mEventToJs;
            mImpl.dispatchEvent(eventType, mParamsToJs);
        }
    }
}
