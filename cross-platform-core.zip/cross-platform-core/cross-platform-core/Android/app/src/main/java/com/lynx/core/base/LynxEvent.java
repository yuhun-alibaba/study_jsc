package com.lynx.core.base;

/**
 * Created by dli on 28/02/2017.
 */

public class LynxEvent extends JSObject {

    protected static final String TYPE = "type";

    public LynxEvent(String type) {
        setProperty(TYPE, type);
    }
}
