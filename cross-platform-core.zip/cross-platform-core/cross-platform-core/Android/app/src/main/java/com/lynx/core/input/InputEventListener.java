package com.lynx.core.input;

import android.text.Editable;
import android.text.TextWatcher;

import com.lynx.core.base.LynxEvent;
import com.lynx.core.impl.RenderObjectAttr;
import com.lynx.core.impl.RenderObjectImpl;

import static com.lynx.core.input.EventType.INPUT_EVENT;

/**
 * Created by Monster on 2016/11/10.
 * input组件的input事件
 * 事件定义:持续不断的输入
 */

public class InputEventListener implements TextWatcher {
    private RenderObjectImpl mImpl;
    private boolean mEnableInput = false;

    public InputEventListener(RenderObjectImpl impl) {
        this.mImpl = impl;
    }

    public void setEnableInput(boolean enableInput) {
        this.mEnableInput = enableInput;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
        mImpl.syncBaseAttr(RenderObjectAttr.GET_TEXT,s.toString());
        if (mEnableInput) {
            LynxEvent mEventToJs = new LynxEvent(INPUT_EVENT);
            Object[] mParamsToJs = new Object[1];
            mParamsToJs[0] = mEventToJs;
            mImpl.dispatchEvent(INPUT_EVENT, mParamsToJs);
        }
    }
}
