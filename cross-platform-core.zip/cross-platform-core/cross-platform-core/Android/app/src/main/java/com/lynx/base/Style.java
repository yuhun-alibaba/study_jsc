package com.lynx.base;

/**
 * Created by dli on 11/23/16.
 */
public class Style {


    public final static int CSSTEXT_ALIGN_LEFT = 0;
    public final static int CSSTEXT_ALIGN_RIGHT = 1;
    public final static int CSSTEXT_ALIGN_CENTER = 2;
    public final static int CSSTEXT_TEXTDECORATION_LINETHROUGH = 3;
    public final static int CSSTEXT_TEXTDECORATION_NONE = 4;
    public final static int CSSTEXT_FONT_WEIGHT_NORMAL = 5;
    public final static int CSSTEXT_FONT_WEIGHT_BOLD = 6;
    public final static int CSSTEXT_OVERFLOW_ELLIPSIS = 7;
    public final static int CSSTEXT_OVERFLOW_NONE = 8;
    public final static int CSSTEXT_WHITESPACE_NOWRAP = 9;
    public final static int CSSTEXT_WHITESPACE_NORMAL = 10;

    public final static int CSSIMAGE_OBJECT_FIT_FILL = 0;
    public final static int CSSIMAGE_OBJECT_FIT_CONTAIN = 1;
    public final static int CSSIMAGE_OBJECT_FIT_COVER = 2;

    public final static int CSSFLEX_DIRECTION_COLUMN = 7;
    public final static int SSFLEX_DIRECTION_COLUMN_REVERS = 8;
    public final static int CSSFLEX_DIRECTION_ROW = 9;
    public final static int SSFLEX_DIRECTION_ROW_REVERSE = 10;

    public int mBackgroundColor;
    public double mBorderWidth;
    public int mBorderColor;
    public double mBorderRadius;
    public double mOpacity;
    public int mFlexDirection;

    public int mWidth;
    public int mHeight;

    public int mZIndex;

    //for text
    public int mFontColor;
    public int mFontSize;
    public int mFontWeight;
    public int mTextOverflow;
    public int mWhiteSpace;
    public int mTextAlign;
    public int mTextDecoration;

    //for iamge
    public int mObjectFit;

    //screen density
    static public double mDensity;


    public Style() {

    }
}
