package com.lynx.core.input;

/**
 * Created by Monster on 2016/11/23.
 */

public enum EventHandlerType {
    /**
     * 文本改变事件传递标志
     */
    CHANGE_EVENT_TYPE,

    /**
     * 失去焦点事件传递标志
     */
    BLUR_EVENT_TYPE
}
