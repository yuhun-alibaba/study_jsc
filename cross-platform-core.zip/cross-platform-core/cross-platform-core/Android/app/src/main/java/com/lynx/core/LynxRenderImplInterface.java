package com.lynx.core;


import com.lynx.core.impl.RenderObjectImpl;
import com.lynx.core.impl.RenderImplInterface;

/**
 * Created by dli on 11/23/16.
 */
public interface LynxRenderImplInterface extends RenderImplInterface {
    void layoutView();
    void linkElement(RenderObjectImpl impl);
    void separateElement();
    RenderObjectImpl getImpl();

}
