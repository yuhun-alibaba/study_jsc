package com.lynx.core.sliderview;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

import com.lynx.core.impl.RenderObjectImpl;

/**
 * Created by Monster on 2017/3/14.
 */

public class SliderViewPagerAdapter extends PagerAdapter {

    protected BaseSliderChildViewFactory mChildViewFactory;

    protected boolean mLooper = false;

    public SliderViewPagerAdapter(Context context) {
        mChildViewFactory = new SliderChildViewFactory(context);
    }

    public SliderViewPagerAdapter(BaseSliderChildViewFactory factory) {
        mChildViewFactory = factory;
    }

    public void setLooper(boolean looper) {
        mLooper = looper;
        notifyDataSetChanged();
    }

    public void appendChild(int index, RenderObjectImpl child) {

        mChildViewFactory.appendChild(index, child);

        notifyDataSetChanged();

    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    public RenderObjectImpl removeChild(int index) {

        RenderObjectImpl removed = mChildViewFactory.removeChild(index);
        notifyDataSetChanged();

        return removed;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        if (mLooper && mChildViewFactory.getChildCount() != 0) {

            View cur = makeView(position);
            if (cur.getParent() != null) {
                ((ViewGroup)cur.getParent()).removeView(cur);
            }
            container.addView(cur);

            return cur;
        } else {

            View cur = makeView(position);
            container.addView(cur);
            return cur;
        }
    }

    protected View makeView(int position) {

        return mChildViewFactory.createView(position);

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        View cur = mChildViewFactory.removeView(position);
        container.removeView(cur);
    }

    @Override
    public int getCount() {
        if (mLooper && mChildViewFactory.getChildCount() > 1) {
            return Integer.MAX_VALUE;
        }
        return mChildViewFactory.getChildCount();
    }

    @Override
    public int getItemPosition(Object object) {

        if (mChildViewFactory.getNeedToFlush()) {
            return PagerAdapter.POSITION_NONE;
        }

        return super.getItemPosition(object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    /**
     * 通过这个方法拿到孩子的个数
     * @return
     */
    public int getActualChildCount() {
        return mChildViewFactory.getChildCount();
    }
}
