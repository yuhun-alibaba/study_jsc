package com.lynx.demo.info;


/**
 * Created by yanxing on 16/7/8.
 * sharedPreferences存储的相关key
 */
public class SharedPreferencesInfo {
    public static String CORE = "xcore";
    public static String LOCAL = "local";
    public static String USER_AGENT = "useragent";
    public static String IS_FIRST_OPEN = "isFirstOpen";
    public static String IS_DEBUG = "isDebug";
    public static String ENABLE_APPMATE = "enableAppmate";
}
