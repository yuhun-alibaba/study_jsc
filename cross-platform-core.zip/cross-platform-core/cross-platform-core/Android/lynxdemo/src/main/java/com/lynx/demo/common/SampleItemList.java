package com.lynx.demo.common;


import com.lynx.demo.recycleview.Item;

import java.util.List;

/**
 * Created by Monster on 2016/12/19.
 */

public class SampleItemList implements Item {
    public List<SampleItem> shortcutList;

    public SampleItemList(List<SampleItem> shortcutList) {
        this.shortcutList = shortcutList;
    }
}
