package com.lynx.demo.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.lynx.demo.R;
import com.mogujie.hdp.framework.eventbus.EventBus;
import com.mogujie.hdp.framework.eventbus.EventReceiver;
import com.mogujie.hdp.framework.extend.v4.HDPFragment;

/**
 * Created by yanxing on 16/7/8.
 * hdp容器入口
 */
public class HdpActivity extends AppCompatActivity implements EventReceiver {
    private HDPFragment mHDPFragment;
    private final static int mRequestCode = 1000;
    private String mUrl;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webcontainer);
        // 注册EventBus
        EventBus.register(this);
        getUrlFromIntent();
        initFragment(savedInstanceState);
    }

    private void getUrlFromIntent() {
        Intent intent = this.getIntent();
        String url=(String)intent.getSerializableExtra("url");
        if (url == null) {
            url = intent.getData().getQueryParameter("url");
        }
        mUrl = url;
    }

    protected void initFragment(Bundle savedInstanceState) {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("加载中...");
        setSupportActionBar(toolbar);
        if(getSupportActionBar() != null){
            // Enable the Up button
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        mHDPFragment = new HDPFragment();
        // HDP初始化入口
        mHDPFragment.initController(this, savedInstanceState);

        // 加载主页
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();
        transaction.add(R.id.framelayout, mHDPFragment, "home");
        transaction.commit();
        mHDPFragment.loadUrl(mUrl);
    }

    /**
     * 返回到主界面
     */
    public void turnBackToHome() {
        finish();
    }

    @Override
    public void onBackPressed() {
        supportFinishAfterTransition();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        mHDPFragment.onNewIntent(intent);
        // 此处做fragment跳转
        Uri uri = intent.getData();
        String url = uri.getQueryParameter("url");
        mHDPFragment.loadUrl(url);
    }

    @Override
    protected void onDestroy() {
        EventBus.unregister(this);
        super.onDestroy();
    }

    @Override
    public void onMsgReceive(String target, String msg, Object data) {
        if (msg.equalsIgnoreCase("onPageFinished")) {

        } else if (msg.equalsIgnoreCase("onReceivedTitle")) {
            if (data != null && toolbar != null) {
                toolbar.setTitle((String) data);
            }
        } else if (msg.equalsIgnoreCase("onPageStarted")) {
            if (toolbar != null)
                toolbar.setTitle("加载中...");
        } else if (msg.equalsIgnoreCase("onReceivedError")) {

        } else if (msg.equalsIgnoreCase("onNewIntent")) {
            // 此处不要做fragment跳转,由于内部是进行PluginManager插件遍历,以EVENTBUS传出事件
            // 利用fragment跳转会使PluginMananger重新加载,会引起ConcurrentModificationException

        }
    }

}
