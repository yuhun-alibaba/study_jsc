package com.lynx.demo.recycleview;

import android.support.annotation.NonNull;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by Monster on 2016/12/19.
 */

public class EveryTypePool implements TypePool{
    private static String TAG = EveryTypePool.class.getSimpleName();
    private ArrayList<Class<? extends Item>> contents ;
    private ArrayList<ItemViewHolder> holders ;

    private EveryTypePool() {
        this.contents = new ArrayList<>();
        this.holders = new ArrayList<>();
    }

    static EveryTypePool newInstance(){
        return new EveryTypePool();
    }


    @Override
    public void register(@NonNull Class<? extends Item> clazz, @NonNull ItemViewHolder holder) {
        if (!contents.contains(clazz)){
            contents.add(clazz);
            holders.add(holder);
        }else{
            int index = contents.indexOf(clazz);
            holders.set(index,holder);
            Log.w(TAG,"override the type");
        }
    }

    @Override
    public int indexOf(@NonNull Class<? extends Item> clazz) {
        int index = contents.indexOf(clazz);
        if (index >= 0){
            return index;
        }
        for (int i = 0;i<contents.size();i++){
            if (contents.get(i).isAssignableFrom(clazz)){
                return i;
            }
        }
        return index;
    }

    @NonNull
    @Override
    public ArrayList<Class<? extends Item>> getContents() {
        return contents;
    }

    @NonNull
    @Override
    public ArrayList<ItemViewHolder> getHolders() {
        return holders;
    }

    @NonNull
    @Override
    public ItemViewHolder getItemViewHolderByIndex(int index) {
        return holders.get(index);
    }

    @SuppressWarnings("unchecked")
    @NonNull
    @Override
    public <T extends ItemViewHolder> T getItemViewHolderByClass(Class<? extends Item> clazz) {
        return (T)getItemViewHolderByIndex(indexOf(clazz));
    }
}
