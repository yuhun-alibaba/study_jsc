package com.lynx.demo.recycleview;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Monster on 2016/12/19.
 */

public class EveryTypeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements TypePool,FlatTypeAdapter{
    protected LayoutInflater inflater;
    protected EveryTypePool delegate;
    protected List<? extends Item> items;

    public EveryTypeAdapter(List<? extends Item> items) {
        this.items = items;
        this.delegate = EveryTypePool.newInstance();
    }

    @Override
    public int getItemViewType(int position) {
        Item item = items.get(position);
        return indexOf(onFlattenClass(item));
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (inflater == null){
            inflater = LayoutInflater.from(parent.getContext());
        }
        return getItemViewHolderByIndex(viewType).onCreateViewHolder(inflater,parent);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int type = getItemViewType(position);
        Item item = items.get(position);
        getItemViewHolderByIndex(type).onBindViewHolder(holder,item);
    }

    @Override
    public int getItemCount() {
        return items == null?0:items.size();
    }

    @Override
    public void register(@NonNull Class<? extends Item> clazz, @NonNull ItemViewHolder holder) {
        delegate.register(clazz, holder);
    }

    @Override
    public int indexOf(@NonNull Class<? extends Item> clazz) {
        return delegate.indexOf(clazz);
    }

    @NonNull
    @Override
    public ArrayList<Class<? extends Item>> getContents() {
        return delegate.getContents();
    }

    @NonNull
    @Override
    public ArrayList<ItemViewHolder> getHolders() {
        return delegate.getHolders();
    }

    @NonNull
    @Override
    public ItemViewHolder getItemViewHolderByIndex(int index) {
        return delegate.getItemViewHolderByIndex(index);
    }

    @NonNull
    @Override
    public <T extends ItemViewHolder> T getItemViewHolderByClass(Class<? extends Item> clazz) {
        return delegate.getItemViewHolderByClass(clazz);
    }

    @NonNull
    @Override
    public Class onFlattenClass(@NonNull Item item) {
        return item.getClass();
    }

    @NonNull
    @Override
    public Item onFlattenItem(@NonNull Item item) {
        return item;
    }
}
