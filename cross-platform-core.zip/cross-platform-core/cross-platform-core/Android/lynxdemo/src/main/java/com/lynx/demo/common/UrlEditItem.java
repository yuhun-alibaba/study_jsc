package com.lynx.demo.common;


import com.lynx.demo.recycleview.Item;

/**
 * Created by Monster on 2016/12/19.
 */

public class UrlEditItem implements Item {
    public String url;

    public UrlEditItem(String url) {
        this.url = url;
    }
}
