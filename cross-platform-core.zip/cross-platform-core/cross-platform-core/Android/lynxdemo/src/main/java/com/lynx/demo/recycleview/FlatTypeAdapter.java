package com.lynx.demo.recycleview;

import android.support.annotation.NonNull;

/**
 * Created by Monster on 2016/12/19.
 */

public interface FlatTypeAdapter {
    @NonNull
    Class onFlattenClass(@NonNull Item item);
    @NonNull
    Item onFlattenItem(@NonNull Item item);
}
