package com.lynx.demo.recycleview;

/**
 * Created by Monster on 2016/12/19.
 */

public interface Item {
}
