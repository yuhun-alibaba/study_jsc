package com.lynx.demo.recycleview;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

/**
 * Created by Monster on 2016/12/19.
 */

public abstract class ItemViewHolder<I extends Item,V extends RecyclerView.ViewHolder> {
    @NonNull
    protected abstract V onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent);
    @NonNull
    protected abstract void onBindViewHolder(@NonNull V holder, @NonNull I i);
}
