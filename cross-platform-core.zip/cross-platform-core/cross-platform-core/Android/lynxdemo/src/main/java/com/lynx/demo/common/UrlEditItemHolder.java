package com.lynx.demo.common;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.lynx.demo.R;
import com.lynx.demo.activity.HdpActivity;
import com.lynx.demo.activity.XCoreActivity;
import com.lynx.demo.info.SharedPreferencesInfo;
import com.lynx.demo.recycleview.ItemViewHolder;

/**
 * Created by Monster on 2016/12/19.
 */

public class UrlEditItemHolder extends ItemViewHolder<UrlEditItem,UrlEditItemHolder.ViewHolder> {
    @NonNull
    @Override
    protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
        View view = inflater.inflate(R.layout.url_edit_card, parent, false);
        return new ViewHolder(view);
    }

    @NonNull
    @Override
    protected void onBindViewHolder(@NonNull final ViewHolder holder, @NonNull final UrlEditItem urlEditItem) {
        holder.editText.setText(urlEditItem.url);

    }

    static class ViewHolder extends RecyclerView.ViewHolder{
        private final AppCompatEditText editText;
        private final AppCompatButton mButton;
        private final AppCompatButton mWebViewBtn;
        private final AppCompatButton mXcoreBtn;
        private SharedPreferences mSharedPreferences;
        private final String[] urlArray = new String[]{"http://h5.mogujie.com/mgj-hd/category.html?_xcore=1&cate=clothing",
                "http://h5.mogujie.com/mgj-hd/home.html?_xcore=1",
                "http://h5.mogujie.com/mgj-hd/shop-detail.html?_xcore=1&iid=1k6k8gi&ptp=m1.zqDTfb..0.NOgx4&acm=3.ms.1_4_1k6k8gi.0.1651-22922.w6Tsfq7Y1cEqt.t_0",
                "http://h5.mogujie.com/mgj-hd/search-bar.html?_xcore=1",
                "http://h5.mogujie.com/mgj-hd/mine.html?_xcore=1",
                "http://h5.mogujie.com/mgj-brandstation-xcore/home.html?_xcore=1",
                "http://h5.mogujie.com/xcore-example/hello.html?_xcore=1","http://dwz.cn/4LagjE?_xcore=1"};
        private int indexUrl = 0;
        public ViewHolder(View itemView) {
            super(itemView);
            mSharedPreferences = itemView.getContext().getSharedPreferences(SharedPreferencesInfo.CORE, Activity.MODE_PRIVATE);
            editText = (AppCompatEditText) itemView.findViewById(R.id.local_ip);
            mButton = (AppCompatButton) itemView.findViewById(R.id.btn_change_url);
            mWebViewBtn = (AppCompatButton) itemView.findViewById(R.id.btn_webview_open);
            mXcoreBtn = (AppCompatButton) itemView.findViewById(R.id.btn_xcore_open);
            mButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (indexUrl < urlArray.length - 1) {
                        indexUrl++;
                    } else {
                        indexUrl = 0;
                    }
                    editText.setText(urlArray[indexUrl]);
                }
            });
            editText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    SharedPreferences.Editor mEditor = mSharedPreferences.edit();
                    mEditor.putString(SharedPreferencesInfo.LOCAL, s.toString());
                    mEditor.apply();
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });

            mWebViewBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    webviewOpen();
                }
            });
            mXcoreBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    xcoreOpen();
                }
            });
        }
        private void xcoreOpen() {
            load(XCoreActivity.class);
        }

        private void webviewOpen() {
            load(HdpActivity.class);
        }

        private void load(Class className) {
            String url = editText.getText().toString();

            if (TextUtils.isEmpty(url)) {
                Toast.makeText(editText.getContext(), "url 为空",Toast.LENGTH_SHORT).show();
                return;
            }
            if (!url.startsWith("http://")) {
                url = "http://" + url;
            }
            Intent intent = new Intent();
            String title = "自定义页面";
            intent.putExtra("title", title);
            intent.setClass(editText.getContext(), className);
            Bundle bundle = new Bundle();
            bundle.putSerializable("url", url);
            intent.putExtras(bundle);
            editText.getContext().startActivity(intent);
        }
    }
}
