package com.lynx.demo.adpter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import com.lynx.demo.recycleview.EveryTypeAdapter;
import com.lynx.demo.recycleview.Item;
import com.lynx.demo.util.ScreenUtils;

import java.util.List;


/**
 * Created by Monster on 2016/11/25.
 */

public class MyAdapter extends EveryTypeAdapter {
    private static final int ANIMATED_ITEMS_COUNT = 4;
    private boolean animateItems = false;
    private int lastAnimatedPosition = -1;

    public MyAdapter(List<? extends Item> items) {
        super(items);
    }

    private void runEnterAnimation(View view, int position) {
        if (!animateItems || position >= ANIMATED_ITEMS_COUNT - 1) {
            return;
        }
        if (position > lastAnimatedPosition) {
            lastAnimatedPosition = position;
            view.setTranslationY(ScreenUtils.getScreenHeight(view.getContext()));
            view.animate()
                    .translationY(0)
                    .setStartDelay(100 * position)
                    .setInterpolator(new DecelerateInterpolator(3.f))
                    .setDuration(700)
                    .start();
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        runEnterAnimation(holder.itemView, position);
        super.onBindViewHolder(holder, position);
    }

}
