package com.lynx.demo.common;


import com.lynx.demo.recycleview.Item;

/**
 * Created by Monster on 2016/12/19.
 */

public class Category implements Item {
    public String title;
    public int titleLogo;
    public String lastTitle;

    public Category(String title, int titleLogo, String lastTitle) {
        this.title = title;
        this.titleLogo = titleLogo;
        this.lastTitle = lastTitle;
    }
}
