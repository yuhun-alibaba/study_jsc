package com.lynx.demo.common;

import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.lynx.demo.R;
import com.lynx.demo.recycleview.ItemViewHolder;

import java.util.List;

/**
 * Created by Monster on 2016/12/19.
 */

public class GridViewItemHolder extends ItemViewHolder<SampleItemList, GridViewItemHolder.ViewHolder> {
    @NonNull
    @Override
    protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
        View view = inflater.inflate(R.layout.example_item,parent,false);
        return new ViewHolder(view);
    }

    @NonNull
    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull SampleItemList sampleItemList) {
        holder.setSampleItems(sampleItemList.shortcutList);
    }

    static class ViewHolder extends RecyclerView.ViewHolder{
        private final ExampleAdapter exampleAdapter;
        private RecyclerView mRecyclerView;
        private ViewHolder(View itemView) {
            super(itemView);
            mRecyclerView = (RecyclerView) itemView.findViewById(R.id.rv_example);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(itemView.getContext(),3);
            mRecyclerView.setLayoutManager(gridLayoutManager);
            mRecyclerView.setItemAnimator(new DefaultItemAnimator());
            exampleAdapter = new ExampleAdapter();
            mRecyclerView.setAdapter(exampleAdapter);
        }

        private void setSampleItems(List<SampleItem> items){
            exampleAdapter.setSampleItems(items);
            exampleAdapter.notifyDataSetChanged();
        }
    }
}
