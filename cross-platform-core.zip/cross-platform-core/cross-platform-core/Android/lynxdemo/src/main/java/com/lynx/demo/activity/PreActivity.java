package com.lynx.demo.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;

import com.lynx.demo.R;
import com.lynx.demo.info.SharedPreferencesInfo;


/**
 * Created by yanxing on 16/7/5.
 * 加载页
 */
public class PreActivity extends Activity {
    public static int OVERLAY_PERMISSION_REQ_CODE = 1234;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre);
        View mBody = findViewById(R.id.body);
        requestDrawOverLays();

        mBody.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(PreActivity.this, MainActivity.class));
                finish();
                //overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }
        },1000);

    }

    public void requestDrawOverLays() {
        try {
            SharedPreferences mSharedPreferences = getSharedPreferences(SharedPreferencesInfo.CORE, Activity.MODE_PRIVATE);
            boolean enabled = mSharedPreferences.getBoolean(SharedPreferencesInfo.ENABLE_APPMATE, false);
            if (enabled) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE);
            }
        } catch (Exception e) {

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQ_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    Log.d("ok.","can draw overlays.");
                }
            }
        }
    }
}
