package com.lynx.demo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lynx.core.LynxView;
import com.lynx.demo.R;
import com.lynx.utils.StringUtil;
import com.mogujie.uikit.progressbar.MGProgressbar;
public class XCoreActivity extends AppCompatActivity {
    private TextView mTitle;
    private String mTitleString;
    private MGProgressbar mProgressbar;
    private String mUrl;

    LynxView mWebView;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Bundle b = savedInstanceState;

        Intent intent = this.getIntent();
        mUrl = (String) intent.getSerializableExtra("url");
        mTitleString = intent.getStringExtra("title");
        if (mUrl == null) {
            mUrl = intent.getData().getQueryParameter("url");
        }
        createWholeView(mUrl);
        if (mUrl.startsWith("local://")) {
            // 加载本地测试页面
            //mWebView.loadScriptData(readBundleScript("prebundle.js"));
            //mWebView.loadScriptData(readBundleScript("xiaodian.js"));
            //mWebView.loadScriptData(readBundleScript("bundle.js"));
            mWebView.loadHTMLData(readBundleScript("bundle.html"));
        } else {
            // 请求index.xc文件
            mWebView.loadUrl(mUrl);
        }
    }

    private void createWholeView(final String url) {
        setContentView(R.layout.activity_xcore);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(mTitleString);
        setSupportActionBar(toolbar);
        if(getSupportActionBar() != null){
            // Enable the Up button
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        mWebView = new LynxView(this, getDataServerRendered(url));
        RelativeLayout ll = (RelativeLayout) findViewById(R.id.body_ll);
        ll.addView(mWebView);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private String readBundleScript(String fileName) {
        try {
            return StringUtil.convertToString(getResources().getAssets().open(fileName));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private boolean getDataServerRendered(String url) {
        return !url.contains("_xcore=1");
    }
}
