package com.lynx.demo.info;

import android.content.Context;

import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by yanxing on 16/7/5.
 * 读取config.json的配置信息
 */
public class Config {

    public static ShortCuts readFromJSON(Context context) {
        ShortCuts shortCuts = null;
        Gson gson = new Gson();
        try {
            InputStream is = context.getAssets().open("config.json");
            int length = -1;
            byte[] buffer = new byte[is.available()];
            while ((length = is.read(buffer)) > 0) {
                String json = new String(buffer, 0, length);
                shortCuts =  gson.fromJson(json, Config.ShortCuts.class);
            }
            buffer = null;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return shortCuts;
    }



    public class ShortCuts {
        private List<String> userAgentApps;
        private List<Item> shortcutList;

        public List<Item> getItems() {
            return shortcutList;
        }

        public void setItems(List<Item> items) {
            this.shortcutList = items;
        }

        public List<String> getUserAgentApps() {
            return userAgentApps;
        }

        public void clearItem(){
            if (shortcutList != null){
                shortcutList.clear();
            }
        }
    }

    public class Item {
        private String name;
        private String url;
        private String icon;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }
    }

}
