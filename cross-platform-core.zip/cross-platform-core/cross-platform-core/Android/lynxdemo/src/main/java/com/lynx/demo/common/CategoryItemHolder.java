package com.lynx.demo.common;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.lynx.demo.R;
import com.lynx.demo.recycleview.ItemViewHolder;

/**
 * Created by Monster on 2016/12/19.
 */

public class CategoryItemHolder extends ItemViewHolder<Category,CategoryItemHolder.ViewHolder> {
    @NonNull
    @Override
    protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
        View root = inflater.inflate(R.layout.category_item,parent,false);
        return new ViewHolder(root);
    }

    @NonNull
    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull Category category) {
        holder.title.setText(category.title);
        holder.imageView.setImageResource(category.titleLogo);
        holder.lastTitle.setText(category.lastTitle);
    }

    static class ViewHolder extends RecyclerView.ViewHolder{
        private final TextView title;
        private final ImageView imageView;
        private final TextView lastTitle;

        public ViewHolder(View itemView) {
            super(itemView);
            this.title = (TextView) itemView.findViewById(R.id.tv_title);
            this.imageView = (ImageView) itemView.findViewById(R.id.iv_logo);
            this.lastTitle = (TextView) itemView.findViewById(R.id.tv_last_title);
        }
    }
}
