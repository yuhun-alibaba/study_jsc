package com.lynx.demo.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.NavigationView;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.lynx.demo.R;
import com.lynx.demo.adpter.MyAdapter;
import com.lynx.demo.common.Category;
import com.lynx.demo.common.CategoryItemHolder;
import com.lynx.demo.common.GridViewItemHolder;
import com.lynx.demo.common.SampleItem;
import com.lynx.demo.common.SampleItemList;
import com.lynx.demo.common.UrlEditItem;
import com.lynx.demo.common.UrlEditItemHolder;
import com.lynx.demo.info.SharedPreferencesInfo;
import com.lynx.demo.recycleview.EveryTypeAdapter;
import com.lynx.demo.recycleview.Item;
import com.mogujie.appmate.MGJMateService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dli on 5/3/16.
 */
public class MainActivity extends AppCompatActivity {
    public static final String ACTIVITY_TITLE = "Hybrid Develop Platform";
    private BroadcastReceiver mBroadcastReceiver;
    private SharedPreferences mSharedPreferences;
    private final static int mRequestQRCode = 1000;
    private RecyclerView mRecyclerView;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    private NavigationView mNavigationView;
    private Toolbar toolbar;
    private ArrayList<Item> items;
    private EveryTypeAdapter adapter;

    private static class JsonData {
        private Category category00 = new Category("wifi", R.drawable.wifi, "WIFI");
        private UrlEditItem urlEditItem00 = new UrlEditItem("http://h5.mogujie.com/mgj-brandstation-xcore/home.html?_xcore=1");
        private List<SampleItem> lists = new ArrayList<>();

        {
            lists.add(new SampleItem("local://", R.drawable.monitoring, "本地bundle.js"));
            lists.add(new SampleItem("http://172.17.37.57:9001/tmp/ssr/58520", R.drawable.weight, "SSR"));
            lists.add(new SampleItem("http://h5.mogujie.com/xcore-example/act-616.html?_xcore=1", R.drawable.heart, "616主会场"));
            lists.add(new SampleItem("http://h5.mogujie.com/xcore-example/shopping.html?_xcore=1", R.drawable.heart, "shopping页面"));
            lists.add(new SampleItem("http://h5.mogujie.com/mgj-brandstation-xcore/home.html?_xcore=1", R.drawable.tv, "品牌馆"));
            lists.add(new SampleItem("http://h5.f2e.mogujie.org/xcore/xcore.html?_xcore=1", R.drawable.dummy, "容器插件测试"));
            lists.add(new SampleItem("http://h5.mogujie.com/xcore-test/api.html?_xcore=1", R.drawable.babycar, "api测试"));
            lists.add(new SampleItem("http://act.mogujie.com/616xcore/test?_xcore=1", R.drawable.babycar, "测试"));
            lists.add(new SampleItem("http://act.mogujie.com/xcoretuangouindex?_xcore=1", R.drawable.babycar, "团购线上"));
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Bundle b = savedInstanceState;
        setContentView(R.layout.activity_main);
        initConfig();
        initView();
        initEvent();
    }

    protected void initConfig() {
        startBroadcast();
        mSharedPreferences = this.getSharedPreferences(SharedPreferencesInfo.CORE, Activity.MODE_PRIVATE);
        JsonData data = new JsonData();
        items = new ArrayList<>();
        items.add(data.category00);
        if (!mSharedPreferences.getString(SharedPreferencesInfo.LOCAL,"").isEmpty()){
            data.urlEditItem00.url = mSharedPreferences.getString(SharedPreferencesInfo.LOCAL,"");
        }
        items.add(data.urlEditItem00);
        items.add(new SampleItemList(data.lists));

        adapter = new MyAdapter(items);

    }

    protected void initView() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(ACTIVITY_TITLE);
        setSupportActionBar(toolbar);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.drawer_open,
                R.string.drawer_close);
        mDrawerToggle.syncState();
        mDrawerLayout.addDrawerListener(mDrawerToggle);
        mNavigationView = (NavigationView) findViewById(R.id.navigation_view);


        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
    }

    protected void initEvent() {
        MenuItem item = mNavigationView.getMenu().findItem(R.id.log_debug);
        CheckBox cb = (CheckBox) MenuItemCompat.getActionView(item);
        boolean isDebug = mSharedPreferences.getBoolean(SharedPreferencesInfo.IS_DEBUG, false);
        cb.setChecked(isDebug);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mSharedPreferences.edit().putBoolean(SharedPreferencesInfo.IS_DEBUG, isChecked).apply();
            }
        });

        MenuItem appmateItem = mNavigationView.getMenu().findItem(R.id.enable_appmate);
        CheckBox appmateItemCb = (CheckBox) MenuItemCompat.getActionView(appmateItem);
        boolean enableAppmate = mSharedPreferences.getBoolean(SharedPreferencesInfo.ENABLE_APPMATE, false);
        if (enableAppmate) {
            startAppMate(this);
        }
        appmateItemCb.setChecked(enableAppmate);
        appmateItemCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mSharedPreferences.edit().putBoolean(SharedPreferencesInfo.ENABLE_APPMATE, isChecked).apply();
                Toast.makeText(getApplicationContext(), "更改下次启动生效。", Toast.LENGTH_LONG).show();
            }
        });

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        adapter.register(Category.class, new CategoryItemHolder());
        adapter.register(UrlEditItem.class, new UrlEditItemHolder());
        adapter.register(SampleItemList.class, new GridViewItemHolder());
        mRecyclerView.setAdapter(adapter);

        startBroadcast();
    }

    private void startAppMate(Context context) {
        context.startService(new Intent(context, MGJMateService.class));
    }

    private String getCurWifiName() {
        WifiManager wifiMgr = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiMgr.getConnectionInfo();
        String wifiId = info != null ? info.getSSID() : null;
        return wifiId.substring(1, wifiId.length() - 1);
    }

    private void startBroadcast() {
        // 注册wifi状态更新的接收广播
        mBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {
                    String ids = getCurWifiName();
                    if (!TextUtils.isEmpty(ids)) {
                        ((Category) items.get(0)).title = ids;
                        adapter.notifyItemChanged(0);
                    }
                }

            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        intentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        registerReceiver(mBroadcastReceiver, intentFilter);
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(mBroadcastReceiver);
        super.onDestroy();

    }

    public void goToWifiSettings(View view) {
        startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
    }

}
