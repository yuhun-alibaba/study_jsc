package com.lynx.demo;

import android.util.Log;
import android.webkit.JavascriptInterface;

/**
 * Created by dli on 10/10/16.
 */
public class JavascriptTest {
    @JavascriptInterface
    public void test(){
        Log.e("JavascriptTest", "javascript test");
    }

    @JavascriptInterface
    public void test1(String test){
        Log.e("JavascriptTest1", "javascript test1" + test);
    }

    @JavascriptInterface
    public void testChar(char test){
        Log.e("JavascriptTest1", "javascript char = " + test);
    }

    @JavascriptInterface
    public void testInt(int test){
        Log.e("JavascriptTest1", "javascript test2" + test);
    }

    @JavascriptInterface
    public void testIntArray(int[] test){
        Log.e("JavascriptTest1", "testIntArray test1" + test[0] + " test2 " + test[1] + " test2 " + test[2]);
    }

    @JavascriptInterface
    public void testStringArray(String[] test){
        if (test.length == 0) {
            Log.e("JavascriptTest1", "testStringArray nothing");
        } else {
            Log.e("JavascriptTest1", "testStringArray " + test[0] + " " + test[1] + " " + test[2]);
        }
    }
}
