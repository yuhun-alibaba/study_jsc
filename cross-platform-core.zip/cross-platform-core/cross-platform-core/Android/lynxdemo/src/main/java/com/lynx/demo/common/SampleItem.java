package com.lynx.demo.common;


import com.lynx.demo.recycleview.Item;

/**
 * Created by Monster on 2016/12/19.
 */

public class SampleItem implements Item {
    public String url;
    public int picId;
    public String title;

    public SampleItem(String url, int picId, String title) {
        this.url = url;
        this.picId = picId;
        this.title = title;
    }
}
