/*
 * Copyright 2016 drakeet. https://github.com/drakeet
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lynx.demo.common;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.lynx.demo.R;
import com.lynx.demo.activity.XCoreActivity;

import java.util.List;

/**
 * Created by Monster on 2016/12/19.
 */

public class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ViewHolder> {

    private List<SampleItem> sampleItems;


    public void setSampleItems(List<SampleItem> sampleItems) {
        this.sampleItems = sampleItems;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.example_template, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final SampleItem item = sampleItems.get(position);
        holder.cover.setImageResource(item.picId);
        holder.title.setText(item.title);
        holder.cover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                String title = "";
                intent.putExtra("title", item.title);
                intent.setClass(v.getContext(), XCoreActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("url", item.url);
                intent.putExtras(bundle);
                v.getContext().startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return sampleItems != null ? sampleItems.size() : 0;
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        AppCompatImageView cover;
        TextView title;

        ViewHolder(View itemView) {
            super(itemView);
            cover = (AppCompatImageView) itemView.findViewById(R.id.iv_example);
            title = (TextView) itemView.findViewById(R.id.tv_example);

        }
    }
}
