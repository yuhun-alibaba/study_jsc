package com.lynx.demo.recycleview;

import android.support.annotation.NonNull;

import java.util.ArrayList;

/**
 * Created by Monster on 2016/12/19.
 */

public interface TypePool {
    void register(@NonNull Class<? extends Item> clazz, @NonNull ItemViewHolder holder);
    int indexOf(@NonNull Class<? extends Item> clazz);
    @NonNull
    ArrayList<Class<? extends Item>> getContents();
    @NonNull
    ArrayList<ItemViewHolder> getHolders();
    @NonNull
    ItemViewHolder getItemViewHolderByIndex(int index);
    @NonNull
    <T extends ItemViewHolder> T getItemViewHolderByClass(Class<? extends Item> clazz);
}
