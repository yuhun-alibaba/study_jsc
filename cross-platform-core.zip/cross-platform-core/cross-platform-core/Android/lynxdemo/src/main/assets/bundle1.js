var listview = document.createElement('listview');

for(var i = 0; i < 10; i ++) {
var view = document.createElement('view');
var view_Left = document.createElement('layout-view');
var view_right = document.createElement('view');
var view_left_left = document.createElement('layout-view');
var view_left_right = document.createElement('view');
var view_left_left_left = document.createElement('layout-view');
var view_left_left_middle = document.createElement('view');
var view_left_left_right = document.createElement('view');
var view_left_left_left_right = document.createElement('view');
var view_left_left_left_left = document.createElement('view');

var colorGold = "#FFD700";
var colorGreen = "#32CD32";
var colorRed = "#FF7F50";
var colorGray = '#666';
var colorBlue = '#00f';
var colorBlack = '#000';
var colorWhite = '#fff';


var density = 0.75;

view.setStyle({
  flexDirection: 'column',
  width: 380 * density,
  height: 470 * density,
  backgroundColor: colorBlue,
  paddingBottom: 10 * density,
  paddingTop: 10 * density,
  paddingLeft: 10 * density,
  paddingRight: 10 * density
});

view_Left.setStyle({
  flexDirection: 'row',
  paddingTop: 20 * density,
  paddingBottom: 20 * density,
  width: 360 * density,
  height: 300 * density,
  backgroundColor: colorGreen,
});

view_right.setStyle({
  width: 360 * density,
  height: 150 * density,
  backgroundColor: colorGold,
});

view_left_left.setStyle({
  flexDirection: 'row',
  marginLeft: 20 * density,
  width: 240 * density,
  height: 260 * density,
  backgroundColor: colorBlue,
});

view_left_right.setStyle({
  marginLeft: 20 * density,
  width: 80 * density,
  height: 260 * density,
  backgroundColor: colorGold,
});

view_left_left_left.setStyle({
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  flex: 1,
  height: 260 * density,
  backgroundColor: colorBlack,
});

view_left_left_middle.setStyle({
  flex: 1,
  height: 260 * density,
  backgroundColor: colorGold,
});

view_left_left_right.setStyle({
  flex: 1,
  height: 260 * density,
  backgroundColor: colorGray,
});

view_left_left_left_left.setStyle({
  width: 50 * density,
  height: 100 * density,
  backgroundColor: colorGold,
});

view_left_left_left_right.setStyle({
  width: 50 * density,
  height: 100 * density,
  backgroundColor: colorRed,
});

view_left_left_left.appendChild(view_left_left_left_left);
view_left_left_left.appendChild(view_left_left_left_right);

view_left_left.appendChild(view_left_left_left);
view_left_left.appendChild(view_left_left_middle);
view_left_left.appendChild(view_left_left_right);

view_Left.appendChild(view_left_left);
view_Left.appendChild(view_left_right);

view.appendChild(view_Left);
view.appendChild(view_right);
listview.appendChild(view);
}



document.body.appendChild(listview);