var wrap = document.createElement('view');
var sliderview = document.createElement('sliderview');

wrap.setStyle({
  flexDirection: 'column',
//  justifyContent: 'center',
//  alignItems: 'center'
});

var color = ['#f90', '#0f1', '#87f', '#7f5'];

for (var j = 0; j < 5; j++) {
    var wrapContent = document.createElement('view');

    var label = document.createElement('label');
    label.setText('tab' + '  ' + j);
    label.setStyle({
      fontSize: '14',
      color: '#f00',
      whiteSpace: 'nowrap'
    });

    wrapContent.appendChild(label);
    for (var i = 0; i < 100; i++) {
        var temp = document.createElement('view');
        temp.addEventListener('click', function() {});
        temp.setStyle({
          backgroundColor: color[(i % 4)],
          width: 10,
          height: 10
        })
        wrapContent.setStyle({
            flexDirection: 'column',
            width: 400,
            height: 300,
            marginLeft: 50,
            flexWrap: 'wrap'
        });
        wrapContent.appendChild(temp);
    }
    sliderview.appendChild(wrapContent);
}

var btn = document.createElement('view');
var label = document.createElement('label');
label.setText('增加一个');
label.setStyle({
  fontSize: '14',
  color: '#f00',
  whiteSpace: 'nowrap',
  marginTop: 10
});
btn.appendChild(label);
btn.addEventListener('click', function(e) {
    var wrapContent = document.createElement('view');
    for (var i = 0; i < 100; i++) {
        var temp = document.createElement('view');
        temp.addEventListener('click', function() {});
        temp.setStyle({
          backgroundColor: color[(i % 4)],
          width: 10,
          height: 10
        })
        wrapContent.setStyle({
            flexDirection: 'column',
            width: 200,
            height: 300,
            marginLeft: 50,
            flexWrap: 'wrap'
        });
        wrapContent.appendChild(temp);
      }
    sliderview.appendChild(wrapContent);
})

var removeBtn = document.createElement('view');
var removeLabel = document.createElement('label');
removeLabel.setText('删除第三个');
removeLabel.setStyle({
  fontSize: '14',
  color: '#f00',
  whiteSpace: 'nowrap',
  marginTop: 10
});
removeBtn.appendChild(removeLabel);
removeBtn.addEventListener('click', function(e) {
    sliderview.removeChildByIndex(2);
});

var insertBtn = document.createElement('view');
var insertLabel = document.createElement('label');
insertLabel.setText('插入第三个');
insertLabel.setStyle({
  fontSize: '14',
  color: '#f00',
  whiteSpace: 'nowrap',
  marginTop: 10
});
insertBtn.appendChild(insertLabel);
insertBtn.addEventListener('click', function(e) {
    var wrapContent = document.createElement('view');

    var label = document.createElement('label');
    label.setText('i am insert');
    label.setStyle({
      fontSize: '14',
      color: '#f00',
      whiteSpace: 'nowrap'
    });
    wrapContent.appendChild(label);
    for (var i = 0; i < 100; i++) {
        var temp = document.createElement('view');
        temp.addEventListener('click', function() {});
        temp.setStyle({
          backgroundColor: color[(i % 4)],
          width: 10,
          height: 10
        })
        wrapContent.setStyle({
            flexDirection: 'column',
            width: 200,
            height: 300,
            marginLeft: 50,
            flexWrap: 'wrap'
        });
        wrapContent.appendChild(temp);
      }
    sliderview.insertChildAtIndex(wrapContent, 2);
});

var insertFirstBtn = document.createElement('view');
var insertFirstLabel = document.createElement('label');
insertFirstLabel.setText('插入第三个');
insertFirstLabel.setStyle({
  fontSize: '14',
  color: '#f00',
  whiteSpace: 'nowrap',
  marginTop: 10
});
insertFirstBtn.appendChild(insertFirstLabel);
insertFirstBtn.addEventListener('click', function(e) {
    var wrapContent = document.createElement('view');

    var label = document.createElement('label');
    label.setText('i am 0');
    label.setStyle({
      fontSize: '14',
      color: '#f00',
      whiteSpace: 'nowrap'
    });
    wrapContent.appendChild(label);
    for (var i = 0; i < 100; i++) {
        var temp = document.createElement('view');
        temp.addEventListener('click', function() {});
        temp.setStyle({
          backgroundColor: color[(i % 4)],
          width: 10,
          height: 10
        })
        wrapContent.setStyle({
            flexDirection: 'column',
            width: 200,
            height: 300,
            marginLeft: 50,
            flexWrap: 'wrap'
        });
        wrapContent.appendChild(temp);
      }
    sliderview.insertChildAtIndex(wrapContent, 0);
});

wrap.appendChild(sliderview);
wrap.appendChild(btn);
wrap.appendChild(removeBtn);
wrap.appendChild(insertBtn);
wrap.appendChild(insertFirstBtn);
document.createDom(wrap);