//
//  ViewController.m
//  lynx
//
//  Created by dli on 11/3/16.
//  Copyright © 2016 dli. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

-(BOOL) prefersStatusBarHidden
{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
    
    LynxView *view = [[LynxView alloc] init];
    
    [self.view addSubview:view];
    
    //[view loadScriptData:@"var view = document.createElement('view'); var label = document.createElement('label'); label.setStyle({'width':100}); view.appendChild(label); document.body.appendChild(view); console.log('hello world'); console.log(label.parentNode); console.log(view.parentNode)"];
    
    
 //[view loadScriptFile:@"test"];
    [view parseFile:@"test"];
    
    //NSString *url = @"http://h5.mogujie.com/xcore-example/act-616.html?_xcore=1";
    //[view loadUrl:url];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
