//
//  ViewController.h
//  lynx
//
//  Created by dli on 11/3/16.
//  Copyright © 2016 dli. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "lynx_view.h"

@interface ViewController : UIViewController


@end

